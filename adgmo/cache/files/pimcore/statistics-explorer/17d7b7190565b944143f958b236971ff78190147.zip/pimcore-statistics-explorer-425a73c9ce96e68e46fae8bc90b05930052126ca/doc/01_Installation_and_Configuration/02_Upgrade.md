# Upgrade Information

Following steps are necessary during updating to newer versions.

## Upgrade to 1.3.0
- Execute all migrations of the bundle.

## Upgrade to Pimcore X
- Update to latest (allowed) bundle version in Pimcore 6.9 and execute all migrations.
- Then update to Pimcore X.