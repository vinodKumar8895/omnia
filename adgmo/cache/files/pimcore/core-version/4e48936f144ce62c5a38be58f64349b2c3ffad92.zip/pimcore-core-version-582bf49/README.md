## Don't use this package anymore
## Support will be removed with Pimcore v6.0.0
