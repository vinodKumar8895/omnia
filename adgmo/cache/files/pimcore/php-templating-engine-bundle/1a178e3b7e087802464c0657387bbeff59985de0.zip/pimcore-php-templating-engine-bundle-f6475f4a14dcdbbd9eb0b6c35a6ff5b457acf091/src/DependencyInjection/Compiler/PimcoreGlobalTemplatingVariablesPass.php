<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler;

use Pimcore\Templating\GlobalVariables;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class PimcoreGlobalTemplatingVariablesPass implements CompilerPassInterface
{
    /**
     * @param ContainerBuilder $container
     */
    public function process(ContainerBuilder $container)
    {
        // set templating globals to our implementation
        if ($container->hasDefinition('templating.globals')) {
            $definition = $container->getDefinition('templating.globals');
            $definition->setClass(GlobalVariables::class);
        }
    }
}
