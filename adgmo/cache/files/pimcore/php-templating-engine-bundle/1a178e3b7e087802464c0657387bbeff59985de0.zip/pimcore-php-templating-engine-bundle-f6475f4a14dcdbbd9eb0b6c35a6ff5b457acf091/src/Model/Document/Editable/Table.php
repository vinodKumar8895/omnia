<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Model;

class Table extends Model\Document\Editable\Table implements EditableViewModelInterface
{
    use EditableViewModelTrait;
}
