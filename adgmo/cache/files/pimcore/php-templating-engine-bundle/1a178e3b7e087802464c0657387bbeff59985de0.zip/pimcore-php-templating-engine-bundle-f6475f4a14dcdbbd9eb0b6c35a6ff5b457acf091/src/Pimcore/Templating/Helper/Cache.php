<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\CacheExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class Cache extends CacheExtension implements HelperInterface
{
    use HelperTrait;

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'cache';
    }

    /**
     * @param string $name
     * @param int|null $lifetime
     * @param bool $force
     *
     * @return mixed
     */
    public function __invoke($name, $lifetime = null, $force = false)
    {
        return $this->init($name, $lifetime, $force);
    }
}
