<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\Area;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Model\Document\Editable;

class Info extends Editable\Area\Info
{
    use EditableViewModelTrait;

    /**
     * @inheritdoc
     *
     */
    public function getDocument()
    {
        $document = null;

        if ($this->view && isset($this->view->document)) {
            $document = $this->view->document;
        } else {
            $document = $this->editable->getDocument();
        }

        return $document;
    }
}
