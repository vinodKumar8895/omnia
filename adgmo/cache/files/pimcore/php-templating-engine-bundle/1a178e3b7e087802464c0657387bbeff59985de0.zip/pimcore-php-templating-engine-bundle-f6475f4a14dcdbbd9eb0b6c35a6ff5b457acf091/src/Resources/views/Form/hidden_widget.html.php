<?php echo $view['form']->block($form, 'form_widget_simple', ['type' => isset($type) ? $type : 'hidden']) ?>
