<?php

declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Controller;

use Symfony\Component\HttpFoundation\Request;

interface TemplateControllerInterface
{
    const ATTRIBUTE_TEMPLATE_CONTROLLER = '_template_controller';
    const ATTRIBUTE_AUTO_RENDER = '_template_controller_auto_render';
    const ATTRIBUTE_AUTO_RENDER_ENGINE = '_template_controller_auto_render_engine';

    /**
     * Enable view auto-rendering without depending on the Template annotation
     *
     * @param Request $request
     * @param bool $autoRender
     * @param string|null $engine
     */
    public function setViewAutoRender(Request $request, bool $autoRender, string $engine = null);
}
