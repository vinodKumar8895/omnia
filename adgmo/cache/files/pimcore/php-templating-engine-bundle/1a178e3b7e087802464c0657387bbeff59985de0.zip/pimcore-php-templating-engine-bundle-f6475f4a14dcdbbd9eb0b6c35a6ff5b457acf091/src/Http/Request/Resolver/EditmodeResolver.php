<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Http\Request\Resolver;

use Pimcore\Templating\Vars\TemplateVarsProviderInterface;
use Symfony\Component\HttpFoundation\Request;

class EditmodeResolver extends \Pimcore\Http\Request\Resolver\EditmodeResolver implements TemplateVarsProviderInterface
{
    /**
     * @inheritDoc
     */
    public function addTemplateVars(Request $request, array $templateVars)
    {
        $templateVars['editmode'] = $this->isEditmode($request);

        return $templateVars;
    }
}
