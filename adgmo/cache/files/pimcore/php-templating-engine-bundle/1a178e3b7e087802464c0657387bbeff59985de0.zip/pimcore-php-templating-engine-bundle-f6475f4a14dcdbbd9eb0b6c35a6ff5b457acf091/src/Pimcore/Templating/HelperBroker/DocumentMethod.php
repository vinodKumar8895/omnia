<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\HelperBroker;

use Pimcore\Templating\PhpEngine;

class DocumentMethod implements HelperBrokerInterface
{
    /**
     * @inheritDoc
     */
    public function supports(PhpEngine $engine, $method)
    {
        $document = $engine->__get('document');
        if (null !== $document && method_exists($document, $method)) {
            return true;
        }

        return false;
    }

    /**
     * @inheritDoc
     */
    public function helper(PhpEngine $engine, $method, array $arguments)
    {
        $document = $engine->__get('document');

        return call_user_func_array([$document, $method], $arguments);
    }
}
