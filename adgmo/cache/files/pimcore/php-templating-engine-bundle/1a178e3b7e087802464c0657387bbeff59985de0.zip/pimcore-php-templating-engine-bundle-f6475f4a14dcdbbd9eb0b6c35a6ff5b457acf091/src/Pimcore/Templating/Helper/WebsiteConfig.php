<?php

declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Config;
use Pimcore\Http\RequestHelper;
use Symfony\Component\Templating\Helper\Helper;

class WebsiteConfig extends Helper
{
    /**
     * @var RequestHelper
     */
    protected $requestHelper;

    /**
     * @param RequestHelper $requestHelper
     */
    public function __construct(RequestHelper $requestHelper)
    {
        $this->requestHelper = $requestHelper;
    }

    public function getName()
    {
        return 'websiteConfig';
    }

    public function __invoke($key = null, $default = null)
    {
        $locale = $this->requestHelper->getCurrentRequest()->getLocale();

        return Config::getWebsiteConfigValue($key, $default, $locale);
    }
}
