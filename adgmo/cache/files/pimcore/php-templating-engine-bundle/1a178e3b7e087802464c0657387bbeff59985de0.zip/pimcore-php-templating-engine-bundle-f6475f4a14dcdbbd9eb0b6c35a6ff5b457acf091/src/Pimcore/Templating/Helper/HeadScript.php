<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\Templating\HeadScript as HeadScriptExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class HeadScript extends HeadScriptExtension implements HelperInterface
{
    use HelperTrait;

    /**#@+
     * Script type contants
     * @const string
     */
    const FILE = 'FILE';
    const SCRIPT = 'SCRIPT';
    /**#@-*/

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'headScript';
    }
}
