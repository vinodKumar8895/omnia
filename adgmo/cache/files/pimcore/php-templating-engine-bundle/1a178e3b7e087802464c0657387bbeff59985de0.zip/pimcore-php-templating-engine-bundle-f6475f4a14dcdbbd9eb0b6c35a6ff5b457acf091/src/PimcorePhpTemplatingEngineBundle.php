<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle;

use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Bundle\EnterpriseBundleInterface;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\PimcoreEnterpriseSubscriptionToolsBundle;
use Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler\LegacyTemplatePass;
use Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler\PimcoreGlobalTemplatingVariablesPass;
use Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler\TemplateVarsProviderPass;
use Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler\TemplatingEngineAwareHelperPass;
use Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler\TemplatingPass;
use Pimcore\Extension\Bundle\AbstractPimcoreBundle;
use Pimcore\HttpKernel\BundleCollection\BundleCollection;
use Symfony\Component\DependencyInjection\Compiler\PassConfig;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class PimcorePhpTemplatingEngineBundle extends AbstractPimcoreBundle implements EnterpriseBundleInterface
{
    public function getJsPaths()
    {
        return [];
    }

    /**
     * @param BundleCollection $collection
     */
    public static function registerDependentBundles(BundleCollection $collection)
    {
        $collection->addBundle(new PimcoreEnterpriseSubscriptionToolsBundle());
    }

    public function getBundleLicenseId(): string
    {
        return 'PTE';
    }

    /**
     * {@inheritdoc}
     */
    protected function getComposerPackageName()
    {
        return 'pimcore/php-templating-engine-bundle';
    }

    public function build(ContainerBuilder $container)
    {
        $container->addCompilerPass(new TemplatingPass());
        $container->addCompilerPass(new LegacyTemplatePass(), PassConfig::TYPE_BEFORE_OPTIMIZATION, -50);
        $container->addCompilerPass(new TemplatingEngineAwareHelperPass());
        $container->addCompilerPass(new TemplateVarsProviderPass());
        $container->addCompilerPass(new PimcoreGlobalTemplatingVariablesPass());
    }
}
