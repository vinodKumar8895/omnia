<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Http\RequestHelper;
use Pimcore\Model\Translation;
use Symfony\Component\Templating\Helper\Helper;
use Symfony\Contracts\Translation\TranslatorInterface;

class Translate extends Helper
{
    /**
     * @var TranslatorInterface
     */
    protected $translator;

    /**
     * @var string
     */
    protected $domain;

    protected $requestHelper;

    public function __construct(TranslatorInterface $translator, RequestHelper $requestHelper)
    {
        $this->translator = $translator;
        $this->requestHelper = $requestHelper;
    }

    /**
     * Returns the canonical name of this helper.
     *
     * @return string The canonical name
     */
    public function getName()
    {
        return 'translate';
    }

    /**
     * @param string $key
     * @param array $parameters
     * @param string|null $domain
     * @param string|null $locale
     *
     * @return string
     */
    public function __invoke($key, $parameters = [], $domain = Translation::DOMAIN_DEFAULT, $locale = null)
    {
        //compatibility for legacy views
        if (is_string($parameters) || is_numeric($parameters)) {
            $parameters = [$parameters];
        }

        if (!$locale) {
            $locale = $this->requestHelper->getCurrentRequest()->getLocale();
        }

        $term = $this->translator->trans($key, $parameters, $domain, $locale);

        return $term;
    }

    /**
     * @param string $domain
     */
    public function setDomain($domain)
    {
        $this->domain = $domain;
    }
}
