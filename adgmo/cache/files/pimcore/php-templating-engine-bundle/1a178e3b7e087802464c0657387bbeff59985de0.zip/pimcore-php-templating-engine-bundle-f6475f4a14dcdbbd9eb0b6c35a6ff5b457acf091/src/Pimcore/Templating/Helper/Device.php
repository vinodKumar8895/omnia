<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Tool\DeviceDetector;
use Symfony\Component\Templating\Helper\Helper;

class Device extends Helper
{
    /**
     * @param string|null $default
     *
     * @return DeviceDetector
     */
    public function __invoke($default = null)
    {
        return DeviceDetector::getInstance($default);
    }

    /**
     * Returns the canonical name of this helper.
     *
     * @return string The canonical name
     */
    public function getName()
    {
        return 'device';
    }
}
