<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Model\Document\PageSnippet;
use Pimcore\Targeting\Document\DocumentTargetingConfigurator;
use Pimcore\Templating\HelperTrait;
use Pimcore\Templating\Renderer\ActionRenderer;
use Symfony\Component\HttpKernel\Controller\ControllerReference;
use Symfony\Component\Templating\Helper\Helper;

class Action extends Helper
{
    use HelperTrait;

    /**
     * @var ActionRenderer
     */
    protected $actionRenderer;

    /**
     * @var DocumentTargetingConfigurator
     */
    private $targetingConfigurator;

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'action';
    }

    public function __construct(
        ActionRenderer $actionRenderer,
        DocumentTargetingConfigurator $targetingConfigurator,
    ) {
        $this->actionRenderer = $actionRenderer;
        $this->targetingConfigurator = $targetingConfigurator;
    }

    /**
     * @param string $action
     * @param string $controller
     * @param string|null $module
     * @param array $attributes
     * @param array $query
     * @param array $options
     *
     * @return string
     */
    public function __invoke($controller, array $attributes = [], array $query = [], array $options = [])
    {
        $document = isset($attributes['document']) ? $attributes['document'] : null;
        if ($document && $document instanceof PageSnippet) {
            // apply best matching target group (if any)
            $this->targetingConfigurator->configureTargetGroup($document);

            $attributes = $this->actionRenderer->addDocumentAttributes($document, $attributes);
        }

        $uri = new ControllerReference($controller, $attributes, $query);

        return $this->actionRenderer->render($uri, $options);
    }
}
