<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\Templating\PimcoreUrl as PimcoreUrlExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class PimcoreUrl extends PimcoreUrlExtension implements HelperInterface
{
    use HelperTrait;

    /**
     * Returns the canonical name of this helper.
     *
     * @return string The canonical name
     */
    public function getName()
    {
        return 'pimcoreUrl';
    }
}
