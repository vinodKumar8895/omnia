<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Document\Editable\EditableHandler;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Cache;
use Pimcore\Model;
use Pimcore\Model\Document;
use Pimcore\Model\Site;
use Pimcore\Targeting\Document\DocumentTargetingConfigurator;
use Pimcore\Tool\DeviceDetector;

class Snippet extends Model\Document\Editable\Snippet implements EditableViewModelInterface
{
    use EditableViewModelTrait;

    /**
     * @see EditableInterface::frontend
     *
     * @return string
     */
    public function frontend()
    {
        // TODO inject services via DI when editables are built through container
        $container = \Pimcore::getContainer();

        $editableHandler = $container->get(EditableHandler::class);
        $targetingConfigurator = $container->get(DocumentTargetingConfigurator::class);

        if (!$this->snippet instanceof Document\Snippet) {
            return '';
        }

        if (!$this->snippet->isPublished()) {
            return '';
        }

        // apply best matching target group (if any)
        $targetingConfigurator->configureTargetGroup($this->snippet);

        $params = $this->config;
        $params['document'] = $this->snippet;

        // check if output-cache is enabled, if so, we're also using the cache here
        $cacheKey = null;
        $cacheConfig = \Pimcore\Tool\Frontend::isOutputCacheEnabled();
        if ((isset($params['cache']) && $params['cache'] === true) || $cacheConfig) {

            // cleanup params to avoid serializing Element\ElementInterface objects
            $cacheParams = $params;
            array_walk($cacheParams, function (&$value, $key) {
                if ($value instanceof Model\Element\ElementInterface) {
                    $value = $value->getId();
                }
            });

            // TODO is this enough for cache or should we disable caching completely?
            if ($this->snippet->getUseTargetGroup()) {
                $cacheParams['target_group'] = $this->snippet->getUseTargetGroup();
            }

            if (Site::isSiteRequest()) {
                $cacheParams['siteId'] = Site::getCurrentSite()->getId();
            }

            $cacheKey = 'editable_snippet__' . md5(serialize($cacheParams));
            if ($content = Cache::load($cacheKey)) {
                return $content;
            }
        }

        $content = $editableHandler->renderAction($this->snippet->getController(), $params);

        // write contents to the cache, if output-cache is enabled
        if (isset($params['cache']) && $params['cache'] === true) {
            Cache::save($content, $cacheKey, ['output']);
        } elseif ($cacheConfig && !DeviceDetector::getInstance()->wasUsed()) {
            Cache::save($content, $cacheKey, ['output', 'output_inline'], $cacheConfig['lifetime']);
        }

        return $content;
    }
}
