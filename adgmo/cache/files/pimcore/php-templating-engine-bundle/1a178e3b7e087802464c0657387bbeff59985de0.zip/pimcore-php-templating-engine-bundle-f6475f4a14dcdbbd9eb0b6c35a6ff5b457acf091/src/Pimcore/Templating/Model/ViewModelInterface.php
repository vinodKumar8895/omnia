<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Model;

use Symfony\Component\HttpFoundation\ParameterBag;

interface ViewModelInterface extends \Countable, \IteratorAggregate, \ArrayAccess, \JsonSerializable
{
    /**
     * @return ParameterBag
     */
    public function getParameters();

    /**
     * Get parameter value
     *
     * @param string $key
     * @param mixed|null $default
     *
     * @return mixed
     */
    public function get($key, $default = null);

    /**
     * Check if parameter is set
     *
     * @param string $key
     *
     * @return bool
     */
    public function has($key);
}
