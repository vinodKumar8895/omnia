<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Http\Request\Resolver;

use Pimcore\Http\Request\Resolver\ViewModelResolver;
use Pimcore\Model\Document;
use Pimcore\Templating\Vars\TemplateVarsProviderInterface;
use Symfony\Cmf\Bundle\RoutingBundle\Routing\DynamicRouter;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

class DocumentResolver extends \Pimcore\Http\Request\Resolver\DocumentResolver implements TemplateVarsProviderInterface
{
    /**
     * @var ViewModelResolver
     */
    protected $viewModelResolver;

    public function __construct(RequestStack $requestStack, ViewModelResolver $viewModelResolver)
    {
        $this->viewModelResolver = $viewModelResolver;
        parent::__construct($requestStack);
    }

    /**
     * @param Request $request
     * @param Document $document
     */
    public function setDocument(Request $request, Document $document)
    {
        $request->attributes->set(DynamicRouter::CONTENT_KEY, $document);
        if ($document->getProperty('language')) {
            $request->setLocale($document->getProperty('language'));
        }

        // update the view model on the current request if exists
        $viewModel = $this->viewModelResolver->getViewModel($request, false);
        if ($viewModel) {
            $viewModel->getParameters()->set('document', $document);
        }
    }

    /**
     * @inheritDoc
     */
    public function addTemplateVars(Request $request, array $templateVars)
    {
        $templateVars['document'] = $this->getDocument($request);

        return $templateVars;
    }
}
