<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Document\Editable\EditableHandler;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\Area\Info;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Logger;
use Pimcore\Model;
use Pimcore\Model\Document\Editable\Area;

class Areablock extends Model\Document\Editable\Areablock implements EditableViewModelInterface
{
    use EditableViewModelTrait;

    public function loop()
    {
        $disabled = false;
        $config = $this->getConfig();
        $manual = (($config['manual'] ?? false) == true);

        if ($this->current > 0) {
            if (!$manual && $this->blockStarted) {
                $this->blockDestruct();
                $this->blockEnd();

                $this->blockStarted = false;
            }
        } else {
            if (!$manual) {
                $this->start();
            }
        }

        if ($this->current < count($this->indices) && $this->current < $config['limit']) {
            $index = current($this->indices);
            next($this->indices);

            $this->currentIndex = $index;
            if (!empty($config['allowed']) && !in_array($index['type'], $config['allowed'])) {
                $disabled = true;
            }

            $brickTypeLimit = $config['limits'][$this->currentIndex['type']] ?? 100000;
            $brickTypeUsageCounter = $this->brickTypeUsageCounter[$this->currentIndex['type']] ?? 0;
            if ($brickTypeUsageCounter >= $brickTypeLimit) {
                $disabled = true;
            }

            if (!$this->getEditableHandler()->isBrickEnabled($this, $index['type']) && $config['dontCheckEnabled'] != true) {
                $disabled = true;
            }

            $this->blockStarted = false;
            $info = $this->buildInfoObject();

            if (!$manual && !$disabled) {
                $this->blockConstruct();
                $templateParams = $this->blockStart($info);

                $this->blockStarted = true;
                $this->content($info, $templateParams);
            } elseif (!$manual) {
                $this->current++;
            }

            return true;
        } else {
            if (!$manual) {
                $this->end();
            }

            return false;
        }
    }

    public function content($info = null, $templateParams = [], $return = false)
    {
        if (!$info) {
            $info = $this->buildInfoObject();
        }

        $content = '';

        if ($this->editmode || !isset($this->currentIndex['hidden']) || !$this->currentIndex['hidden']) {
            $templateParams['isAreaBlock'] = true;
            $content = $this->getEditableHandler()->renderAreaFrontend($info, $templateParams);
            if (!$return) {
                echo $content;
            }
            $this->brickTypeUsageCounter += [$this->currentIndex['type'] => 0];
            $this->brickTypeUsageCounter[$this->currentIndex['type']]++;
        }

        $this->current++;

        if ($return) {
            return $content;
        }
    }

    public function buildInfoObject(): Area\Info
    {
        // create info object and assign it to the view
        $info = new Info();
        try {
            $info->setId($this->currentIndex['type']);
            $info->setEditable($this);
            $info->setIndex($this->current);
        } catch (\Exception $e) {
            Logger::err($e);
        }

        $params = [];

        $config = $this->getConfig();
        if (isset($config['params']) && is_array($config['params']) && array_key_exists($this->currentIndex['type'], $config['params'])) {
            if (is_array($config['params'][$this->currentIndex['type']])) {
                $params = $config['params'][$this->currentIndex['type']];
            }
        }

        if (isset($config['globalParams'])) {
            $params = array_merge($config['globalParams'], (array)$params);
        }

        $info->setParams($params);

        return $info;
    }

    /**
     * {@inheritDoc}
     */
    protected function getEditableHandler()
    {
        // TODO inject area handler via DI when editables are built through container
        return \Pimcore::getContainer()->get(EditableHandler::class);
    }
}
