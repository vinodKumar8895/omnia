<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\Templating\InlineScript as InlineScriptExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class InlineScript extends InlineScriptExtension implements HelperInterface
{
    use HelperTrait;

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'inlineScript';
    }
}
