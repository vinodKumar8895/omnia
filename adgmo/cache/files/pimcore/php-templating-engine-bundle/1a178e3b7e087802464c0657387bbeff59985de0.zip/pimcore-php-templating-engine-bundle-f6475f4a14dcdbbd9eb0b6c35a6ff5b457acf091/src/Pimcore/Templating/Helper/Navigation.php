<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Model\Document;
use Pimcore\Navigation\Container;
use Pimcore\Navigation\Renderer\RendererInterface;
use Pimcore\Templating\Helper\Navigation\Exception\InvalidRendererException;
use Pimcore\Templating\Helper\Navigation\Exception\RendererNotFoundException;
use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\Templating\Navigation as NavigationExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class Navigation extends NavigationExtension implements HelperInterface
{
    use HelperTrait;

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'navigation';
    }

    /**
     * Builds a navigation container by passing arguments
     *
     *
     * @param Document $activeDocument
     * @param Document|null $navigationRootDocument
     * @param string|null $htmlMenuPrefix
     * @param callable|null $pageCallback
     * @param bool|string $cache
     * @param int|null $maxDepth
     * @param int|null $cacheLifetime
     *
     * @return Container
     *
     * @throws \Exception
     */
    public function buildNavigation(
        Document $activeDocument,
        Document $navigationRootDocument = null,
        string $htmlMenuPrefix = null,
        callable $pageCallback = null,
        $cache = true,
        $maxDepth = null,
        $cacheLifetime = null
    ): Container {
        return parent::build([
            'root' => $navigationRootDocument,
            'htmlMenuPrefix' => $htmlMenuPrefix,
            'pageCallback' => $pageCallback,
            'cache' => $cache,
            'cacheLifetime' => $cacheLifetime,
            'maxDepth' => $maxDepth,
            'active' => $activeDocument,
        ]);
    }

    /**
     * Get a named renderer
     *
     * @param string $alias
     *
     * @return RendererInterface
     */
    public function getRenderer(string $alias): RendererInterface
    {
        try {
            return parent::getRenderer($alias);
        } catch (NavigationExtension\Exception\RendererNotFoundException $exception) {
            throw new RendererNotFoundException($exception->getMessage());
        } catch (NavigationExtension\Exception\InvalidRendererException $exception) {
            throw new InvalidRendererException($exception->getMessage());
        }
    }
}
