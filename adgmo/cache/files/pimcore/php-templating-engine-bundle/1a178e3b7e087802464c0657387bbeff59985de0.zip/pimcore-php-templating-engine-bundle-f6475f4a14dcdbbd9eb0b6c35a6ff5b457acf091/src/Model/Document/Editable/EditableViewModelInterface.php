<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Model\Document\Editable\EditableInterface;
use Pimcore\Templating\Model\ViewModelInterface;

interface EditableViewModelInterface
{
    /**
     * Renders the editable, calls either frontend() or admin() depending on the context
     *
     * @return ViewModelInterface
     */
    public function getView();

    /**
     * @param ViewModelInterface $view
     *
     * @return EditableInterface
     */
    public function setView(ViewModelInterface $view);
}
