<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\EditableViewModelInterface;
use Pimcore\Extension\Document\Areabrick\TemplateAreabrickInterface;
use Pimcore\Model\Document\Editable\Area\Info;
use Pimcore\Templating\Model\ViewModelInterface;

class EditableHandler extends \Pimcore\Document\Editable\EditableHandler
{
    /**
     * {@inheritdoc}
     */
    public function renderAreaFrontend(Info $info, $templateParams = []): string
    {
        $editable = $info->getEditable();

        if ($editable instanceof EditableViewModelInterface) {
            /** @var ViewModelInterface $view */
            $view = $editable->getView();
            $info->setView($view);
        }

        $editmode = $view->get('editmode');
        $brick = $this->brickManager->getBrick($info->getId());

        $params = $info->getParams();
        $forceEditInView = array_key_exists('forceEditInView', $params) && $params['forceEditInView'];
        $hasEditableTemplate = false;
        if (method_exists($brick, 'hasEditTemplate')) {
            $hasEditableTemplate = $brick->hasEditTemplate();
        }
        // merge view parameters
        $params = array_merge(
            $view->getParameters()->all(),
            // enable editmode if editmode is active and the brick has no edit template or edit in view is forced
            ['editmode' => $editmode ? (!$hasEditableTemplate || $forceEditInView) : false],
            $params);
        $info->setParams($params);

        return parent::renderAreaFrontend($info, $templateParams);
    }

    /**
     * Return either bundle or global (= app/Resources) template reference
     *
     * @param TemplateAreabrickInterface $brick
     * @param string $type
     *
     * @return string
     */
    protected function buildBrickTemplateReference(TemplateAreabrickInterface $brick, $type)
    {
        if ($brick->getTemplateLocation() === TemplateAreabrickInterface::TEMPLATE_LOCATION_BUNDLE) {
            $bundle = $this->bundleLocator->getBundle($brick);
            $bundleName = $bundle->getName();
            if (str_ends_with($bundleName, 'Bundle')) {
                $bundleName = substr($bundleName, 0, -6);
            }

            foreach (['areas', 'Areas'] as $folderName) {
                $templateReference = sprintf(
                    '@%s/%s/%s/%s.%s',
                    $bundleName,
                    $folderName,
                    $brick->getId(),
                    $type,
                    $brick->getTemplateSuffix()
                );

                if ($this->templating->exists($templateReference)) {
                    return $templateReference;
                }
            }

            // return the last reference, even we know that it doesn't exist -> let care the templating engine
            return $templateReference;
        } else {
            return sprintf(
                'Areas/%s/%s.%s',
                $brick->getId(),
                $type,
                $brick->getTemplateSuffix()
            );
        }
    }
}
