<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Pimcore\Templating\HelperTrait;
use Pimcore\Twig\Extension\Templating\HeadStyle as HeadStyleExtension;
use Symfony\Component\Templating\Helper\HelperInterface;

class HeadStyle extends HeadStyleExtension implements HelperInterface
{
    use HelperTrait;

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'headStyle';
    }
}
