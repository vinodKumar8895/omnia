<?php

declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler;

use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

class TemplatingPass implements CompilerPassInterface
{
    public function process(ContainerBuilder $container)
    {
        if ($container->hasDefinition('pimcore.templating')) {
            return;
        }

        if ($container->hasDefinition('pimcore.templating.engine.php')) {
            $refs = [];
            $helpers = [];
            $engine = $container->getDefinition('pimcore.templating.engine.php');

            foreach ($container->findTaggedServiceIds('templating.helper', true) as $id => $attributes) {
                if (isset($attributes[0]['alias'])) {
                    $helpers[$attributes[0]['alias']] = new Reference($id);
                    $refs[$id] = new Reference($id);
                }
            }

            if (\count($helpers) > 0) {
                $engine->addMethodCall('setHelpers', [$helpers]);

                if ($container->hasDefinition('pimcore.templating.engine.php.helpers_locator')) {
                    $container->getDefinition('pimcore.templating.engine.php.helpers_locator')->replaceArgument(0, $refs);
                }
            }

            // add tagged helper brokers
            $helperBrokers = $this->findHelperBrokers($container);
            foreach ($helperBrokers as $helperBroker) {
                $engine->addMethodCall('addHelperBroker', [new Reference($helperBroker)]);
            }
        }
    }

    /**
     * Find registered brokers by tag
     *
     * @param ContainerBuilder $container
     *
     * @return array
     */
    protected function findHelperBrokers(ContainerBuilder $container)
    {
        $taggedServices = $container->findTaggedServiceIds('pimcore.templating.helper_broker');

        $list = [];
        foreach ($taggedServices as $id => $tags) {
            foreach ($tags as $attributes) {
                $priority = isset($attributes['priority']) ? (int)$attributes['priority'] : 0;
                $list[$priority][] = $id;
            }
        }

        ksort($list);

        $brokers = [];
        foreach ($list as $priority => $ids) {
            foreach ($ids as $id) {
                $brokers[] = $id;
            }
        }

        $brokers = array_unique($brokers);
        $brokers = array_reverse($brokers); // highest priority first

        return $brokers;
    }
}
