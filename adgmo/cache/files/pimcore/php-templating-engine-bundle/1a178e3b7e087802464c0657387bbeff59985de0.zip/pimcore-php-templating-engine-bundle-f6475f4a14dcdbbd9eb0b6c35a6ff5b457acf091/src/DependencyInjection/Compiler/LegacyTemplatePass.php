<?php

declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection\Compiler;

use Pimcore\Bundle\PhpTemplatingEngineBundle\EventListener\LegacyTemplateListener;
use Pimcore\Templating\LegacyTemplateGuesser;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

class LegacyTemplatePass implements CompilerPassInterface
{
    /**
     * Replace SensioFrameworkExtraBundle template guesser & view listener with our implementation to support PHP templates
     *
     * @inheritDoc
     */
    public function process(ContainerBuilder $container)
    {
        if ($container->hasDefinition('sensio_framework_extra.view.guesser')) {
            $definition = $container->getDefinition('sensio_framework_extra.view.guesser');
            $definition
                ->setPublic(true)
                ->setClass(LegacyTemplateGuesser::class)
                ->addArgument(new Reference('pimcore.templating.engine.delegating'));
        }

        if ($container->hasDefinition('sensio_framework_extra.view.listener')) {
            $definition = $container->getDefinition('sensio_framework_extra.view.listener');
            $definition
                ->setClass(LegacyTemplateListener::class)
                ->addMethodCall('setTemplateEngine', [
                    new Reference('pimcore.templating.engine.delegating'),
                ]);
        }
    }
}
