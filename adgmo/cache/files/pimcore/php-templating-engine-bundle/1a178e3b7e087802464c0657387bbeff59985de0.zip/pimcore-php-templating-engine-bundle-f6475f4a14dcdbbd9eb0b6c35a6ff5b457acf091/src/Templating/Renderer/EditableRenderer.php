<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Templating\Renderer;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\EditableViewModelInterface;
use Pimcore\Model\Document\Editable;
use Pimcore\Model\Document\Editable\EditableInterface;
use Pimcore\Model\Document\PageSnippet;
use Pimcore\Templating\Model\ViewModel;
use Pimcore\Templating\Renderer\EditableRenderer as BaseEditableRenderer;

class EditableRenderer extends BaseEditableRenderer
{
    /**
     * @param PageSnippet $document
     * @param string $type
     * @param string $inputName
     * @param array $config
     * @param bool|null $editmode
     *
     * @return EditableInterface
     *
     * @throws \Exception
     */
    public function getEditable(PageSnippet $document, string $type, string $inputName, array $config = [], bool $editmode = null): Editable\EditableInterface
    {
        $editable = parent::getEditable($document, $type, $inputName, $config, $editmode);

        if ($editable instanceof EditableViewModelInterface) {
            $view = new ViewModel([
                'editmode' => $editmode,
                'document' => $document,
            ]);

            $editable->setView($view);
        }

        return $editable;
    }
}
