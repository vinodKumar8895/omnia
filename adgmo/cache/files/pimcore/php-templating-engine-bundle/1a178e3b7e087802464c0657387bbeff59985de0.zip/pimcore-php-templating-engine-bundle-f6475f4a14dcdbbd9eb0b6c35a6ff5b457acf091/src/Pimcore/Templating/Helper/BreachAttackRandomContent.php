<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Helper;

use Symfony\Component\Templating\Helper\Helper;

class BreachAttackRandomContent extends Helper
{
    /**
     * @inheritDoc
     */
    public function getName()
    {
        return 'breachAttackRandomContent';
    }

    /**
     * @return string
     *
     * @throws \Exception
     */
    public function __invoke()
    {
        $length = 50;
        $randomData = random_bytes($length);

        return '<!--'
            . substr(
                base64_encode($randomData),
                0,
                ord($randomData[$length - 1]) % 32
            )
            . '-->';
    }
}
