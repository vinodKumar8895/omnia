<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\EventListener;

use Pimcore\Event\MailEvents;
use Pimcore\Event\Model\MailEvent;
use Pimcore\Placeholder;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Handles the attributes set by TemplateControllerInterface and injects them into the Template annotation which is
 * then processed by SensioFrameworkExtraBundle. This allows us to add view auto-rendering without depending on annotations.
 *
 */
class MailParametersListeners implements EventSubscriberInterface
{
    public function __construct(protected Placeholder $placeholderObject)
    {
    }

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents()
    {
        return [
            MailEvents::PRE_SEND => 'onMailPreSend',
        ];
    }

    public function onMailPreSend(MailEvent $event)
    {
        $mail = $event->getMail();

        if ($bodyHtmlRendered = $mail->getHtmlBody()) {
            $bodyHtmlRendered = $this->placeholderObject->replacePlaceholders($bodyHtmlRendered, $mail->getParams(), $mail->getDocument());
            $mail->html($bodyHtmlRendered);
        }

        if ($bodyTextRendered = $mail->getTextBody()) {
            $bodyTextRendered = $this->placeholderObject->replacePlaceholders($bodyTextRendered, $mail->getParams(), $mail->getDocument());
            $mail->text($bodyTextRendered);
        }

        if ($subjectRendered = $mail->getSubject()) {
            $subjectRendered = $this->placeholderObject->replacePlaceholders($subjectRendered, $mail->getParams(), $mail->getDocument());
            $mail->subject($subjectRendered);
        }
    }
}
