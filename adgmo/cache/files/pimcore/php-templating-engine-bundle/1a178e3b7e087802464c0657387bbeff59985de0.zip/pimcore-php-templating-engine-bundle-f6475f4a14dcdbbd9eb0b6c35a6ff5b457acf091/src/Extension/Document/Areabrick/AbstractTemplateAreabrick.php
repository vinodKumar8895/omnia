<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Extension\Document\Areabrick;

abstract class AbstractTemplateAreabrick extends \Pimcore\Extension\Document\Areabrick\AbstractTemplateAreabrick
{
    const TEMPLATE_SUFFIX_PHP = 'html.php';

    /**
     * {@inheritdoc}
     */
    public function getTemplateSuffix()
    {
        return static::TEMPLATE_SUFFIX_PHP;
    }
}
