<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection;

use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

/**
 * This is the class that validates and merges configuration from your app/config files.
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/configuration.html}
 */
class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritdoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder('pimcore_templating_engine');
        $rootNode = $treeBuilder->getRootNode();

        $rootNode->addDefaultsIfNotSet()->children()
            ->scalarNode('cache')->end()
            ->arrayNode('form')
                ->addDefaultsIfNotSet()
                ->children()
                    ->arrayNode('resources')
                        ->addDefaultChildrenIfNoneSet()
                        ->prototype('scalar')->defaultValue('PimcorePhpTemplatingEngineBundle:Form')->end()
                        ->validate()
                            ->ifTrue(function ($v) {
                                return !\in_array('PimcorePhpTemplatingEngineBundle:Form', $v);
                            })
                            ->then(function ($v) {
                                return array_merge(['FrameworkBundle:Form'], $v);
                            })
                        ->end()
                    ->end()
                ->end()
            ->end()
            ->booleanNode('enabled')->defaultTrue()->end()
            ->arrayNode('engines')
                ->prototype('scalar')->end()
                ->defaultValue(['twig', 'php'])
                ->info('Supported templating engines')
            ->end()
            ->scalarNode('default_path')
                ->info('The default path used to load Php templates')
                ->defaultValue('%kernel.project_dir%/templates')
            ->end()
        ->end();

        return $treeBuilder;
    }
}
