<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document;

use Pimcore\Templating\Model\ViewModelInterface;

trait EditableViewModelTrait
{
    /**
     * @var ViewModelInterface|null
     *
     */
    protected $view;

    /**
     * @param ViewModelInterface $view
     *
     * @return $this
     */
    public function setView(ViewModelInterface $view)
    {
        $this->view = $view;

        return $this;
    }

    /**
     * @return ViewModelInterface
     */
    public function getView()
    {
        return $this->view;
    }

    public function __sleep()
    {
        $parentVars = parent::__sleep();
        unset($parentVars['view']);

        return $parentVars;
    }

    public function __clone()
    {
        parent::__clone();
        $this->view = null;
    }
}
