<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\Area;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;

abstract class AbstractArea extends \Pimcore\Model\Document\Editable\Area\AbstractArea
{
    use EditableViewModelTrait;
}
