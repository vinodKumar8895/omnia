<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\EventListener;

use Pimcore\Controller\FrontendController;
use Pimcore\Controller\TemplateControllerInterface;
use Pimcore\Templating\LegacyTemplateGuesser;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\Event\ViewEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Handles the attributes set by TemplateControllerInterface and injects them into the Template annotation which is
 * then processed by SensioFrameworkExtraBundle. This allows us to add view auto-rendering without depending on annotations.
 *
 */
class TemplateControllerListener implements EventSubscriberInterface
{
    /**
     * @var LegacyTemplateGuesser
     */
    protected $templateGuesser;

    /**
     * @var string
     */
    protected $defaultEngine;

    /**
     * @param LegacyTemplateGuesser $templateGuesser
     * @param string $defaultEngine
     */
    public function __construct(LegacyTemplateGuesser $templateGuesser, $defaultEngine = 'twig')
    {
        $this->templateGuesser = $templateGuesser;
        $this->defaultEngine = $defaultEngine;
    }

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents()
    {
        // the view event needs to run before the SensioFrameworkExtraBundle TemplateListener
        // handles the Template annotation
        return [
            KernelEvents::CONTROLLER => 'onKernelController',
            KernelEvents::VIEW => ['onKernelView', 50],
        ];
    }

    public function onKernelController(ControllerEvent $event)
    {
        $request = $event->getRequest();
        $callable = $event->getController();

        // if controller implements TemplateControllerInterface, register it as attribute as we need it later in onKernelView
        $templateController = false;
        if (is_object($callable) && ($callable instanceof TemplateControllerInterface || $callable instanceof FrontendController)) {
            $templateController = true;
        } elseif (is_array($callable) && is_object($callable[0]) && ($callable[0] instanceof TemplateControllerInterface || $callable[0] instanceof FrontendController)) {
            $templateController = true;
        }

        if ($templateController) {
            $request->attributes->set(TemplateControllerInterface::ATTRIBUTE_TEMPLATE_CONTROLLER, $callable);
        }
    }

    public function onKernelView(ViewEvent $event)
    {
        $request = $event->getRequest();

        // don't do anything if there's already a Template annotation in place
        if ($request->attributes->has('_template')) {
            return;
        }

        if (!$request->attributes->has(TemplateControllerInterface::ATTRIBUTE_TEMPLATE_CONTROLLER)) {
            return;
        }

        if ($request->attributes->has(TemplateControllerInterface::ATTRIBUTE_AUTO_RENDER)) {
            $controller = $request->attributes->get(TemplateControllerInterface::ATTRIBUTE_TEMPLATE_CONTROLLER);

            $engine = $this->defaultEngine;
            if ($request->attributes->has(TemplateControllerInterface::ATTRIBUTE_AUTO_RENDER_ENGINE)) {
                $engine = $request->attributes->get(TemplateControllerInterface::ATTRIBUTE_AUTO_RENDER_ENGINE);
            }

            $template = new Template([]);
            $template->setOwner($controller);
            $templateReference = $this->templateGuesser->guessTemplateName($controller, $request, $engine);
            $template->setTemplate($templateReference);

            // inject Template annotation into the request - will be used by SensioFrameworkExtraBundle
            $request->attributes->set('_template', $template);
        }
    }
}
