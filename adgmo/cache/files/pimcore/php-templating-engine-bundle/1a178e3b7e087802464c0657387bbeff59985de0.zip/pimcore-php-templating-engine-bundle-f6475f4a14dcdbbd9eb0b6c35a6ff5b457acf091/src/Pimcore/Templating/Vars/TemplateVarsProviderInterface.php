<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Vars;

use Symfony\Component\HttpFoundation\Request;

interface TemplateVarsProviderInterface
{
    /**
     * Adds template vars which should be included in a new view model when
     * created via TemplateVarsResolver.
     *
     * @param Request $request
     * @param array $templateVars
     *
     * @return array
     */
    public function addTemplateVars(Request $request, array $templateVars);
}
