<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Controller\Configuration;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template as BaseTemplate;

/**
 * Same annotation as Template, but defaults to the php engine
 *
 * @Annotation
 *
 */
class TemplatePhp extends BaseTemplate
{
    /**
     * The template engine used when a specific template isn't specified.
     *
     * @var string
     */
    protected $engine = 'php';
}
