<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Document\Editable\EditableHandler;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Model;
use Pimcore\Targeting\Document\DocumentTargetingConfigurator;

class Renderlet extends Model\Document\Editable\Renderlet implements EditableViewModelInterface
{
    use EditableViewModelTrait;

    /**
     * @see EditableInterface::frontend
     *
     * @return string
     */
    public function frontend()
    {
        // TODO inject services via DI when editables are built through container
        $container = \Pimcore::getContainer();
        $editableHandler = $container->get(EditableHandler::class);

        if (!is_array($this->config)) {
            $this->config = [];
        }

        if (empty($this->config['controller']) && !empty($this->config['template'])) {
            $this->config['controller'] = $container->getParameter('pimcore.documents.default_controller');
        }

        if (empty($this->config['controller'])) {
            // this can be the case e.g. in \Pimcore\Model\Search\Backend\Data::setDataFromElement() where
            // this method is called without the config, so it would just render the default controller with the default template
            return '';
        }

        if (method_exists($this->o, 'isPublished')) {
            if (!$this->o->isPublished()) {
                return '';
            }
        }

        if ($this->o instanceof Model\Element\ElementInterface) {
            // apply best matching target group (if any)
            if ($this->o instanceof Document\Targeting\TargetingDocumentInterface) {
                $targetingConfigurator = $container->get(DocumentTargetingConfigurator::class);
                $targetingConfigurator->configureTargetGroup($this->o);
            }

            $blockparams = ['controller', 'template'];

            $params = [
                'template' => isset($this->config['template']) ? $this->config['template'] : null,
                'id' => $this->id,
                'type' => $this->type,
                'subtype' => $this->subtype,
                'pimcore_request_source' => 'renderlet',
            ];

            foreach ($this->config as $key => $value) {
                if (!array_key_exists($key, $params) && !in_array($key, $blockparams)) {
                    $params[$key] = $value;
                }
            }

            return $editableHandler->renderAction(
                $this->config['controller'],
                $params
            );
        }

        return '';
    }
}
