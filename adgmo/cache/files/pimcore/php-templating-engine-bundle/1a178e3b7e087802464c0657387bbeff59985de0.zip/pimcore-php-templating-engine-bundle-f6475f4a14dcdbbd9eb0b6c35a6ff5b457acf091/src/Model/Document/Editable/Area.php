<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Document\Editable\EditableHandler;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\Editable\Area\Info;
use Pimcore\Bundle\PhpTemplatingEngineBundle\Model\Document\EditableViewModelTrait;
use Pimcore\Document\Editable\Block\BlockName;
use Pimcore\Model;

class Area extends Model\Document\Editable\Area implements EditableViewModelInterface
{
    use EditableViewModelTrait;

    /**
     * @inheritDoc
     */
    public function frontend()
    {
        $config = $this->getConfig();

        // TODO inject area handler via DI when editables are built by container
        $editableHandler = \Pimcore::getContainer()->get(EditableHandler::class);

        // don't show disabled bricks
        if (!$editableHandler->isBrickEnabled($this, $config['type'] && ($config['dontCheckEnabled'] ?? false) !== true)) {
            return;
        }

        // push current block name
        $blockState = $this->getBlockState();
        $blockState->pushBlock(BlockName::createFromEditable($this));

        // create info object and assign it to the view
        $info = null;
        try {
            $info = new Info();
            $info->setId($config['type']);
            $info->setEditable($this);
            $info->setIndex(0);
        } catch (\Exception $e) {
            $info = null;
        }

        // start at first index
        $blockState->pushIndex(1);

        $params = [];
        if (isset($config['params']) && is_array($config['params']) && array_key_exists($config['type'], $config['params'])) {
            if (is_array($config['params'][$config['type']])) {
                $params = $config['params'][$config['type']];
            }
        }

        $info->setParams($params);

        $editableHandler->renderAreaFrontend($info);

        // remove current block and index from stack
        $blockState->popIndex();
        $blockState->popBlock();
    }
}
