<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Templating\Loader;

use Symfony\Component\Config\FileLocatorInterface;
use Symfony\Component\Templating\Loader\FilesystemLoader as BaseFilesystemLoader;
use Symfony\Component\Templating\Storage\FileStorage;
use Symfony\Component\Templating\TemplateReferenceInterface;

/**
 * FilesystemLoader is a loader that read templates from the filesystem.
 *
 * @author Fabien Potencier <fabien@symfony.com>
 *
 */
class FilesystemLoader extends BaseFilesystemLoader
{
    protected $locator;

    public function __construct(FileLocatorInterface $locator, $templatePathPatterns = [])
    {
        $this->locator = $locator;

        parent::__construct($templatePathPatterns);
    }

    /**
     * {@inheritdoc}
     */
    public function load(TemplateReferenceInterface $template)
    {
        try {
            $file = $this->locator->locate($template);

            return new FileStorage($file);
        } catch (\InvalidArgumentException $e) {
            return parent::load($template);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function isFresh(TemplateReferenceInterface $template, $time)
    {
        if (false === $storage = $this->load($template)) {
            return false;
        }

        if (!is_readable((string) $storage)) {
            return false;
        }

        return filemtime((string) $storage) < $time;
    }

    public function setTemplatePathPatterns($templatePathPatterns)
    {
        $this->templatePathPatterns = $templatePathPatterns;
    }

    public function addTemplatePathPatterns($templatePath)
    {
        $this->templatePathPatterns[] = $templatePath;
    }
}
