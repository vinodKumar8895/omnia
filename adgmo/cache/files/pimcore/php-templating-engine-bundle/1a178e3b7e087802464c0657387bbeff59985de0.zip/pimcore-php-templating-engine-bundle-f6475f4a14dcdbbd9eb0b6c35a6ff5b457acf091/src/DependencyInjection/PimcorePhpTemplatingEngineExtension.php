<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\DependencyInjection;

use Pimcore\HttpKernel\Config\FileLocator as PimcoreFileLocator;
use Pimcore\Templating\PhpEngine;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\Config\Resource\FileExistenceResource;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Loader;
use Symfony\Component\DependencyInjection\Reference;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\Stopwatch\Stopwatch;

class PimcorePhpTemplatingEngineExtension extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        if (!$this->isConfigEnabled($container, $config)) {
            return;
        }

        if (!class_exists('Symfony\Component\Templating\PhpEngine')) {
            throw new LogicException('Templating support cannot be enabled as the Templating component is not installed. Try running "composer require symfony/templating".');
        }

        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.yml');

        $this->registerTemplatingConfiguration($config, $container, $loader);
        $this->registerTemplatingPaths($config, $container);
    }

    private function registerTemplatingConfiguration(array $config, ContainerBuilder $container, Loader\FileLoader $loader)
    {
        $loader->load('templating.yml');
        $loader->load('aliases.yml');

        $engines = array_map(static function ($engine) {
            return new Reference('pimcore.templating.engine.'.$engine);
        }, $config['engines']);

        $templateEngineDefinition = $container->getDefinition('pimcore.templating.engine.delegating');
        foreach ($engines as $engine) {
            $templateEngineDefinition->addMethodCall('addEngine', [$engine]);
        }
        $templateEngineDefinition->addMethodCall('setDelegate', [true]);
        $container->setAlias('pimcore.templating', 'pimcore.templating.engine.delegating')->setPublic(true);

        // configure the PHP engine if needed
        if (\in_array('php', $config['engines'], true)) {
            $loader->load('templating_php.yml');
            $loader->load('templating_php_aliases.yml');

            $container->setParameter('templating.helper.form.resources', $config['form']['resources']);

            if ($container->getParameter('kernel.debug') && class_exists(Stopwatch::class)) {
                $loader->load('templating_debug.yml');

                $container->setDefinition('pimcore.templating.engine.php', $container->findDefinition('pimcore.debug.templating.engine.php'));
                $container->setAlias('pimcore.debug.templating.engine.php', 'pimcore.templating.engine.php')->setPrivate(true);
            } else {
                $container->setDefinition('pimcore.templating.engine.php', $container->findDefinition(PhpEngine::class));
            }

            if ($container->has('assets.packages')) {
                $container->getDefinition('templating.helper.assets')->replaceArgument(0, new Reference('assets.packages'));
            } else {
                $container->removeDefinition('templating.helper.assets');
            }
        }
    }

    private function registerTemplatingPaths(array $config, ContainerBuilder $container)
    {
        $templatePaths = [
            $config['default_path'], //configurable default path for templates
            '%kernel.project_dir%/app/Resources/views' //for BC reasons
        ];

        $templatePaths = array_merge($templatePaths, $this->getBundleTemplatePaths($container, $config));
        $fileSystemLoaderDef = $container->getDefinition(PimcoreFileLocator::class);
        $fileSystemLoaderDef->replaceArgument(2, $templatePaths);
    }

    private function getBundleTemplatePaths(ContainerBuilder $container, array $config)
    {
        $bundleHierarchy = [];
        foreach ($container->getParameter('kernel.bundles_metadata') as $name => $bundle) {
            $defaultOverrideBundlePath = $container->getParameterBag()->resolveValue($config['default_path']).'/bundles/'.$name;
            if (file_exists($defaultOverrideBundlePath)) {
                $bundleHierarchy[$name] = $defaultOverrideBundlePath;
            }
            $container->addResource(new FileExistenceResource($defaultOverrideBundlePath));

            //for Bc reasons
            if (file_exists($dir = $bundle['path'].'/Resources/views')) {
                $namespace = $this->normalizeBundleName($name);
                $bundleHierarchy[$namespace] = $dir;
            }
            $container->addResource(new FileExistenceResource($dir));
        }

        return $bundleHierarchy;
    }

    private function normalizeBundleName($name)
    {
        if ('Bundle' === substr($name, -6)) {
            $name = substr($name, 0, -6);
        }

        return $name;
    }
}
