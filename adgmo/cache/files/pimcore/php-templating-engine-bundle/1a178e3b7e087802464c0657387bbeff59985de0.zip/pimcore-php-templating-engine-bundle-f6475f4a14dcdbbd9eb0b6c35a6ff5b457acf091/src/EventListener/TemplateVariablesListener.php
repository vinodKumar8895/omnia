<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\EventListener;

use Pimcore\Bundle\CoreBundle\EventListener\Traits\PimcoreContextAwareTrait;
use Pimcore\Http\Request\Resolver\DocumentResolver;
use Pimcore\Http\Request\Resolver\EditmodeResolver;
use Pimcore\Http\Request\Resolver\PimcoreContextResolver;
use Pimcore\Http\Request\Resolver\ViewModelResolver;
use Pimcore\Templating\Model\ViewModelInterface;
use Psr\Log\LoggerAwareInterface;
use Psr\Log\LoggerAwareTrait;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\Event\ViewEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class TemplateVariablesListener implements EventSubscriberInterface, LoggerAwareInterface
{
    use LoggerAwareTrait;
    use PimcoreContextAwareTrait;

    /**
     * @var DocumentResolver
     */
    protected $documentResolver;

    /**
     * @var EditmodeResolver
     */
    protected $editmodeResolver;

    /**
     * @var ViewModelResolver
     */
    protected $viewModelResolver;

    /**
     * @var array
     */
    protected $globalsStack = [];

    public function __construct(
        DocumentResolver $documentResolver,
        EditmodeResolver $editmodeResolver,
        ViewModelResolver $viewModelResolver
    ) {
        $this->documentResolver = $documentResolver;
        $this->editmodeResolver = $editmodeResolver;
        $this->viewModelResolver = $viewModelResolver;
    }

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents()
    {
        return [
            KernelEvents::CONTROLLER => ['onKernelController', 10],
            KernelEvents::VIEW => ['onKernelView', 20], //this should run before ControllerViewModelListener::onKernelView
        ];
    }

    public function onKernelController(ControllerEvent $event)
    {
        $request = $event->getRequest();
        if (!$this->matchesPimcoreContext($request, PimcoreContextResolver::CONTEXT_DEFAULT)) {
            return;
        }

        // update the view model on the current request if exists
        $viewModel = $this->viewModelResolver->getViewModel($request, true);
        if ($viewModel instanceof ViewModelInterface) {
            $document = $this->documentResolver->getDocument($request);
            $editmode = $this->editmodeResolver->isEditmode($request);

            $viewModel->getParameters()->set('document', $document);
            $viewModel->getParameters()->set('editmode', $editmode);
        }
    }

    /**
     * When action returns viewModel, set document and editmode vars
     *
     * @param ViewEvent $event
     */
    public function onKernelView(ViewEvent $event)
    {
        $request = $event->getRequest();

        $result = $event->getControllerResult();

        // update the view model on the current request if exists
        if ($result instanceof ViewModelInterface) {
            $document = $this->documentResolver->getDocument($request);
            $editmode = $this->editmodeResolver->isEditmode($request);

            $result->getParameters()->set('document', $document);
            $result->getParameters()->set('editmode', $editmode);
        }
    }
}
