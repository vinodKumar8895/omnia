<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\PhpTemplatingEngineBundle\Controller;

use Pimcore\Controller\FrontendController as BaseFrontendController;
use Pimcore\Controller\KernelControllerEventInterface;
use Pimcore\Controller\TemplateControllerInterface;
use Pimcore\Controller\Traits\TemplateControllerTrait;
use Pimcore\Http\Request\Resolver\ViewModelResolver;
use Pimcore\Model\Document;
use Pimcore\Templating\Model\ViewModel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ControllerEvent;

/**
 * @property ViewModel $view
 * @property Document|Document\PageSnippet $document
 * @property bool $editmode
 */
abstract class FrontendController extends BaseFrontendController implements KernelControllerEventInterface, TemplateControllerInterface
{
    use TemplateControllerTrait;

    public static function getSubscribedServices()
    {
        $services = parent::getSubscribedServices();
        $services[ViewModelResolver::class] = '?'.ViewModelResolver::class;

        return $services;
    }

    /**
     * Expose view, document and editmode as properties and proxy them to request attributes through
     * their resolvers.
     *
     * @inheritDoc
     */
    public function __get($name)
    {
        if ('view' === $name) {
            return $this->get(ViewModelResolver::class)->getViewModel();
        }

        return parent::__get($name);
    }

    public function __set($name, $value)
    {
        if ($name == 'view') {
            throw new \RuntimeException(sprintf(
                'Property "%s" is a request attribute and can\'t be set on the controller instance',
                $name
            ));
        }

        parent::__set($name, $value);
    }

    /**
     * @inheritDoc
     */
    public function onKernelControllerEvent(ControllerEvent $event)
    {
        // enable view auto-rendering
        $this->setViewAutoRender($event->getRequest(), true, 'php');
    }

    /**
     * Enable view autorendering for the current request
     *
     * @param Request $request
     * @param string $engine
     *
     */
    protected function enableViewAutoRender(Request $request = null, $engine = 'php')
    {
        if (null === $request) {
            $request = $this->get('request_stack')->getCurrentRequest();
        }

        $this->setViewAutoRender($request, true, $engine);
    }

    /**
     * Disable view autorendering for the current request
     *
     * @param Request $request
     *
     */
    protected function disableViewAutoRender(Request $request = null)
    {
        if (null === $request) {
            $request = $this->get('request_stack')->getCurrentRequest();
        }

        $this->setViewAutoRender($request, false);
    }

    /**
     * @param string $view
     * @param array $parameters
     * @param Response|null $response
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function renderTemplate($view, array $parameters = [], Response $response = null)
    {
        $viewModel = $this->get(ViewModelResolver::class)->getViewModel();
        $parameters = array_merge($viewModel->getAllParameters(), $parameters);

        return $this->render($view, $parameters, $response);
    }
}
