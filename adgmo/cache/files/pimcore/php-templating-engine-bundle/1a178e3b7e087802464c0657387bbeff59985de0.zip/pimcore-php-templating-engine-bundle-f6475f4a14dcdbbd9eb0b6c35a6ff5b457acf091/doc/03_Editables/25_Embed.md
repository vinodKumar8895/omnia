# Embed Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Embed.html)

## Example

```php
// Basic usage
<?= $this->embed("socialWidgets"); ?>
 
// Advanced usage
<?= $this->embed("socialWidgets", ["width" => 540]); ?>
```
