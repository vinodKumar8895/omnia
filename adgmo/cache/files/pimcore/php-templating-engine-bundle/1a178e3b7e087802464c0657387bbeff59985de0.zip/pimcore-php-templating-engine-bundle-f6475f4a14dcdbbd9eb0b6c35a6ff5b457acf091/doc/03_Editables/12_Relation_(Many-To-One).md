# Relation (Many-To-One) Editable
[Read More](https://pimcore.com/docs/pimcore/master/Development_Documentation/Documents/Editables/Relation_(Many-To-One).html)

## Examples

### Basic usage

You can just create the code line like, below:

```php
<?= $this->relation("myRelation"); ?>
```

After, the view in the administration panel changes like in the picture:

![Relation editable preview in the administration panel](../img/href_backend_preview.png)

### Using Restriction

If you want specify elements which could be assigned to the relation editable, use `types`, `subtypes` and `classes`
options in the editable configuration.

##### Example

```php
<?= $this->relation("myRelation", [
    "types" => ["asset","object"],
    "subtypes" => [
        "asset" => ["video","image"],
        "object" => ["object"]
     ],
    "classes" => ["person"],
]); ?>
```

We restricted the `myRelation` editable to the following entities: 
* Video / Image (Assets) 
* Person Objects (`\Pimcore\Model\DataObject\Person`) (Objects) 
 
As you see in the picture below, it's impossible to drop any other type to that editable.

![Relation restriction](../img/href_restriction_in_backend.png)

### Download Example

Another useful use-case for the relation editable is a download link. 

```php
<?php if ($this->editmode): ?>
    <?= $this->relation("myRelation"); ?>
<?php else: ?>
    <?php if ($this->relation("myRelation")->getElement() instanceof Asset): ?>
        <a href="<?= $this->relation("myRelation")->getFullPath() ?>"><?= $this->translate("Download") ?></a>
    <?php endif; ?>
<?php endif; ?>
```