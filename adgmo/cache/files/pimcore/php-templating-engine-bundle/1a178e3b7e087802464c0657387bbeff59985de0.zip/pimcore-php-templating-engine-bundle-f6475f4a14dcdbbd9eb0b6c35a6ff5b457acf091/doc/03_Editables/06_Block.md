# Block Editable
[Read More](https://pimcore.com/docs/pimcore/master/Development_Documentation/Documents/Editables/Block.html)

## Basic Usage

Please use the `getIterator()` method to iterate through all block elements. This makes sure the correct indices are set internally
to reference the right elements within a block.


```php
<?php foreach($this->block("contentblock")->getIterator() as $blockItem) { ?>
    <h2><?= $this->input("subline"); ?></h2>
    <?= $this->wysiwyg("content"); ?>
<?php } ?>
```


The result in editmode should looks like to following: 
![Block in editmode](../img/block_editmode.png)

And in the frontend of the application:
![Block in the frontend](../img/block_frontend_preview.png)

## Advanced Usage
### Advanced Usage with Different Includes.

```php
<?php foreach($this->block("contentblock")->getIterator() as $blockItem) { ?>
    <?php if($this->editmode) { ?>
        <?= $this->select("blocktype", [
            "store" => [
                ["wysiwyg", "WYSIWYG"],
                ["contentimages", "WYSIWYG with images"],
                ["video", "Video"]
            ],
            "reload" => true
        ]); ?>
    <?php } ?>
     
    <?php if(!$this->select("blocktype")->isEmpty()) {
        $this->template("content/blocks/".$this->select("blocktype")->getData().".php");
    } ?>
<?php } ?>
 
<?php foreach($this->block("teasers", ["limit" => 2])->getIterator() as $blockItem) { ?>
    <?= $this->snippet("teaser") ?>
<?php } ?>
```

### Example for `getCurrent()`
```php
<?php foreach ($this->block("myBlock")->getIterator() as $blockItem) { ?>
    <?php if ($this->block("myBlock")->getCurrent() > 0) { ?>
        Insert this line only after the first iteration<br />
        <br />
    <?php } ?>
    <h2><?= $this->input("subline"); ?></h2>
     
<?php } ?>
```

### Using Manual Mode

The manual mode offers you the possibility to deal with block the way you like, this is for example useful with tables: 


```php
<?php $block = $this->block("gridblock", ["manual" => true])->start(); ?>
<table>
    <tr>
        <?php while ($block->loop()) { ?>
            <?php $block->blockConstruct(); ?>
                <td customAttribute="<?= $this->input("myInput")->getData() ?>">
                    <?php $block->blockStart(); ?>
                        <div style="width:200px; height:200px;border:1px solid black;">
                            <?= $this->input("myInput"); ?>
                        </div>
                    <?php $block->blockEnd(); ?>
                </td>
            <?php $block->blockDestruct(); ?>
        <?php } ?>
    </tr>
</table>
<?php $block->end(); ?>
```

### Using Manual Mode with custom button position

If you want to wrap buttons in a div or change the Position.

```php
<?php $block = $this->block("gridblock", ["manual" => true])->start(); ?>
<table>
    <tr>
        <?php while ($block->loop()) { ?>
            <?php $block->blockConstruct(); ?>
                <td customAttribute="<?= $this->input("myInput")->getData() ?>">
                    <?php $block->blockStart('false'); ?>
                        <div style="background-color: #fc0; margin-bottom: 10px; padding: 5px; border: 1px solid black;">
                            <?php $block->blockControls(); ?>
                        </div>
                        <div style="width:200px; height:200px;border:1px solid black;">
                            <?= $this->input("myInput"); ?>
                        </div>
                    <?php $block->blockEnd(); ?>
                </td>
            <?php $block->blockDestruct(); ?>
        <?php } ?>
    </tr>
</table>
<?php $block->end(); ?>
```


### Accessing Data Within a Block Element

Bricks and structure refer to the CMS demo (content/default template).

```php
<?php
// load document
$document = \Pimcore\Model\Document\Page::getByPath('/en/basic-examples/galleries');
 
// Bsp #1 | get the first picture from the first "gallery-single-images" brick
$image = $document
    ->getElement('content')                             // view.html.php > $this->areablock('content')
        ->getElement('gallery-single-images')[0]        // get the first entry for this brick
            ->getBlock('gallery')->getElements()[0]     // view.html.php > $this->block("gallery")->loop()
                ->getImage('image')                     // view.html.php > $this->image("image")
;
 
 
var_dump("Bsp #1: " . $image->getSrc());
```
