# Numeric Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Numeric.html)                                   |

## Examples

### Basic Usage
```php
<?= $this->numeric("myNumber"); ?>
```

Now you can see the **numeric** value in the editmode view 
![Numeric input - editmode](../img/editables_numeric_simple_editmode.png)

### Advanced Usage

In the following example we're going to use a minimal and maximum value as well as a decimal precision. 

```php
<?= $this->numeric("myNumber", [
    "width" => 300,
    "minValue" => 0,
    "maxValue" => 100,
    "decimalPrecision" => 0
]); ?>
```
To display the number also in editmode, you can use the method `getData()`

```php
<p>
    <?= $this->numeric("myNumber")->getData(); ?>
</p>
```
