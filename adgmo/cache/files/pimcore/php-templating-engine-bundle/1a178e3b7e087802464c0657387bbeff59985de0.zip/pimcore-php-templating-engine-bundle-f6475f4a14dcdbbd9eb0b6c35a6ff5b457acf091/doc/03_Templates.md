# Templating

Pimcore's default implementations default to the Twig templating engine, but you
can easily change the default behaviour when you use template auto-discovery from your controllers. If
you use `@TemplatePhp` annotations or directly create a response via `$this->render()`, you can already just
reference a Php template.

//@TODO 
If you use the Pimcore's default [FrontendController](https://github.com/pimcore/pimcore/blob/master/lib/Controller/FrontendController.php),
it will set a special attribute on the request which mimics the [@Template](https://symfony.com/doc/3.0/bundles/SensioFrameworkExtraBundle/annotations/view.html)
annotation and tries to auto-render a view with the same name as the controller action if the controller does not return
a response (see [TemplateControllerInterface](https://github.com/pimcore/pimcore/blob/master/lib/Controller/TemplateControllerInterface.php)
for details). As this call defaults to Twig, you need to change this to Twig in order to automatically use Twig in your 
controllers:

```php
<?php

namespace AppBundle\Controller;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Controller\FrontendController;
use Symfony\Component\HttpKernel\Event\ControllerEvent;

class MyController extends FrontendController
{
    public function onKernelController(ControllerEvent $event)
    {
        // set auto-rendering to twig
        $this->setViewAutoRender($event->getRequest(), true, 'php');
    }
    
    /**
     * This action will automatically render MyController/myAction.html.php as
     * auto-rendering was enabled above.
     */
    public function myAction()
    {
        $this->view->foo = 'bar';
    }
}
```

Alternatively, just use annotations or render the view directly to use twig:

```php
<?php

namespace AppBundle\Controller;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Controller\FrontendController;
use Pimcore\Controller\Configuration\TemplatePhp;

class MyController extends FrontendController
{
    /**
     * The annotation will automatically resolve the view to MyController/myAnnotatedAction.html.php
     * 
     * @TemplatePhp() 
     */
    public function myAnnotatedAction()
    {   
    }
    
    public function directRenderAction()
    {
        return $this->render('my/custom/action.html.php', ['param1' => 'value1']);
    }
}
```

Of course, you can just set a custom template for Pimcore documents in the admin interface and that
template will be used for auto-rendering when the controller does not return a response.

### Pimcore editables

You can use any Pimcore document editable in Php by calling it with `$this->` and using the same arguments as in PHP:

```php
<h1><?= $this->input('headline') ?></h1>

<?= $this->wysiwyg('content') ?>

<?= $this->select('type', ['reload' => true, 'store' => [["video","video"], ["image","image"]]]) ?>
```

#### Subrequests

The following PHP templating view helpers are used to render subrequests:

* `$this->inc`
* `$this->action`


```php
<?php
//render an action
echo $this->action('App\Controller\FooController::barAction', [ 'items' => 'count' ]);


//include another document
echo $this->inc('/snippets/foo');
```

See [Templating Helpers](./04_Templating_Helpers) for details.
