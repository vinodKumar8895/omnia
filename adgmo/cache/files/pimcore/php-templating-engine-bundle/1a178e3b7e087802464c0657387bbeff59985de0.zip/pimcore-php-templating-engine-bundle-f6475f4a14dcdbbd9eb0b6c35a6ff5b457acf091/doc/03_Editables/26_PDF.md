# PDF Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/PDF.html)

## Examples

### Basic usage

```php
<div class="code-section">
    <div class="pdf">
        <?= $this->pdf("myPdf", ["width" => 640]); ?>
    </div>
</div>    
```

This looks like the following in editmode: 

![PDF editable - the empty area](../img/editables_pdf_empty_container.png)

A user can now drag documents there from the *Assets* tree:

![PDF editable - drag a document](../img/editables_pdf_filled.png)

