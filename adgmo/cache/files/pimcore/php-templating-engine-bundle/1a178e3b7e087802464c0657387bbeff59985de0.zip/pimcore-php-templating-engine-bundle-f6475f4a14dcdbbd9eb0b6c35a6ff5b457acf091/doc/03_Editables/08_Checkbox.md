# Checkbox Editable
[Read More](https://pimcore.com/docs/pimcore/master/Development_Documentation/Documents/Editables/Checkbox.html)

## Simple Example
```php
<?= $this->checkbox("myCheckbox"); ?>
```

## Advanced Example
```php
Setting XYZ: <?= $this->checkbox("myCheckbox"); ?>

<?php if($this->checkbox("myCheckbox")->isChecked()): ?>
    <div>
        <?php //do something... ?>
    </div>
<? endif; ?>
```