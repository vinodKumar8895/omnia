# Date Editable
[Read More](https://pimcore.com/docs/pimcore/master/Development_Documentation/Documents/Editables/Date.html)

## Simple Example

The following code will create a simple date widget in editmode. 
In frontend it will format the date as defined in `format`.

Localization (output-format, ...) is automatically used from the globally registered locale.
Please read the topic [Localization](https://pimcore.com/docs/pimcore/current/Development_Documentation/Multi_Language_i18n/index.html).

```php
<?= $this->date('date', [
    'format' => 'd m Y',
    'outputFormat' => '%d.%m.%Y'
]); ?>
```
