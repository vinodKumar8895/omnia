# Textarea Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Textarea.html)

## Example

```php
<p class="product-description">
    <?= $this->textarea("product_description", [
        "nl2br" => true,
        "height" => 300,
        "placeholder" =>
            "Product Description"
    ]); ?>
</p>
```

In the editmode, you can see the textarea and the predefined `placeholder`.
 
![Product description textarea - editmode](../img/editable_textarea_editmode_preview.png)


