# Image Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Image.html)

## Examples

### Basic usage
```php
<?= $this->image("myImage"); ?>
```

The code above generates an image area in the backend and displays the image at the frontend.

The empty backend area:
![Empty image area](../img/image_preview_backend1.png)

The filled backend area:
![Filled image area](../img/image_preview_backend2.png)


### Advanced Usage
In the example below you can see how to add a title and specify size of the image area.
Note that if you use the thumbnail argument, the rendered image on the frontend will use the specified thumbnail. 

Learn more about thumbnails here: [Image Thumbnails](https://pimcore.com/docs/pimcore/current/Development_Documentation/Assets/Working_with_Thumbnails/Image_Thumbnails.html).

```php
<?= $this->image("myImage", [
    "title" => "Drag your image here",
    "width" => 200,
    "height" => 200,
    "thumbnail" => "contentimages"
]); ?>
```

###### Backend Preview

![Image with title and specified size - the backend preview](.../img/image_preview_backend3.png)

### An Example with a Direct Thumbnail Configuration

You can also change the thumbnail configuration:

```php
<?= $this->image("myImage", [
    "title" => "Drag your image here",
    "width" => 200,
    "height" => 200,
    "thumbnail" => [
        "width" => 200,
        "height" => 200,
        "interlace" => true,
        "quality" => 90
    ]
]); ?>
```


### An Example Using Custom Attributes
```php
<?= $this->image("myImage", [
    "thumbnail" => "content",
    "attributes" => [
        "custom-attr" => "value",
        "data-role" => "image"
    ]
]) ?>
```

And this is how the rendered html looks: `<img custom-attr="value" data-role="image" src="/var/tmp/image-thumbnails/0/56/thumb__content/dsc03807.jpeg" />`

### Other Advanced Examples
```php

// get retina image
<?= $this->image("myImage", [
    "thumbnail" => [
        "width" => 200,
        "height" => 200
    ],    
    "highResolution" => 2
]); ?>


// will output<img src="/var/thumb_9999__auto_xxxxxxxx@2x.png" width="200" height="200" /> <!-- but the real image size is 400x400 pixel -->

// custom image tag (thumbnail objects)
<?php if($this->editmode): ?>
    <?= $this->image("myImage", ["thumbnail" => "myThumbnail"]); ?>
<?php else: ?>
    <?php $thumbnail = $this->image("myImage")->getThumbnail("myThumbnail"); ?>
    <img src="<?= $thumbnail; ?>" width="<?= $thumbnail->getWidth(); ?>" height="<?= $thumbnail->getHeight(); ?>" data-custom="xxxx" />
<?php endif; ?>
 
 
// disable automatic width and height attributes
<?= $this->image("myImage", [
    "thumbnail" => "exampleScaleWidth",
    "disableWidthHeightAttributes" => true
]) ?>
  
// custom drop targets
<div class="myCustomImageDropTarget anotherClass">My first alternative drop target</div>
<?= $this->image("image", [
    "thumbnail" => "contentfullimage",
    "dropClass" => "myCustomImageDropTarget"
]) ?>
<div class="myCustomImageDropTarget someClass">My second alternative drop target</div>
```

## Field-specific Image Cropping for Documents

### Backend Usage

Right-click on the image editable in editmode and press *Select specific area of image* 
![image options in the editmode](../img/image_preview_backend_modification.png)

Now you're able to select the desired area on the image: 
![image cropping in the editmode](../img/image_preview_backend_modification2.png)

Therefore, there is no need any more to define specific images or thumbnails if a specific region of an image should be displayed. 
Just assign the original image and define field specific cropping directly within the document.

## Markers & Hotspots

This functionality is available on every image editable (no configuration necessary).

Setting a marker or a hotspot on an image has no direct effect on the output, the assigned image is displayed as usual.

![Image hotspots and markers](../img/image_preview_backend_hotspots.png)

You as a developer have to get the data out of the image editable to build amazing frontends with it.

You can get the data with the methods `getMarker()` and `getHotspots()`. 
All dimensions are in percent and therefore independent from the image size, you have to change them back to pixels according to your image size.
 
### Code Usage Example

```php
<div>
 <p>
        <?= $this->image("myImage", [
            "title" => "Drag your image here",
            "width" => 400,
            "height" => 400,
            "thumbnail" => "content",
            /* 
            //adds predefined config sets
            "predefinedDataTemplates" => [
                            "marker" => [
                                [
                                    "menuName" => "marker config 1",
                                    "name" => "marker name",
                                    "data" => [
                                        [
                                            "name" => "my textfield",
                                            "type" => "textfield"
                                        ],
                                        [
                                            "name" => "my asset href",
                                            "type" => "asset",
                                            "value" => "/testimage1.jpg"
                                        ]
                                    ]
                                ]
                            ],
                            "hotspot" => [
                                [
                                    "menuName" => "hotspot config 1",
                                    "name" => "hotspot name",
                                    "data" => [
                                        [
                                            "name" => "my textfield",
                                            "type" => "textfield"
                                        ],
                                        [
                                            "name" => "my asset href",
                                            "type" => "asset",
                                            "value" => "/testimage1.jpg"
                                        ]
                                    ]
                                ]
                            ]
                        ]*/
        ]); ?>
        
        <?php if(!$this->editmode): ?>
            <?php
            // outside the editmode: do something with the data
            if($this->image("myImage")->getHotspots()) {
                dump($this->image("myImage")->getHotspots());
            }
            if($this->image("myImage")->getMarker()) {
                dump($this->image("myImage")->getMarker());
            }
            ?>
        <?php endif; ?>
 </p>
</div>
```

`getHotspots` output:

```
array(1) {
  [0] => array(6) {
    ["top"] => float(36.8)
    ["left"] => float(39.5)
    ["width"] => int(5)
    ["height"] => float(6.6666666666667)
    ["data"] => array(2) {
      [0] => object(Pimcore\Model\Element\Data\MarkerHotspotItem)#171 (3) {
        ["name"] => string(30) "checkbox_data_added_to_hotspot"
        ["type"] => string(8) "checkbox"
        ["value"] => bool(true)
      }
      [1] => object(Pimcore\Model\Element\Data\MarkerHotspotItem)#172 (3) {
        ["name"] => string(28) "object_data_added_to_hotspot"
        ["type"] => string(6) "object"
        ["value"] => int(6)
      }
    }
    ["name"] => NULL
  }
}
```


`getMarker` output:

```
array(1) {
  [0] => array(4) {
    ["top"] => float(35.466666666667)
    ["left"] => float(69.9)
    ["data"] => array(1) {
      [0] => object(Pimcore\Model\Element\Data\MarkerHotspotItem)#173 (3) {
        ["name"] => string(31) "Textarea data added to the marker"
        ["type"] => string(8) "textarea"
        ["value"] => string(38) "Here is a description of marked place."
      }
    }
    ["name"] => NULL
  }
}
```

