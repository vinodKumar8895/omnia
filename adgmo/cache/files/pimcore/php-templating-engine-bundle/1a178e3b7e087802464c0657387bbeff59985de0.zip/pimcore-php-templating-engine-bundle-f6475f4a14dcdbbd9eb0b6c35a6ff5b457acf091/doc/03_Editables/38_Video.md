# Video Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Video.html)

## Examples

### Basic Usage - a Local Asset

To create a container for local video files you can just use the `$this->video` helperwithout any options.

```php
<section id="campaign_video">
    <?= $this->video("campaignVideo", [
        "width" => 700,
        "height" => 400
    ]); ?>
</section>
```

In the editmode, there is now a container available where you can assign an asset path and a video poster. 

![Video editable window - editmode](../img/editables_video_localtype_editmode.png)


### YouTube, Vimeo & Dailymotion

You can use videos from external services, as well (at the moment, YouTube, Vimeo and Dailymotion) but with limited functionalities. 
In the video edit dialog, change the type to `youtube` and fill the **ID** input with a video identifier or the video URL.
(in that case you can easily find it in the url). Youtube playlists are supported as well - you can identify them by the prefix `PL` in the **ID**.

![Video editable - YouTube configuration - editmode](../img/editables_video_youtube_editmode.png)

Have a look at the frontend preview:
 
![Video editable - YouTube configuration - frontend](../img/editables_video_youtube_frontend.png)

In the configuration, you could also specify additional options for external services.
```php
<section id="campaign_video">
    <?= $this->video("campaignVideo", [
        "width" => 700,
        "height" => 400,
        "youtube" => [
            "autoplay" => 1,
            "modestbranding" => 1
        ],
        "vimeo" => [
            "autoplay" => 1,
            "loop" => 1
        ]
    ]); ?>
</section>
```

### HTML5 with Automatic Video Transcoding (using video.js)
```php
<!DOCTYPE HTML>
<html>
<head>
    <link href="http://vjs.zencdn.net/5.4.4/video-js.css" rel="stylesheet">
</head>
<body>
 
    <?= $this->video("myVideo", array(
        "thumbnail" => "example", // NOTE: don't forget to create a video thumbnail
        "width" => 400,
        "height" => 300,
        "attributes" => ["class" => "video-js custom-class", "preload" => "auto", "controls" => "", "data-custom-attr" => "my-test"]
    )); ?>
 
    <script src="http://vjs.zencdn.net/5.4.4/video.js"></script>
</body>
</html>
```

Read more about [Video Thumbnails](https://pimcore.com/docs/pimcore/current/Development_Documentation/Assets/Working_with_Thumbnails/Video_Thumbnails.html).

