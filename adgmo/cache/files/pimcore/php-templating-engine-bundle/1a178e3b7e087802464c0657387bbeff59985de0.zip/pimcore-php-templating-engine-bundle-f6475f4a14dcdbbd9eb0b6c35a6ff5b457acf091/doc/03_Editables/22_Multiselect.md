# Multiselect Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Multiselect.html)

## Example

The code below renders a multiselectbox in the backend. 
Also, it shows the list of chosen elements in the frontend. 

```php
<?php if($this->editmode): ?>
    <?= $this->multiselect("categories", [
        "width" => 200,
        "height" => 100,
        "store" => [
            ["cars", "Cars"], //the first array element is a key, the second is a label rendered in editmode
            ["motorcycles", "Motorcycles"],
            ["accessories", "Accessories"] 
        ]
    ]) ?>
<?php else: ?>
    <p><?= $this->translate("This page is linked to"); ?>:
        <?php foreach($this->multiselect("categories")->getData() as $categoryKey): ?>
            <span>
                <?= $this->translate($categoryKey); ?>
            </span>
        <?php endforeach; ?>
        categories
    </p>
<?php endif; ?>
```

The editmode preview:

![Multiselect editable - editmode](../img/editables_multiselect_editmode.png)

In the frontend you can find the rendered text with the categories you have chosen in the editmode: 

![Multiselect editable - frontend](../img/editables_multiselect_frontend.png)
