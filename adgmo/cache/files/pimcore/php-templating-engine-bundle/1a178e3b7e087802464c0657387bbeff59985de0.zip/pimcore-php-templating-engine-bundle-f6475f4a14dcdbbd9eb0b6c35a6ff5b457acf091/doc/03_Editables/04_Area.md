# Area Editable
[Read More](https://pimcore.com/docs/pimcore/master/Development_Documentation/Documents/Editables/Area.html)

## Example
```php
<div>
    <?= $this->area('myArea', ['type' => 'gallery-single-images']); ?>
</div>
```


## Example with Parameters

<div class="code-section">

```php
<div>
    <?= $this->area('myArea', [
        'type' => 'gallery-single-images',
        'params' => [
            'gallery-single-images' => [
                'param1' => 123,
                "forceEditInView" => true,
                "editWidth" => "800px",
                "editHeight" => "500px"
            ]
        ]
    ]); ?>
</div>
```

</div>

Get the params in your brick:

```php
<div>
    <?= $this->param1; ?>
</div>
```

### Accessing Data Within an Area Element

Assuming your area uses a brick `gallery-single-images` which contains a `gallery` block (see CMS demo):

```php
<?php
// load document
$document = \Pimcore\Model\Document\Page::getByPath('/en/basic-examples/galleries');

/** @var \Pimcore\Model\Document\Editable\Area $area */
$area = $document->getEditable('myArea');

/** @var \Pimcore\Model\Document\Editable\Block $block */
$block = $area->getElement('gallery');
?>
```

See [Block](./06_Block.md) for an example how to get elements from a block editable.
