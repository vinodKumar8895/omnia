# Link Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Link.html)

## Examples

### Basic Usage
```php
<p>
    <?= $this->translate("Visit our"); ?> 
    <?= $this->link("blogLink"); ?>
</p>
```

You could see the backend preview in the picture, below.

![Link editable - adminitration panel](../img/editables_link_backend_preview.png)

And the frontend:

![Link editable - frontend](../img/editables_link_frontend_preview.png)



### Use Link in the Block Editable

Let's see how to make a list of links with [Block](./06_Block.md).

```php
<h3><?= $this->translate("Useful links"); ?></h3>
<ul>
    <?php while ($this->block("linkblock")->loop()): ?>
        <li>
            <?= $this->link("myLink", ["class" => "special-link-class"]); ?>
        </li>
    <?php endwhile; ?>
</ul>
```

The above example renders a list of links: 
![The links list in the backend](../img/editables_link_inside_block.png)





