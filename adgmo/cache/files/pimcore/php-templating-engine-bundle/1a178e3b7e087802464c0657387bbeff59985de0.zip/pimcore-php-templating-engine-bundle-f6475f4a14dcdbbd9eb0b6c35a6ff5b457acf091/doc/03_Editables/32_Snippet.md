# Snippet Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Snippet.html)

## Examples
### Basic Usage

```php
 // Define a place for a snippet to be dragged onto, advanced usage
 <?= $this->snippet("mySnippet", ["width" => 250, "height" => 100]) ?>
```


### Caching 

By default caching is disabled. 
You can enable snippet caching by passing the configuration `cache: true` or 
by enabling the full page cache. 
Regardless if you're using the full page cache or not it's a good practice to
enable the cache directly on the editable if the snippet result should be cached. 

```php
 // Define a place for a snippet to be dragged onto, advanced usage
 <?= $this->snippet("mySnippet", ["cache" => true]) ?>
```
