# Scheduled Block Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Scheduled_Block.html)

## Basic Usage

Please use the `loop()` method to iterate through all block items. This makes sure the correct indices are set internally
to reference the right elements within a block.

```php
<?php while($this->scheduledblock("block")->loop()) { ?>
    <h2><?= $this->input("blockinput") ?><h2>
    <?= $this->image("myimage") ?>
<?php } ?>
```

The result in editmode should looks like to following: 
![Scheduled Block in editmode](../img/scheduledblock_editmode.jpg)

And in the frontend of the application:
![Scheduled Block in the frontend](../img/scheduledblock_preview.jpg)


In document preview, Pimore provides a time slider to get the preview for a certain time as soon as 
the document has at least one scheduled block editable. 

For details on how to create custom functionality using the time slider see 
[Preview Scheduled Content](https://pimcore.com/docs/pimcore/master/Development_Documentation/Development_Tools_and_Details/Preview_Scheduled_Content.html).
