# Input Editable
[Read More](https://pimcore.com/docs/pimcore/current/Development_Documentation/Documents/Editables/Input.html)

## Example 

### Basic usage 

```php
<h2>
 <?= $this->input("myHeadline"); ?>
</h2>
```


The above code generates an editable area which you can fill with the text, see:
![Inpute preview in the backend](../img/input_backend_preview.png)

### Advanced usage

You could also specify other parameters, like the size:

```php
<h2>
    <?= $this->input("myHeadline", ["width" => 540]); ?>
</h2>
```

