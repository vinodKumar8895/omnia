# Pimcore Php Templating Engine Bundle

This Bundle enables PHP templating engine along with Twig (Pimcore's default), which allows usage of Php templates on Pimcore 10 or higher versions. 

Pimcore's default implementations default to the Twig templating engine, but you
can easily change the default behaviour when you use template auto-discovery from your controllers. If
you use `@TemplatePhp` annotations or directly create a response via `$this->render()`, you can already just
reference a Php template.

If you use this bundle [FrontendController](./src/Controller/FrontendController.php),
it will set a special attribute on the request which mimics the [@Template](https://symfony.com/doc/5.0/bundles/SensioFrameworkExtraBundle/annotations/view.html)
annotation and tries to auto-render a view with the same name as the controller action if the controller does not return
a response (see [TemplateControllerInterface](./src/Pimcore/Controller/TemplateControllerInterface.php)
for details). As this call defaults to Twig, you need to change this to Php in order to automatically use Php in your controllers:

```php
<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpKernel\Event\ControllerEvent;

class MyController extends \Pimcore\Bundle\PhpTemplatingEngineBundle\Controller\FrontendController
{
    public function onKernelController(ControllerEvent $event)
    {
        // set auto-rendering to php
        $this->setViewAutoRender($event->getRequest(), true, 'php');
    }
    
    /**
     * This action will automatically render MyController/myAction.html.php as
     * auto-rendering was enabled above.
     */
    public function myAction()
    {
        $this->view->foo = 'bar';
    }
}
```

Alternatively, just use annotations or render the view directly to use twig:

```php
<?php

namespace AppBundle\Controller;

use Pimcore\Bundle\PhpTemplatingEngineBundle\Controller\FrontendController;
use Pimcore\Controller\Configuration\TemplatePhp;

class MyController extends FrontendController
{
    /**
     * The annotation will automatically resolve the view to MyController/myAnnotatedAction.html.php
     * 
     * @TemplatePhp() 
     */
    public function myAnnotatedAction()
    {   
    }
    
    public function directRenderAction()
    {
        return $this->render('my/custom/action.html.php', ['param1' => 'value1']);
    }
}
```

Of course, you can just set a custom template for Pimcore documents in the admin interface and that
template will be used for auto-rendering when the controller does not return a response.

### Pimcore editables
The editables are placeholders in the templates, which are displayed as input widgets in the admin interface (so called editmode) and output the content in frontend mode.
They are the essential part of managing content in documents. 

You can use Pimcore editable in Php templates by calling it with `$this` scope and using the same arguments as in Twig:

```php
<h1><?= $this->input('headline') ?></h1>

<?= $this->wysiwyg('content') ?>

<?= $this->select('type', ['reload' => true, 'store' => [["video","video"], ["image","image"]]]) ?>
```
See [Editables](doc/03_Editables/README.md) page fore details and related examples.

> **IMPORTANT** 
> If you are using block editable with `loop()` method in while to iterate through block elements, then please adapt to new method `getIterator()` with foreach or for.
> e.g.,
```php
//old way
<?php while($this->block("contentblock")->loop()) { ?>
    <h2><?= $this->input("subline"); ?></h2>
    <?= $this->wysiwyg("content"); ?>
<?php } ?>
```
change to:
```php
//new way
<?php foreach($this->block("contentblock")->getIterator() as $blockItem) { ?>
    <h2><?= $this->input("subline"); ?></h2>
    <?= $this->wysiwyg("content"); ?>
<?php } ?>
```

### Area bricks
For bricks template auto-discovery to work php templates either extend brick class from `Pimcore\Bundle\PhpTemplatingEngineBundle\Extension\Document\Areabrick\AbstractTemplateAreabrick` or add method to your brick class:

```php
<?php
// src/Document/Areabrick/myBrick.php
    /**
     * {@inheritdoc}
     */
    public function getTemplateSuffix()
    {
        return 'html.php';
    }

?>
```

#### Subrequests

The following PHP templating view helpers are used to render subrequests:

* `$this->inc`
* `$this->action`


```php
<?php
//render an action
echo $this->action('App\Controller\FooController::barAction', [ 'items' => 'count' ]);


//include another document
echo $this->inc('/snippets/foo');
```

See [Templating Helpers](./doc/04_Templating_Helpers) for details.


## Further Information
- [Controller](./doc/00_Controller.md)
- [Layouts](./doc/01_Layouts.md)
- [Templating Helpers](./doc/04_Templating_Helpers)

