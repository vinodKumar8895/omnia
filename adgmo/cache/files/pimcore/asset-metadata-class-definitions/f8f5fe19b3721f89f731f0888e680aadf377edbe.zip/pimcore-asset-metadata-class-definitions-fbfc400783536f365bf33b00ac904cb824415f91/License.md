# License
Copyright (C) Pimcore GmbH

This software is available under following license: 

## Pimcore Commercial License (PCL)
Commercial and supported versions of the program - also known as
Commercial Distributions - must be used in accordance with the terms and conditions
contained in a separate written agreement between you and Pimcore GmbH.
For more information about the Pimcore Commercial License (PCL) please contact info@pimcore.com.
