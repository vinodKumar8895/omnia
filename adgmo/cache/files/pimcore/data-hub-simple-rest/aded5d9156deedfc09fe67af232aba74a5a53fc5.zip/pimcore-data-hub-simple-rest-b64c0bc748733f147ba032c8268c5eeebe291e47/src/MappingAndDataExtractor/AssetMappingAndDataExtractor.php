<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Model\Asset;
use Pimcore\Model\Element\ElementInterface;

class AssetMappingAndDataExtractor extends AbstractMappingAndDataExtractor
{
    protected $type = 'asset';

    public function extractMapping(): array
    {
        $systemDataMapping = $this->createSystemAttributesMapping();
        $systemDataMapping['properties']['checksum'] = ['type' => 'keyword'];
        $systemDataMapping['properties']['mimeType'] = ['type' => 'keyword'];
        $systemDataMapping['properties']['fileSize'] = ['type' => 'integer'];
        $systemDataMapping['properties']['versionCount'] = ['type' => 'integer'];

        $data = [

            'system' => $systemDataMapping,

            'dimensionData' => [
                'type' => 'object',
                'dynamic' => false,
                'properties' => [
                    'height' => ['type' => 'integer'],
                    'width' => ['type' => 'integer']
                ]
            ],

            'xmpData' => [
                'type' => 'object',
                'dynamic' => true,
                'enabled' => $this->indexingOptions['assets']['enable_xmp']
            ],

            'exifData' => [
                'type' => 'object',
                'dynamic' => true,
                'enabled' => $this->indexingOptions['assets']['enable_exif']
            ],

            'iptcData' => [
                'type' => 'object',
                'dynamic' => true,
                'enabled' => $this->indexingOptions['assets']['enable_iptc']
            ],

            'metaData' => [
                'type' => 'object',
                'dynamic' => true
            ],
        ];

        $thumbnails = [
            'original' => [
                'type' => 'object',
                'dynamic' => false,
                'properties' => [
                    'path' => ['type' => 'keyword'],
                    'checksum' => ['type' => 'keyword']
                ]
            ]
        ];

        if (!empty($this->config['thumbnails'])) {
            foreach ($this->config['thumbnails'] as $thumbnail) {
                $thumbnails[$thumbnail] = [
                    'type' => 'object',
                    'dynamic' => false,
                    'properties' => [
                        'path' => ['type' => 'keyword'],
                        'checksum' => ['type' => 'keyword']
                    ]
                ];
            }
        }

        $data['binaryData'] = [
            'type' => 'object',
            'dynamic' => false,
            'properties' => $thumbnails
        ];

        return $data;
    }

    public function buildAggregationsRequest(): array
    {
        $aggregations = [];

        if (!empty($this->fieldsForAggregations)) {
            foreach ($this->fieldsForAggregations as $fullFieldName => $active) {
                if ($active) {
                    $aggregations[$fullFieldName] = $this->createTermsAggregation($fullFieldName);
                }
            }
        }

        return $aggregations;
    }

    public function extractData($elementId): array
    {
        $asset = $this->loadElement($elementId);

        if (! $asset instanceof Asset || !$this->workspaceResolver->checkElementPermission($asset, $this->workspaces)) {
            return [];
        }

        $data = [];

        $data['system'] = $this->createSystemAttributes($asset);
        $data['system']['subtype'] = $asset->getType();
        $data['system']['checksum'] = $this->generateAssetChecksum($asset);
        $data['system']['mimeType'] = $asset->getMimetype();
        $data['system']['fileSize'] = $asset->getFileSize();

        if ($asset->getHasMetaData()) {
            $metaData = $asset->getMetadata();
            foreach ($metaData as $dataDataEntry) {
                $dataKey = implode('.', array_filter([$dataDataEntry['name'], $dataDataEntry['language']]));
                $data['metaData'][$dataKey] = $asset->getMetadata($dataDataEntry['name']); // $dataDataEntry['data'];

                // create path for relations
                if (!empty($data['metaData'][$dataKey]) && in_array($dataDataEntry['type'], ['object', 'asset', 'document', 'manyToManyRelation'])) {
                    $rawData = $data['metaData'][$dataKey];
                    if (!is_array($rawData)) {
                        $rawData = [$rawData];
                    }

                    $processedData = [];
                    foreach ($rawData as $element) {
                        if ($element instanceof ElementInterface) {
                            $processedData[] = $element->getFullPath();
                        }
                    }

                    if (!empty($processedData)) {
                        $data['metaData'][$dataKey] = $processedData;
                    } else {
                        unset($data['metaData'][$dataKey]);
                    }
                }
            }
        }

        if ($asset instanceof Asset\Image) {
            if ($asset->getWidth()) {
                $data['dimensionData']['width'] = $asset->getWidth();
            }
            if ($asset->getHeight()) {
                $data['dimensionData']['height'] = $asset->getHeight();
            }

            $data['xmpData'] = $asset->getXMPData();
            $data['exifData'] = $asset->getEXIFData();
            $data['iptcData'] = $asset->getIPTCData();

            if ($this->config['allowOriginalImage']) {
                $data['binaryData']['original']['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId()]);
                $data['binaryData']['original']['checksum'] = $this->generateAssetChecksum($asset);
                $data['binaryData']['original']['filename'] = pathinfo($asset->getFilename(), PATHINFO_BASENAME);
            }
            if (!empty($this->config['thumbnails'])) {
                foreach ($this->config['thumbnails'] as $thumbnail) {
                    $config = Asset\Image\Thumbnail\Config::getByName($thumbnail);
                    if ($config) {
                        $data['binaryData'][$thumbnail]['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId(), 'thumbnail' => $thumbnail]);
                        $data['binaryData'][$thumbnail]['checksum'] = hash('md5', $this->generateAssetChecksum($asset) . $config->getModificationDate());
                        $data['binaryData'][$thumbnail]['filename'] = urldecode(pathinfo($asset->getThumbnail($thumbnail)->getPath(), PATHINFO_BASENAME));
                    }
                }
            }
        } elseif (!$asset instanceof Asset\Folder) {
            $data['binaryData']['original']['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId()]);
            $data['binaryData']['original']['checksum'] = $this->generateAssetChecksum($asset);
            $data['binaryData']['original']['filename'] = pathinfo($asset->getFilename(), PATHINFO_BASENAME);
        }

        return $data;
    }

    public function getLabelBlackList(): array
    {
        return array_merge(parent::getLabelBlackList(), [
            'exifData',
            'iptcData',
            'xmpData',
            'binaryData',
            'system.versionCount',
            'system.fileSize',
            'system.checksum'
        ]);
    }

    public function loadElement($elementId): ?ElementInterface
    {
        return Asset::getById($elementId);
    }
}
