<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Model\Asset;
use Pimcore\Model\DataObject\Folder;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class FolderMappingAndDataExtractor extends AbstractMappingAndDataExtractor
{
    public function __construct($configName, $entityType, $config, DataExtractorFactory $dataExtractorFactory, WorkspaceResolver $workspaceResolver, array $workspaces, array $fieldsForAggregations, $indexNamePrefix, UrlGeneratorInterface $urlGenerator, array $indexingOptions)
    {
        parent::__construct($configName, $entityType, $config, $dataExtractorFactory, $workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $urlGenerator, $indexingOptions);
        $this->type = $this->entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER ? 'object' : 'asset';
    }

    public function extractMapping(): array
    {
        return [

            'system' => $this->createSystemAttributesMapping(),
        ];
    }

    public function buildAggregationsRequest(): array
    {
        $aggregations = [];

        $possibleAggregationFields = ['system.type', 'system.subtype'];
        foreach ($possibleAggregationFields as $fullFieldName) {
            if ($this->fieldsForAggregations[$fullFieldName] ?? false) {
                $aggregations[$fullFieldName] = $this->createTermsAggregation($fullFieldName);
            }
        }

        return $aggregations;
    }

    public function extractData($elementId): array
    {
        $data = [];
        $element = $this->loadElement($elementId);

        if (!$element instanceof ElementInterface || ! $this->workspaceResolver->checkElementPermission($element, $this->workspaces)) {
            return [];
        }

        $data['system'] = $this->createSystemAttributes($element);
        $data['system']['subtype'] = 'folder';

        return $data;
    }

    public function loadElement($elementId): ?ElementInterface
    {
        if ($this->entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER) {
            return Asset\Folder::getById($elementId);
        }
        if ($this->entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER) {
            return Folder::getById($elementId);
        }

        return null;
    }
}
