<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Controller;

use Pimcore\Bundle\DataHubBundle\Configuration\Dao;
use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Model\Asset\Image\Thumbnail\Config\Listing;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

/**
 * @Route("/admin/pimcoredatahubsimplerest/config")
 */
class ConfigController extends \Pimcore\Bundle\AdminBundle\Controller\AdminController
{
    public const CONFIG_NAME = 'plugin_datahub_config';

    /**
     * @Route("/save")
     *
     * @param Request $request
     *
     * @return JsonResponse
     *
     * @throws \Exception
     *
     */
    public function saveAction(Request $request, IndexService $indexService): ?JsonResponse
    {
        $this->checkPermission(self::CONFIG_NAME);

        try {
            $data = $request->get('data');
            $modificationDate = $request->get('modificationDate', 0);

            if ($modificationDate < Dao::getConfigModificationDate()) {
                throw new \Exception('The configuration was modified during editing, please reload the configuration and make your changes again');
            }

            $dataDecoded = json_decode($data, true);

            $name = $dataDecoded['general']['name'];
            $dataDecoded['general']['active'] = $dataDecoded['general']['active'] ?? false;
            $config = Dao::getByName($name);
            if (!$config->isAllowed('update')) {
                throw $this->createAccessDeniedHttpException();
            }

            $oldConfig = $config->getConfiguration();

            $config->setConfiguration($dataDecoded);

            /* @phpstan-ignore-next-line isAllowed might change due to new configuration */
            if ($config->isAllowed('read') && $config->isAllowed('update')) {
                $config->save();

                //label settings don't have any influence on the indexed data
                $filteredOldConfig = $oldConfig;
                unset($filteredOldConfig['labelSettings']);
                $filteredNewConfig = $config->getConfiguration();
                unset($filteredNewConfig['labelSettings']);

                if (serialize($filteredOldConfig) !== serialize($filteredNewConfig) && $dataDecoded['general']['active']) {
                    $indexService->createOrUpdateMapping($name);
                    $indexService->initIndex($name);
                }

                return $this->json(['success' => true, 'modificationDate' => Dao::getConfigModificationDate()]);
            } else {
                return $this->json(['success' => false, 'permissionError' => true]);
            }
        } catch (\Exception $e) {
            return $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * @Route("/get-label-list")
     *
     * @param Request $request
     * @param IndexService $indexService
     *
     * @return JsonResponse
     */
    public function getLabelListAction(Request $request, IndexService $indexService): JsonResponse
    {
        $this->checkPermission(self::CONFIG_NAME);
        $name = $request->get('name');

        try {
            $configuration = Dao::getByName($name);
            if (!$configuration) {
                throw new \Exception('Configuration ' . $name . ' does not exist.');
            }

            return $this->json(['success' => true, 'labelList' => array_values($indexService->getLabelKeysFromIndex($name))]);
        } catch (\Exception $e) {
            return $this->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * @Route("/get")
     *
     * @param Request $request
     *
     * @return JsonResponse
     *
     * @throws \Exception
     *
     */
    public function getAction(Request $request): JsonResponse
    {
        $this->checkPermission(self::CONFIG_NAME);

        $name = $request->get('name');

        $configuration = Dao::getByName($name);
        if (!$configuration) {
            throw new \Exception('Configuration ' . $name . ' does not exist.');
        }
        if (!$configuration->isAllowed('read')) {
            throw $this->createAccessDeniedHttpException();
        }
        $config = $configuration->getConfiguration();
        if (!isset($config['workspaceSettings'])) {
            $config['workspaceSettings'] = [];
        }

        $config['swaggerUrl'] = $this->generateUrl('data_hub_simple_rest_swagger', [], UrlGeneratorInterface::ABSOLUTE_URL);
        $config['treeItemsUrl'] = $this->generateUrl('data_hub_simple_rest_tree_items', ['config' => $configuration->getName()], UrlGeneratorInterface::ABSOLUTE_URL);
        $config['searchUrl'] = $this->generateUrl('data_hub_simple_rest_search', ['config' => $configuration->getName()], UrlGeneratorInterface::ABSOLUTE_URL);
        $config['getElementByIdUrl'] = $this->generateUrl('data_hub_simple_rest_get_by_id', ['config' => $configuration->getName()], UrlGeneratorInterface::ABSOLUTE_URL);

        return new JsonResponse(
            [
                'name' => $configuration->getName(),
                'configuration' => $config,
                'userPermissions' => [
                    'update' => $configuration->isAllowed('update'),
                    'delete' => $configuration->isAllowed('delete')
                ],
                'modificationDate' => Dao::getConfigModificationDate()
            ]
        );
    }

    /**
     * @Route("/thumbnails")
     *
     * @return JsonResponse
     */
    public function getThumbnailsAction(): JsonResponse
    {
        $thumbnailListing = new Listing();

        $thumbnails = [];
        foreach ($thumbnailListing->load() as $thumbnailConfig) {
            $thumbnails[]['name'] = $thumbnailConfig->getName();
        }

        return new JsonResponse([
           'data' => $thumbnails
        ]);
    }

    /**
     * @Route("/queue-item-count")
     *
     * @param QueueService $queueService
     *
     * @return JsonResponse
     */
    public function getQueueItemCountAction(QueueService $queueService): JsonResponse
    {
        return new JsonResponse([
            'count' => $queueService->getQueueItemCount()
        ]);
    }
}
