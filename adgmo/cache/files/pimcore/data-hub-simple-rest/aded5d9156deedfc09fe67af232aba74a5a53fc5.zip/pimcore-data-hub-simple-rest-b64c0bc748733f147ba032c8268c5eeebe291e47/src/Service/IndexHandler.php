<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Service;

use Elasticsearch\ClientBuilder;
use Elasticsearch\Common\Exceptions\Missing404Exception;
use Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor\AbstractMappingAndDataExtractor;
use Psr\Log\LoggerAwareTrait;

class IndexHandler
{
    use LoggerAwareTrait;

    /**
     * @var string[]
     */
    protected $esHosts;

    /**
     * @var int
     */
    protected $maxResultWindow;

    /**
     * @var null|\Elasticsearch\Client
     */
    protected $elasticSearchClient;

    /**
     * @var array
     */
    protected $mappingTemplate = [
        'dynamic_templates' => [
            [
                'strings' => [
                    'match_mapping_type' => 'string',
                    'mapping' => [
                        'type' => 'keyword',
                        'fields' => [
                            'analyzed' => [
                                'type' => 'text',
                                'analyzer' => 'datahub_ngram_analyzer',
                                'search_analyzer' => 'datahub_whitespace_analyzer'
                            ]
                        ]
                    ]
                ]
            ]
        ]
    ];

    public function __construct($esHosts, $maxResultWindow, $indexingOptions)
    {
        $this->esHosts = $esHosts;
        $this->maxResultWindow = $maxResultWindow;

        $this->mappingTemplate['numeric_detection'] = $indexingOptions['global_options']['numeric_detection'] ?? false;
        $this->mappingTemplate['date_detection'] = $indexingOptions['global_options']['date_detection'] ?? false;
    }

    /**
     * @return \Elasticsearch\Client
     */
    protected function getElasticSearchClient()
    {
        if (empty($this->elasticSearchClient)) {
            $builder = ClientBuilder::create();
            $builder->setHosts($this->esHosts);
            $builder->setLogger($this->logger);
            $this->elasticSearchClient = $builder->build();
        }

        return $this->elasticSearchClient;
    }

    protected function getCurrentIndexVersion(AbstractMappingAndDataExtractor $mappingAndDataExtractor): string
    {
        $client = $this->getElasticSearchClient();
        $result = $client->indices()->getAlias([
            'name' => $mappingAndDataExtractor->getIndexName(),
        ]);

        $aliasIndexName = array_key_first($result);
        $nameParts = explode('-', $aliasIndexName);

        return end($nameParts);
    }

    protected function checkIndex(AbstractMappingAndDataExtractor $mappingAndDataExtractor, $suffix = '-even'): bool
    {
        $client = $this->getElasticSearchClient();

        return $client->indices()->exists([
            'index' => $mappingAndDataExtractor->getIndexName() . $suffix,
            'client' => [
                'ignore' => 404
            ]
        ]);
    }

    protected function createIndex(AbstractMappingAndDataExtractor $dataExtractor, $suffix = '-even'): string
    {
        $client = $this->getElasticSearchClient();

        $mappingProperties = $dataExtractor->extractMapping();

        $mappings = $this->mappingTemplate;
        $mappings['properties'] = $mappingProperties;

        $indexName = $dataExtractor->getIndexName() . $suffix;

        $result = $client->indices()->create([
            'index' => $indexName,
            'include_type_name' => false,
            'body' => [
                'mappings' => $mappings,
                'settings' => $dataExtractor->getIndexSettings()
            ]
        ]);

        if (!$result['acknowledged']) {
            throw new \Exception('Index creation failed. IndexName: ' . $indexName);
        }

        return $indexName;
    }

    protected function reindex(AbstractMappingAndDataExtractor $dataExtractor)
    {
        $currentIndexVersion = $this->getCurrentIndexVersion($dataExtractor);

        $oldIndexName = $dataExtractor->getIndexName() . '-' . $currentIndexVersion;
        $newIndexName = $this->createIndex($dataExtractor, '-' . ($currentIndexVersion == 'even' ? 'odd' : 'even'));

        $body = [
            'source' => [
                'index' => $oldIndexName,

            ],
            'dest' => [
                'index' => $newIndexName,
            ],
        ];

        $this->getElasticSearchClient()->reindex([
            'body' => $body,
        ]);

        $this->switchIndexAliasAndCleanup($dataExtractor->getIndexName(), $oldIndexName, $newIndexName);
    }

    protected function switchIndexAliasAndCleanup($aliasName, $oldIndexName, $newIndexName)
    {
        $client = $this->getElasticSearchClient();

        $params['body'] = [
            'actions' => [
                [
                    'remove' => [
                        'index' => '*',
                        'alias' => $aliasName,
                    ],
                ],
                [
                    'add' => [
                        'index' => $newIndexName,
                        'alias' => $aliasName,
                    ],
                ],
            ],
        ];
        $result = $client->indices()->updateAliases($params);
        if (!$result['acknowledged']) {
            //set current index version
            throw new \Exception('Switching Alias failed for ' . $newIndexName);
        }

        //delete old indices
        $this->deleteEsIndexIfExisting($oldIndexName);
    }

    /**
     * @param string $indexNamePrefix
     * @param array $usedIndices
     */
    public function cleanupUnusedEsIndices($indexNamePrefix, $usedIndices): void
    {
        $stats = $this->getElasticSearchClient()->indices()->stats([
            'index' => $indexNamePrefix . '*'
        ]);
        foreach ($stats['indices'] as $indexName => $data) {
            preg_match('/^'. $indexNamePrefix . '(.*)(-even|-odd)/i', $indexName, $matches);
            if (is_array($matches) && count($matches) > 1 && !in_array($indexNamePrefix . $matches[1], $usedIndices)) {
                $this->deleteEsIndexIfExisting($indexName);
            }
        }
    }

    /**
     * @param string $indexName
     */
    protected function deleteEsIndexIfExisting(string $indexName)
    {
        $client = $this->getElasticSearchClient();
        $result = $client->indices()->exists(['index' => $indexName]);
        if ($result) {
            $result = $client->indices()->delete(['index' => $indexName]);
            if (!array_key_exists('acknowledged', $result) && !$result['acknowledged']) {
                $this->logger->error("Could not delete index {$indexName} while cleanup. Please remove the index manually.");
            }
        }
    }

    /**
     * @param AbstractMappingAndDataExtractor $mappingAndDataExtractor
     */
    public function createOrUpdateMapping(AbstractMappingAndDataExtractor $mappingAndDataExtractor)
    {
        $client = $this->getElasticSearchClient();
        try {
            $indexName = $mappingAndDataExtractor->getIndexName();
            $currentVersion = $this->getCurrentIndexVersion($mappingAndDataExtractor);
            $mappingProperties = $mappingAndDataExtractor->extractMapping();

            $mappings = $this->mappingTemplate;
            $mappings['properties'] = $mappingProperties;

            $result = $client->indices()->putMapping([
                'index' => $indexName,
                'include_type_name' => false,
                'body' => $mappings
            ]);
            if (!$result['acknowledged']) {
                throw new \Exception('Putting mapping to index failed. IndexName: ' . $indexName);
            }

            $currentSettings = $client->indices()->getSettings([
                'index' => $indexName,
            ]);
            $currentSettings = $currentSettings[$indexName . '-' . $currentVersion]['settings']['index'];

            $configuredSettings = $mappingAndDataExtractor->getIndexSettings();

            $settingsIntersection = array_intersect_key($currentSettings, $configuredSettings);
            if ($settingsIntersection != $configuredSettings) {
                $client->indices()->putSettings([
                    'index' => $indexName,
                    'body' => [
                        'index' => $configuredSettings,
                    ],
                ]);
            }
        } catch (\Exception $e) {
            $this->reindex($mappingAndDataExtractor);
        }
    }

    /**
     * @param AbstractMappingAndDataExtractor $mappingAndDataExtractor
     *
     * @throws \Exception
     */
    public function checkAndCreateIndexAlias(AbstractMappingAndDataExtractor $mappingAndDataExtractor)
    {
        $indexName = $mappingAndDataExtractor->getIndexName();

        $client = $this->getElasticSearchClient();
        $aliasExists = $client->indices()->existsAlias([
            'name' => $indexName,
            'client' => [
                'ignore' => 404
            ]
        ]);
        if (!$aliasExists) {
            $aliasName = $indexName;
            if ($this->checkIndex($mappingAndDataExtractor)) {
                $indexName = $indexName . '-even';
            } elseif ($this->checkIndex($mappingAndDataExtractor, '-odd')) {
                $indexName = $indexName . '-odd';
            } else {
                $indexName = $this->createIndex($mappingAndDataExtractor);
            }

            $params['body'] = [
                'actions' => [
                    [
                        'add' => [
                            'index' => $indexName,
                            'alias' => $aliasName,
                        ],
                    ],
                ],
            ];
            $result = $client->indices()->updateAliases($params);
            if (!$result) {
                throw new \Exception('Alias '. $aliasName .' could not be created.');
            }
        }
    }

    public function deleteItem(string $indexName, $elementId)
    {
        $client = $this->getElasticSearchClient();

        try {
            $result = $client->delete([
                'index' => $indexName,
                'type' => '_doc',
                'id' => $elementId,
                'client' => [
                    'ignore' => 404
                ]
            ]);
        } catch (Missing404Exception $e) {
            //nothing to do here - element was not indexed, so it cannot be deleted
        }
    }

    public function indexItem(string $indexName, $elementId, array $data)
    {
        $client = $this->getElasticSearchClient();

        try {
            $indexDocument = $client->get([
                'index' => $indexName,
                'type' => '_doc',
                'id' => $elementId,
                'client' => [
                    'ignore' => 404
                ]
            ]);
            $originalChecksum = $indexDocument['_source']['system'][AbstractMappingAndDataExtractor::INTERNAL_CHECKSUM] ?? -1;
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
            $originalChecksum = -1;
        }

        $checksum = crc32(json_encode($data));

        if ($checksum != $originalChecksum) {
            $data['system'][AbstractMappingAndDataExtractor::INTERNAL_CHECKSUM] = $checksum;
            $client->index([
                'index' => $indexName,
                'type' => '_doc',
                'id' => $elementId,
                'body' => $data
            ]);
        } else {
            $this->logger->info("Not updating index for data object $elementId - nothing has changed.");
        }
    }

    /**
     * @param string $indexName
     *
     * @return array
     */
    public function getAllIdsFromIndex(string $indexName): array
    {
        return $this->doLoadAllIds($indexName, [ 'match_all' => new \stdClass() ]);
    }

    /**
     * @param string $indexName
     * @param string $path
     *
     * @return array
     */
    public function getAllIdsFromIndexByOriginalPath(string $indexName, string $path): array
    {
        return $this->doLoadAllIds($indexName, [
            'bool' => [
                'filter' => [
                    'term' => [
                        'system.' . AbstractMappingAndDataExtractor::INTERNAL_ORIGINAL_FULL_PATH . '.path_analyzed' => $path
                    ]
                ]
            ]
        ]);
    }

    /**
     * @param string $indexName
     * @param array $query
     *
     * @return array
     */
    protected function doLoadAllIds(string $indexName, array $query): array
    {
        $hasElements = true;
        $client = $this->getElasticSearchClient();
        $lastId = ['', 0];

        $ids = [];

        while ($hasElements) {
            $hits = $client->search([
                'index' => $indexName,
                'track_total_hits' => true,
                'rest_total_hits_as_int' => true,
                'body' => [
                    'search_after' => $lastId,
                    'size' => 1000,
                    'query' => $query,
                    'sort' => [
                        'system.fullPath' => ['order' => 'asc'],
                        'system.id' => ['order' => 'asc']
                    ]
                ]
            ]);

            foreach ($hits['hits']['hits'] as $hit) {
                $lastId = [
                    $hit['_source']['system']['fullPath'],
                    $hit['_id']
                ];
                $ids[] = $hit['_id'];
            }

            $hasElements = count($hits['hits']['hits']) > 0 && $hits['hits']['total'] > count($ids);
        }

        return $ids;
    }

    /**
     * @param array $esResponse
     * @param mixed $pageCursor
     * @param int|null $size
     *
     * @return array
     */
    protected function extractResponse(array $esResponse, $pageCursor, int $size = null)
    {
        $serviceResponse = [];

        $serviceResponse['total_count'] = $esResponse['hits']['total'] ?? 0;
        $serviceResponse['items'] = [];

        $hits = $esResponse['hits']['hits'] ?? [];
        foreach ($hits as $hit) {
            $serviceResponse['items'][] = $hit['_source'];
        }

        $lastItem = end($hits);
        if ($lastItem) {
            if (($pageCursor === null || is_numeric($pageCursor)) && $pageCursor + (2 * $size) <= $this->maxResultWindow) {
                $serviceResponse['page_cursor'] = $pageCursor + $size;
            } else {
                $serviceResponse['page_cursor'] = $lastItem['sort'];
            }
        }

        $aggregations = $esResponse['aggregations'] ?? [];
        foreach ($aggregations as $name => $aggregation) {
            $buckets = [];

            foreach ($aggregation['buckets'] as $bucket) {
                $buckets[] = [
                    'key' => $bucket['key'],
                    'element_count' => $bucket['doc_count']
                ];
            }

            if (!empty($buckets)) {
                $serviceResponse['aggregations'][$name] = [
                    'buckets' => $buckets
                ];
            }
        }

        $labels = array_keys($serviceResponse['aggregations'] ?? []);
        foreach ($serviceResponse['items'] as $item) {
            foreach ($item as $dataKey => $dataList) {
                foreach ($dataList as $subDataKey => $dataElement) {
                    $labels[] = $dataKey . '.' . $subDataKey;
                }
            }
        }
        $serviceResponse['labels'] = array_unique($labels);

        return $serviceResponse;
    }

    public function getLabelKeysFromIndex(string $indexName, array $blackList): array
    {
        $client = $this->getElasticSearchClient();
        $params = [
            'index' => [ $indexName ],
            'include_type_name' => false
        ];
        $response = $client->indices()->getMapping($params);

        $allAttributes = [];
        foreach ($response as $index) {
            $allAttributes = array_merge($allAttributes, $this->flattenMappingAttributes($index['mappings']['properties'], $blackList));
        }

        return $allAttributes;
    }

    protected function flattenMappingAttributes(array $mappings, array $blackList, $attributePrefix = '')
    {
        $flattenedAttributes = [];

        foreach ($mappings as $name => $property) {
            if (!in_array($attributePrefix . $name, $blackList)) {

                //filter out any sub-level binary data fields
                if (!empty($attributePrefix) && isset($property['properties']['binaryData'])) {
                    $flattenedAttributes[] = $attributePrefix . $name;
                } elseif (isset($property['properties'])) {
                    $flattenedAttributes = array_merge($flattenedAttributes, $this->flattenMappingAttributes($property['properties'], $blackList, $attributePrefix . $name . '.'));
                } else {
                    $flattenedAttributes[] = $attributePrefix . $name;
                }
            }
        }

        return $flattenedAttributes;
    }

    public function findDuplicateElements(array $indices): ?array
    {
        $client = $this->getElasticSearchClient();

        $body = [
            'size' => 0,
            'aggs' => [
                'system.id' => [
                    'terms' => [
                        'field' => 'system.id',
                        'size' => 10000,
                        'min_doc_count' => 2
                    ],
                ]
            ]
        ];

        $esResponse = $client->search([
            'index' => $indices,
            'body' => $body
        ]);

        $duplicates = [];
        $duplicateIds = [];

        $buckets = $esResponse['aggregations']['system.id']['buckets'] ?? [];

        foreach ($buckets as $bucket) {
            $duplicateIds[] = $bucket['key'] ?? null;
        }

        $duplicateIds = array_filter($duplicateIds);

        if (!empty($duplicateIds)) {
            $esResponse = $client->search([
                'index' => $indices,
                'body' => [
                    'size' => 1000,
                    'query' => [
                        'terms' => [
                            'system.id' => $duplicateIds
                        ]
                    ]
                ]
            ]);

            $results = $esResponse['hits']['hits'] ?? [];

            foreach ($results as $document) {
                $duplicates[] = [
                    'id' => $document['_source']['system']['id'],
                    AbstractMappingAndDataExtractor::INTERNAL_ENTITY_TYPE => $document['_source']['system'][AbstractMappingAndDataExtractor::INTERNAL_ENTITY_TYPE]
                ];
            }
        }

        return $duplicates;
    }

    /**
     * @param array $indices
     * @param int $id
     * @param int $size
     *
     * @return array|null
     */
    public function queryIndexById(array $indices, $id, int $size = 1): ?array
    {
        $client = $this->getElasticSearchClient();

        try {
            if (count($indices) == 1) {
                $result = $client->get([
                    'index' => $indices,
                    'type' => '_doc',
                    'id' => $id
                ]);

                return $result['_source'] ?? null;
            } else {
                $body = [
                    'size' => $size,
                    'query' => [
                        'match' => [
                            '_id' => $id
                        ]
                    ]
                ];

                $esResponse = $client->search([
                    'index' => $indices,
                    'track_total_hits' => true,
                    'rest_total_hits_as_int' => true,
                    'body' => $body
                ]);

                if ($size > 1) {
                    return $this->extractResponse($esResponse, null);
                } else {
                    if (isset($esResponse['hits']['hits'][0]['_source'])) {
                        $response = $esResponse['hits']['hits'][0]['_source'];
                        $labels = [];
                        foreach ($response as $dataKey => $dataList) {
                            foreach ($dataList as $subDataKey => $dataElement) {
                                $labels[] = $dataKey . '.' . $subDataKey;
                            }
                        }
                        $response['labels'] = array_unique($labels);

                        return $response;
                    }

                    return null;
                }
            }
        } catch (Missing404Exception $e) {
            return null;
        }
    }

    /**
     * @param array $indices
     * @param int $id
     *
     * @return bool
     */
    public function hasChildElementInIndex(array $indices, $id): bool
    {
        $client = $this->getElasticSearchClient();

        $body = [
            'size' => 1,
            'query' => [
                'match' => [
                    'system.parentId' => $id
                ]
            ]
        ];

        $esResponse = $client->search([
            'index' => $indices,
            'track_total_hits' => true,
            'rest_total_hits_as_int' => true,
            'body' => $body
        ]);

        return ($esResponse['hits']['total'] ?? 0) > 0;
    }

    protected function generateBoolFilter($filter, $operator = 'must'): array
    {
        if (is_array($filter)) {
            $parts = [];
            $mustNot = [];

            foreach ($filter as $key => $queryPart) {
                if ($key === '$and') {
                    $parts[] = $this->generateBoolFilter($queryPart);
                } elseif ($key === '$or') {
                    $parts[] = $this->generateBoolFilter($queryPart, 'should');
                } else {
                    if (is_array($queryPart)) {
                        if (array_key_exists('$not', $queryPart)) {
                            $mustNot[] = [
                                'term' => [
                                    $key => $queryPart['$not']
                                ]
                            ];
                        } else {
                            $key = array_key_first($queryPart);
                            $parts[] = [
                                'term' => [
                                    $key => $queryPart[$key]
                                ]
                            ];
                        }
                    } else {
                        $parts[] = [
                            'term' => [
                                $key => $queryPart
                            ]
                        ];
                    }
                }
            }

            return [
                'bool' => array_filter([
                    $operator => $parts,
                    'must_not' => $mustNot,
                ])
            ];
        }

        return [];
    }

    /**
     * @param array $indices
     * @param string $fulltextSearch
     * @param array $filter
     * @param int $size
     * @param array $orderBy
     * @param null $pageCursor
     * @param array $aggregationRequest
     *
     * @return array
     *
     * @throws \Exception
     */
    public function queryIndexSearch(
        array $indices,
        string $fulltextSearch,
        $filter = [],
        $size = 200,
        $orderBy = [],
        $pageCursor = null,
        $aggregationRequest = []
    ) {
        $client = $this->getElasticSearchClient();

        $body = [
            'size' => $size,
        ];

        $query = [
            'bool' => [
                'must' => [],
                'filter' => []
            ]
        ];

        if ($fulltextSearch) {
            $query['bool']['must'][] = [
                'simple_query_string' => [
                    'query' => $fulltextSearch,
                    'fields' => []
                ]
            ];
        }

        if ($filter) {
            $query['bool']['filter'] = $this->generateBoolFilter($filter);
        }

        $body['query'] = $query;

        $sort = [];

        if ($orderBy) {
            foreach ($orderBy as $field => $order) {
                $sort[] = [
                    $field => [
                        'order' => $order,
                        'missing' => '_last',
                        'unmapped_type' => 'keyword'
                    ]
                ];
            }
        }

        $sort[] = [
            'system.id' => [
                'order' => 'asc'
            ]
        ];
        $body['sort'] = $sort;

        $this->applyPageCursorToRequest($body, $pageCursor, $size);

        if ($aggregationRequest) {
            $body['aggs'] = $aggregationRequest;
        }

        $esResponse = $client->search([
            'index' => $indices,
            'track_total_hits' => true,
            'rest_total_hits_as_int' => true,
            'body' => $body
        ]);

        $result = $this->extractResponse($esResponse, $pageCursor, $size);

        return $result;
    }

    /**
     * @param array $body
     * @param mixed $pageCursor
     * @param int $size
     *
     * @throws \Exception
     */
    protected function applyPageCursorToRequest(&$body, $pageCursor, $size)
    {
        $pageCursor = $pageCursor ?: 0;
        if ($pageCursor) {
            if (is_numeric($pageCursor)) {
                if ($pageCursor + $size <= $this->maxResultWindow) {
                    $body['from'] = $pageCursor;
                } else {
                    throw new \Exception('Result window exceeds ' . $this->maxResultWindow);
                }
            } else {
                $body['search_after'] = $pageCursor;
            }
        }
    }

    /**
     * @param array $indices
     * @param string $type
     * @param null $parentId
     * @param string $fulltextSearch
     * @param array $filter
     * @param int $size
     * @param array $orderBy
     * @param null $pageCursor
     * @param array $aggregationRequest
     *
     * @return array
     *
     * @throws \Exception
     */
    public function queryIndexTreeNavigation(
        array $indices,
        string $type,
        $parentId = null,
        $fulltextSearch = '',
        $filter = [],
        $size = 200,
        $orderBy = [],
        $pageCursor = null,
        $aggregationRequest = []
    ) {
        $client = $this->getElasticSearchClient();

        $body = [
            'size' => $size,
        ];

        $query = [
            'bool' => [
                'must' => [],
                'filter' => []
            ]
        ];

        if ($fulltextSearch) {
            $query['bool']['must'][] = [
                'simple_query_string' => [
                    'query' => $fulltextSearch,
                    'fields' => []
                ]
            ];
        }

        if ($filter) {
            $query['bool']['filter'] = $this->generateBoolFilter($filter);
        } else {
            $query['bool']['filter']['bool']['must'] = [];
        }

        $query['bool']['filter']['bool']['must'][] = [
            'term' => [
                'system.type' => $type
            ]
        ];
        $query['bool']['filter']['bool']['must'][] = [
            'term' => [
                'system.parentId' => $parentId
            ]
        ];

        $body['query'] = $query;

        $sort = [];

        if ($orderBy) {
            foreach ($orderBy as $field => $order) {
                $sort[] = [
                    $field => [
                        'order' => $order,
                        'missing' => '_last',
                        'unmapped_type' => 'keyword'
                    ]
                ];
            }
        }

        $sort[] = [
            'system.id' => [
                'order' => 'asc'
            ]
        ];
        $body['sort'] = $sort;

        $this->applyPageCursorToRequest($body, $pageCursor, $size);

        if ($aggregationRequest) {
            $body['aggs'] = $aggregationRequest;
        }

        $esResponse = $client->search([
            'index' => $indices,
            'track_total_hits' => true,
            'rest_total_hits_as_int' => true,
            'body' => $body
        ]);

        $result = $this->extractResponse($esResponse, $pageCursor, $size);

        return $result;
    }
}
