<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\EventSubscriber;

use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Event\AssetEvents;
use Pimcore\Event\DataObjectEvents;
use Pimcore\Event\Model\ElementEventInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ChangedEventSubscriber implements EventSubscriberInterface
{
    /**
     * @var IndexService
     */
    protected $indexService;

    /**
     * ChangedEventSubscriber constructor.
     *
     * @param IndexService $indexService
     */
    public function __construct(IndexService $indexService)
    {
        $this->indexService = $indexService;
    }

    /**
     * Returns an array of events this subscriber wants to listen to.
     *
     * @return string[]
     */
    public static function getSubscribedEvents()
    {
        return [
            DataObjectEvents::POST_UPDATE => 'updateElement',
            AssetEvents::POST_UPDATE => 'updateElement',
            AssetEvents::POST_ADD => 'updateElement',
            DataObjectEvents::POST_DELETE => 'deleteElement',
            AssetEvents::POST_DELETE => 'deleteElement'
        ];
    }

    public function updateElement(ElementEventInterface $event)
    {
        //do not update index when auto save or only saving version
        if (
            ($event->hasArgument('isAutoSave') && $event->getArgument('isAutoSave')) ||
            ($event->hasArgument('saveVersionOnly') && $event->getArgument('saveVersionOnly'))
        ) {
            return;
        }

        $element = $event->getElement();
        $entityType = $this->indexService->getEntityTypeForElement($element);
        $this->indexService->addItemToQueue($element->getId(), $entityType);
        $this->indexService->invalidateIndexByOriginalPath($element->getFullPath(), $entityType);
    }

    public function deleteElement(ElementEventInterface $event)
    {
        $element = $event->getElement();
        $entityType = $this->indexService->getEntityTypeForElement($element);
        $this->indexService->invalidateIndexByOriginalPath($element->getFullPath(), $entityType);
    }
}
