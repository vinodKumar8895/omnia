<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Migrations\BundleAwareMigration;

class Version20220307113000 extends BundleAwareMigration
{
    public function up(Schema $schema): void
    {
        if ($schema->hasTable(QueueService::QUEUE_TABLE_NAME)) {
            $queueTable = $schema->getTable(QueueService::QUEUE_TABLE_NAME);
            $queueTable->addColumn('dispatched', 'bigint', ['notnull' => false, 'default' => null]);
            $queueTable->addColumn('workerId', 'string', ['notnull' => false, 'default' => null, 'length' => 13]);
            $queueTable->addIndex(['workerId'], 'bundle_index_queue_workerId');
        }
    }

    public function down(Schema $schema): void
    {
        if ($schema->hasTable(QueueService::QUEUE_TABLE_NAME)) {
            $queueTable = $schema->getTable(QueueService::QUEUE_TABLE_NAME);
            $queueTable->dropColumn('dispatched');
            $queueTable->dropColumn('workerId');
            $queueTable->dropIndex('bundle_index_queue_workerId');
        }
    }

    protected function getBundleName(): string
    {
        return 'PimcoreDataHubSimpleRestBundle';
    }
}
