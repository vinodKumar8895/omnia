<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Controller;

use OpenApi\Annotations as OA;
use Pimcore\Bundle\DataHubSimpleRestBundle\Exception\NotFoundException;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\QueryService;
use Pimcore\Model\Asset;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class EndpointController extends AbstractController
{
    /**
     * @OA\Schema(
     *   schema="ObjectElement",
     *   @OA\Property(
     *      property="system",
     *      type="object",
     *      description="System attributes",
     *      @OA\Property(property="id", type="integer"),
     *      @OA\Property(property="key", type="string"),
     *      @OA\Property(property="fullPath", type="string"),
     *      @OA\Property(property="parentId", type="integer"),
     *      @OA\Property(property="type", type="string", default="object", enum={"object", "asset"}),
     *      @OA\Property(property="subtype", type="string"),
     *      @OA\Property(property="hasChildren", type="boolean"),
     *      @OA\Property(property="creationDate", type="integer"),
     *      @OA\Property(property="modificationDate", type="integer")
     *   ),
     *   @OA\Property(
     *      property="data",
     *      type="object",
     *      description="Data attributes",
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     * )
     *
     */

    /**
     * @OA\Schema(
     *   schema="AssetElement",
     *   @OA\Property(
     *      property="system",
     *      type="object",
     *      description="System attributes",
     *      @OA\Property(property="id", type="integer"),
     *      @OA\Property(property="key", type="string"),
     *      @OA\Property(property="fullPath", type="string"),
     *      @OA\Property(property="parentId", type="integer"),
     *      @OA\Property(property="type", type="string", default="asset", enum={"object", "asset"}),
     *      @OA\Property(property="subtype", type="string"),
     *      @OA\Property(property="hasChildren", type="boolean"),
     *      @OA\Property(property="creationDate", type="integer"),
     *      @OA\Property(property="modificationDate", type="integer"),
     *      @OA\Property(property="versionCount", type="integer"),
     *      @OA\Property(property="checksum", type="string"),
     *      @OA\Property(property="mimeType", type="string"),
     *      @OA\Property(property="fileSize", type="integer", description="File size in bytes")
     *   ),
     *   @OA\Property(
     *      property="dimensionData",
     *      type="object",
     *      description="Dimension attributes",
     *      @OA\Property(property="height", type="integer"),
     *      @OA\Property(property="width")
     *   ),
     *   @OA\Property(
     *      property="binaryData",
     *      type="object",
     *      description="List of Links to binary data",
     *      @OA\Property(property="original", type="string"),
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     *   @OA\Property(
     *      property="xmpData",
     *      type="object",
     *      description="Included XMP Data",
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     *   @OA\Property(
     *      property="exifData",
     *      type="object",
     *      description="Included EXIF Data",
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     *   @OA\Property(
     *      property="iptcData",
     *      type="object",
     *      description="Included IPTC Data",
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     *   @OA\Property(
     *      property="metaData",
     *      type="object",
     *      description="Included Pimcore Meta Data",
     *      @OA\AdditionalProperties(
     *         type="string"
     *      )
     *   ),
     *
     * )
     *
     */

    /**
     * @Route("/{config}/tree-items", name="data_hub_simple_rest_tree_items", requirements={"config"="[\w-]+"})
     *
     * @OA\Get(
     *     description="Method to load all elements of a tree level. For paging use link provided in link header of response",
     *     path="/pimcore-datahub-webservices/simplerest/{config}/tree-items",
     *     tags={"Datahub"},
     *     @OA\Parameter(name="Authorization", in="header",  description="Bearer <access_token> (in swagger ui use authorize feature to set header)"),
     *     @OA\Parameter(name="config", in="path",  description="Name of config", required=true, @OA\Schema(type="string")),
     *     @OA\Parameter(name="type", in="query",  description="Type of elements - asset or object", required=true, @OA\Schema(type="string", enum={"object", "asset"})),
     *     @OA\Parameter(name="parent_id", in="query",  description="Id of parent element", required=false, @OA\Schema(type="integer")),
     *     @OA\Parameter(name="include_folders", in="query",  description="Define if folders should be included, default true", required=false, @OA\Schema(type="boolean", default="true")),
     *     @OA\Parameter(name="size", in="query",  description="Max items of response, default 200.", required=false, @OA\Schema(type="integer", default="200")),
     *     @OA\Parameter(name="fulltext_search", in="query",  description="Search term for fulltext search", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="filter", in="query",  description="Define filter for further filtering. See https://pimcore.com/docs/data-hub-simple-rest/current/Filtering.html for filter syntax, implemeted operators are $not, $or, $and. ", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="order_by", in="query",  description="Field to order by.", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="page_cursor", in="query",  description="Page cursor for paging. Use page cursor of link header in last response.", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="include_aggs", in="query",  description="Set to true to include aggregation information, default false.", required=false, @OA\Schema(type="boolean", default="false")),
     *     security={{"auth": {}}},
     *     @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  @OA\Property(property="total_count", type="integer", description="Total count of available results."),
     *                  @OA\Property(
     *                      property="items",
     *                      type="array",
     *                      @OA\Items(oneOf={@OA\Schema(ref="#/components/schemas/ObjectElement"),@OA\Schema(ref="#/components/schemas/AssetElement")})
     *                  ),
     *                  @OA\Property(property="page_cursor", type="string", description="Page cursor for next page.")
     *              )
     *          )
     *      ),
     *     @OA\Response(
     *          response="400",
     *          ref="#/components/responses/Error400"
     *     ),
     *     @OA\Response(
     *          response=401,
     *          ref="#/components/responses/Error401"
     *      ),
     *     @OA\Response(
     *          response=500,
     *          ref="#/components/responses/Error500"
     *      )
     * )
     *
     *
     */
    public function treeItemsAction(Request $request, QueryService $queryService)
    {
        try {
            $this->checkRequiredParams($request, ['config', 'type']);

            $configName = $request->get('config', 'endpoint1');
            $type = $request->get('type', 'object');
            $parentId = intval($request->get('parent_id', 1));
            $includeFolders = filter_var($request->get('include_folders', true), FILTER_VALIDATE_BOOLEAN);
            $fulltextSearch = $request->get('fulltext_search', '');
            $filter = $request->get('filter', null);
            $size = $request->get('size', 200);
            $orderBy = $request->get('order_by', null);
            $pageCursor = $request->get('page_cursor', null);
            $includeAggs = filter_var($request->get('include_aggs', false), FILTER_VALIDATE_BOOLEAN);

            $this->validateAuthorization($request, $configName, $queryService);

            if ($filter) {
                $filter = json_decode($filter, true);
            }

            $result = $queryService->queryIndexTreeNavigation(
                $configName,
                $type,
                $parentId,
                $includeFolders,
                $fulltextSearch,
                $filter,
                $size,
                $orderBy,
                $pageCursor,
                $includeAggs
            );

            $pageCursor = $result['page_cursor'] ?? '';

            $allParams = $request->query->all();
            $allParams['page_cursor'] = $pageCursor;
            $allParams['config'] = $configName;

            $headers = [];
            if (count($result['items']) == $size) {
                $headers['link'] = $this->generateUrl('data_hub_simple_rest_tree_items', $allParams) . '; rel="next"';
            }

            return new JsonResponse($result, 200, $headers);
        } catch (\Exception $e) {
            return $this->sendJSONError($e);
        }
    }

    /**
     * @Route("/{config}/search", name="data_hub_simple_rest_search", requirements={"config"="[\w-]+"})
     *
     * @OA\Get(
     *     description="Method to search of elements, returns elements of all types. For paging use link provided in link header of response",
     *     path="/pimcore-datahub-webservices/simplerest/{config}/search",
     *     tags={"Datahub"},
     *     @OA\Parameter(name="Authorization", in="header",  description="Bearer <access_token> (in swagger ui use authorize feature to set header)"),
     *     @OA\Parameter(name="config", in="path",  description="Name of config", required=true, @OA\Schema(type="string")),
     *     @OA\Parameter(name="size", in="query",  description="Max items of response, default 200.", required=false, @OA\Schema(type="integer", default="200")),
     *     @OA\Parameter(name="fulltext_search", in="query",  description="Search term for fulltext search", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="filter", in="query",  description="Define filter for further filtering. See https://pimcore.com/docs/data-hub-simple-rest/current/Filtering.html for filter syntax, implemeted operators are $not, $or, $and. ", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="order_by", in="query",  description="Field to order by.", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="page_cursor", in="query",  description="Page cursor for paging. Use page cursor of link header in last response.", required=false, @OA\Schema(type="string")),
     *     @OA\Parameter(name="include_aggs", in="query",  description="Set to true to include aggregation information, default false.", required=false, @OA\Schema(type="boolean", default="false")),
     *     security={{"auth": {}}},
     *     @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  @OA\Property(property="total_count", type="integer", description="Total count of available results."),
     *                  @OA\Property(
     *                      property="items",
     *                      type="array",
     *                      @OA\Items(oneOf={@OA\Schema(ref="#/components/schemas/ObjectElement"),@OA\Schema(ref="#/components/schemas/AssetElement")})
     *                  ),
     *                  @OA\Property(property="page_cursor", type="string", description="Page cursor for next page.")
     *              )
     *          )
     *      ),
     *     @OA\Response(
     *          response="400",
     *          ref="#/components/responses/Error400"
     *     ),
     *     @OA\Response(
     *          response=401,
     *          ref="#/components/responses/Error401"
     *      ),
     *     @OA\Response(
     *          response=500,
     *          ref="#/components/responses/Error500"
     *      )
     * )
     *
     *
     */
    public function searchAction(Request $request, QueryService $queryService)
    {
        try {
            $this->checkRequiredParams($request, ['config']);

            $configName = $request->get('config', 'endpoint1');
            $fulltextSearch = $request->get('fulltext_search', '');
            $filter = $request->get('filter', null);
            $size = $request->get('size', 200);
            $orderBy = $request->get('order_by', null);
            $pageCursor = $request->get('page_cursor', null);
            $includeAggs = filter_var($request->get('include_aggs', false), FILTER_VALIDATE_BOOLEAN);

            $this->validateAuthorization($request, $configName, $queryService);

            if ($filter) {
                $filter = json_decode($filter, true);
            }

            $result = $queryService->queryIndexSearch(
                $configName,
                $fulltextSearch,
                $filter,
                $size,
                $orderBy,
                $pageCursor,
                $includeAggs
            );

            $pageCursor = $result['page_cursor'] ?? '';
//        unset($result['page_cursor']);

            $allParams = $request->query->all();
            $allParams['page_cursor'] = $pageCursor;
            $allParams['config'] = $configName;

            $headers = [];
            if (count($result['items']) == $size) {
                $headers['link'] = '<' . $this->generateUrl('data_hub_simple_rest_search', $allParams, UrlGeneratorInterface::ABSOLUTE_URL) . '>; rel="next"';
            }

            return new JsonResponse($result, 200, $headers);
        } catch (\Exception $e) {
            return $this->sendJSONError($e);
        }
    }

    /**
     * @Route("/{config}/get-element", name="data_hub_simple_rest_get_by_id", requirements={"config"="[\w-]+"})
     *
     * @OA\Get(
     *     description="Method to get one single element by type and id.",
     *     path="/pimcore-datahub-webservices/simplerest/{config}/get-element",
     *     tags={"Datahub"},
     *     @OA\Parameter(name="Authorization", in="header",  description="Bearer <access_token> (in swagger ui use authorize feature to set header)"),
     *     @OA\Parameter(name="config", in="path",  description="Name of config", required=true, @OA\Schema(type="string")),
     *     @OA\Parameter(name="type", in="query",  description="Type of elements - asset or object", required=true, @OA\Schema(type="string", enum={"object", "asset"})),
     *     @OA\Parameter(name="id", in="query",  description="Id of element", required=true, @OA\Schema(type="integer")),
     *     security={{"auth": {}}},
     *     @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  oneOf={@OA\Schema(ref="#/components/schemas/ObjectElement"),@OA\Schema(ref="#/components/schemas/AssetElement")}
     *              )
     *          )
     *      ),
     *     @OA\Response(
     *          response="400",
     *          ref="#/components/responses/Error400"
     *     ),
     *     @OA\Response(
     *          response=401,
     *          ref="#/components/responses/Error401"
     *      ),
     *     @OA\Response(
     *          response=404,
     *          ref="#/components/responses/Error404"
     *      ),
     *     @OA\Response(
     *          response=500,
     *          ref="#/components/responses/Error500"
     *      )
     * )
     *
     */
    public function getByIdAction(Request $request, QueryService $queryService)
    {
        try {
            $this->checkRequiredParams($request, ['config', 'type', 'id']);

            $configName = $request->get('config', 'endpoint1');
            $type = $request->get('type', 'object');
            $id = intval($request->get('id'));

            $this->validateAuthorization($request, $configName, $queryService);

            $result = $queryService->queryIndexById(
                $configName,
                $type,
                $id
            );

            if (empty($result)) {
                throw new NotFoundException("Element with type '$type' and id '$id' not found.");
            }

            return new JsonResponse($result, 200);
        } catch (\Exception $e) {
            return $this->sendJSONError($e);
        }
    }

    /**
     * @Route("/{config}/download-asset", name="data_hub_simple_rest_download_asset", requirements={"config"="[\w-]+"})
     *
     * @param Request $request
     * @param QueryService $queryService
     *
     * @return Response
     *
     * @throws NotFoundException
     * @throws \Pimcore\Bundle\DataHubSimpleRestBundle\Exception\InvalidRequestException
     * @throws \Pimcore\Bundle\DataHubSimpleRestBundle\Exception\AccessDeniedException
     */
    public function deliverAssetsAction(Request $request, QueryService $queryService)
    {
        $headers = [
            'Access-Control-Allow-Origin' => '*',
            'Access-Control-Allow-Methods' => 'GET, OPTIONS',
            'Access-Control-Allow-Headers' => 'authorization'
        ];

        if ($request->getMethod() === 'OPTIONS') {
            return new Response('', 204, array_merge($headers, [
                'Content-Type' => 'text/plain charset=UTF-8',
                'Content-Length' => 0
            ]));
        }

        $this->checkRequiredParams($request, ['config']);

        $configName = $request->get('config');
        $type = 'asset';
        $id = intval($request->get('id'));

        $this->validateAuthorization($request, $configName, $queryService);
        if (method_exists('Asset\Image\Thumbnail\Processor', 'setHasWebpSupport')) { // @phpstan-ignore-line
            Asset\Image\Thumbnail\Processor::setHasWebpSupport(false);                                  // @phpstan-ignore-line
        }

        $result = $queryService->queryIndexById(
            $configName,
            $type,
            $id
        );

        $asset = Asset::getByid($id);

        if (empty($result) || empty($asset)) {
            throw new NotFoundException("Asset with id '$id' not found or access denied.");
        }

        $thumbnail = $request->get('thumbnail');

        if ($asset instanceof Asset\Image && !empty($thumbnail)) {
            $imageThumbnail = $asset->getThumbnail($thumbnail);
            $stream = $imageThumbnail->getStream();

            $headers['Content-Type'] = $imageThumbnail->getMimetype();
            $headers['Content-Disposition'] = sprintf('attachment; filename="%s"', basename($imageThumbnail->getPath()));
            $headers['Content-Length'] = $imageThumbnail->getFileSize();

            return new StreamedResponse(function () use ($stream) {
                fpassthru($stream);
            }, 200, $headers);
        } else {
            $stream = $asset->getStream();

            $headers['Content-Type'] = $asset->getMimetype();
            $headers['Content-Disposition'] = sprintf('attachment; filename="%s"', $asset->getFilename());
            $headers['Content-Length'] = $asset->getFileSize();

            return new StreamedResponse(function () use ($stream) {
                fpassthru($stream);
            }, 200, $headers);
        }
    }
}
