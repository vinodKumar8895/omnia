<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Bundle\DataHubSimpleRestBundle\Tool\AssetRelationFixer;
use Pimcore\Localization\LocaleServiceInterface;
use Pimcore\Model\Asset;
use Pimcore\Model\DataObject;
use Pimcore\Model\DataObject\AbstractObject;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class DataObjectMappingAndDataExtractor extends AbstractMappingAndDataExtractor
{
    /**
     * @var string
     */
    protected $type = 'object';

    /**
     * @var LocaleServiceInterface
     */
    protected $localeService;

    /**
     * @var AssetRelationFixer
     */
    protected $assetRelationFixer;

    public function __construct($configName, $entityType, $config, DataExtractorFactory $dataExtractorFactory, WorkspaceResolver $workspaceResolver, array $workspaces, array $fieldsForAggregations, $indexNamePrefix, UrlGeneratorInterface $urlGenerator, LocaleServiceInterface $localeService, AssetRelationFixer $assetRelationFixer, array $indexingOptions)
    {
        parent::__construct($configName, $entityType, $config, $dataExtractorFactory, $workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $urlGenerator, $indexingOptions);
        $this->localeService = $localeService;
        $this->assetRelationFixer = $assetRelationFixer;
    }

    /**
     * Get sub definition of operator to guess correct type and create mapping correspondingly
     *
     * @param mixed $definition
     *
     * @return array[]|mixed|\stdClass
     */
    protected function extractOperatorSubDefinitionIfNecessary($definition)
    {
        if ($definition instanceof \stdClass && ($definition->isOperator ?? false)) {
            if (in_array($definition->attributes->class, ['LocaleSwitcher', 'LFExpander', 'Alias'])) {
                $fieldConfig = (array) ($definition->attributes->childs[0] ?? []);
                if ($fieldConfig) {
                    return [
                        'fieldConfig' => $fieldConfig
                    ];
                }
            }
        }

        return $definition;
    }

    protected function generateDataMapping()
    {
        $properties = [];
        foreach ($this->getGridConfigData()['helperDefinitions'] as $field => $definition) {
            $fieldName = $this->mapFieldname($field, $definition);
            $definition = $this->extractOperatorSubDefinitionIfNecessary($definition);
            if (is_array($definition)) {
                $type = $definition['fieldConfig']['dataType'] ?? ($definition['fieldConfig']['type'] ?? null);

                if (in_array($type, ['image', 'imageGallery', 'video', 'hotspotimage'])) {
                    $thumbnails = [
                        'original' => [
                            'type' => 'object',
                            'dynamic' => false,
                            'properties' => [
                                'path' => ['type' => 'keyword'],
                                'checksum' => ['type' => 'keyword']
                            ]
                        ]
                    ];
                    foreach (($this->config['assets']['thumbnails'] ?: []) as $thumbnail) {
                        $thumbnails[$thumbnail] = [
                            'type' => 'object',
                            'dynamic' => false,
                            'properties' => [
                                'path' => ['type' => 'keyword'],
                                'checksum' => ['type' => 'keyword']
                            ]
                        ];
                    }

                    $properties[$fieldName] = [
                        'type' => 'object',
                        'dynamic' => false,
                        'properties' => [
                            'id' => ['type' => 'keyword'],
                            'type' => ['type' => 'keyword'],
                            'binaryData' => [
                                'type' => 'object',
                                'dynamic' => false,
                                'properties' => $thumbnails
                            ]
                        ]
                    ];
                } elseif (in_array($type, ['numeric', 'slider'])) {
                    $properties[$fieldName] = [
                        'type' => 'double'
                    ];
                } else {
                    $properties[$fieldName] = [
                        'type' => 'keyword',
                        'fields' => [
                            'analyzed' => [
                                'type' => 'text',
                                'analyzer' => 'datahub_ngram_analyzer',
                                'search_analyzer' => 'datahub_whitespace_analyzer'
                            ]
                        ]
                    ];
                }
            } elseif ($definition instanceof \stdClass) {
                if ($definition->isOperator) {
                    $properties[$fieldName] = [
                        'type' => 'keyword',
                        'fields' => [
                            'analyzed' => [
                                'type' => 'text',
                                'analyzer' => 'datahub_ngram_analyzer',
                                'search_analyzer' => 'datahub_whitespace_analyzer'
                            ]
                        ]
                    ];
                }
            } else {
                throw new \Exception('Invalid definition');
            }
        }

        return [
            'type' => 'object',
            'dynamic' => true,
            'properties' => $properties
        ];
    }

    protected function mapFieldname($field, $definition): string
    {
        if (strpos($field, '#') === 0) {
            if ($definition) {
                if (!empty($definition->attributes)) {
                    return $definition->attributes->label ? $definition->attributes->label : $field;
                }

                return $field;
            }
        } elseif (substr($field, 0, 1) == '~') {
            $fieldParts = explode('~', $field);
            $type = $fieldParts[1];

            if ($type == 'classificationstore') {
                $fieldname = $fieldParts[2];
                $groupKeyId = explode('-', $fieldParts[3]);
                $groupId = intval($groupKeyId[0]);
                $keyId = intval($groupKeyId[1]);

                $groupConfig = DataObject\Classificationstore\GroupConfig::getById($groupId);
                $keyConfig = DataObject\Classificationstore\KeyConfig::getById($keyId);

                if ($groupConfig && $keyConfig) {
                    $field = $fieldname . '~' . $groupConfig->getName() . '~' . $keyConfig->getName();
                }
            }
        }

        return $field;
    }

    public function extractMapping(): array
    {
        return [

            'system' => $this->createSystemAttributesMapping(),
            'data' => $this->generateDataMapping()
        ];
    }

    public function buildAggregationsRequest(): array
    {
        $aggregations = [];

        $possibleAggregationFields = ['system.entityType', 'system.elementType'];

        $mapping = $this->extractMapping();
        foreach ($mapping['data']['properties'] as $field => $definition) {
            $possibleAggregationFields[] = 'data.' . $field;
        }

        foreach ($possibleAggregationFields as $fullFieldName) {
            if ($this->fieldsForAggregations[$fullFieldName] ?? false) {
                $aggregations[$fullFieldName] = $this->createTermsAggregation($fullFieldName);
            }
        }

        return $aggregations;
    }

    protected function getGridConfigData()
    {
        $helperDefinitions = $this->config['columnConfig'] ?? [];

        $fields = array_keys($helperDefinitions);

        foreach ($helperDefinitions as $k => $v) {
            if (DataObject\Service::isHelperGridColumnConfig($k)) {
                $helperDefinitions[$k] = json_decode(json_encode($v['fieldConfig']));
            }
        }
        $requestedLanguage = $this->config['language'] ?? null;

        return [
            'fields' => $fields,
            'helperDefinitions' => $helperDefinitions,
            'language' => $requestedLanguage
        ];
    }

    public function extractData($elementId): array
    {
        $element = $this->loadElement($elementId);

        if (!$element instanceof DataObject\Concrete || !$this->workspaceResolver->checkElementPermission($element, $this->workspaces)) {
            return [];
        }

        $data = [];
        $data['data'] = $this->extractElementExportData($element);
        $data['system'] = $this->createSystemAttributes($element);
        $data['system']['subtype'] = $element->getClassName();

        return $data;
    }

    protected function extractElementExportData(DataObject\Concrete $element)
    {
        $gridConfigData = $this->getGridConfigData();
        $context = [
            'source' => 'pimcore_data_hub_rest_export',
            'exporter' => $this
        ];

        $data = DataObject\Service::getCsvDataForObject($element, $gridConfigData['language'], $gridConfigData['fields'], $gridConfigData['helperDefinitions'], $this->localeService, true, $context);
        $data = $this->fixAssetRelations($gridConfigData['helperDefinitions'], $data);

        return $data;
    }

    /**
     * @param array $definitions
     * @param array $elementExportData
     */
    protected function fixAssetRelations(array $definitions, array $elementExportData)
    {
        foreach ($definitions as $field => $definition) {
            if (is_array($definition) && $definition['fieldConfig']['type'] == 'image') {
                $asset = $this->assetRelationFixer->processImage($elementExportData[$field]);
                if ($asset) {
                    $elementExportData[$field] = $this->generateAssetData($asset);
                } else {
                    unset($elementExportData[$field]);
                }
            }

            if (is_array($definition) && $definition['fieldConfig']['type'] == 'hotspotimage') {
                $data = $this->assetRelationFixer->processHotspotImage($elementExportData[$field]);
                if ($data && $data->getImage()) {
                    $elementExportData[$field] = $this->generateAssetData($data->getImage());
                } else {
                    unset($elementExportData[$field]);
                }
            }

            if (is_array($definition) && $definition['fieldConfig']['type'] == 'imageGallery') {
                $galleryData = $this->assetRelationFixer->processImageGallery($elementExportData[$field]);
                $assets = [];
                foreach (array_filter($galleryData?->getItems() ?? []) as $galleryEntry) {
                    $asset = $galleryEntry->getImage();

                    if ($asset) {
                        $assets[] = $this->generateAssetData($asset);
                    }
                }
                if (!empty($assets)) {
                    $elementExportData[$field] = $assets;
                } else {
                    unset($elementExportData[$field]);
                }
            }

            if (is_array($definition) && $definition['fieldConfig']['type'] == 'video') {
                $data = $this->assetRelationFixer->processVideo($elementExportData[$field]);
                if ($data && $data->getType() == 'asset') {
                    $elementExportData[$field] = $this->generateAssetData($data->getData());
                } else {
                    unset($elementExportData[$field]);
                }
            }
        }

        foreach ($elementExportData as $field => $data) {
            if ($data instanceof Asset) {
                $elementExportData[$field] = $this->generateAssetData($data);
            }
        }

        return $elementExportData;
    }

    protected function generateAssetData(Asset $asset)
    {
        $data = [
            'id' => $asset->getId(),
            'type' => 'asset'
        ];

        if ($asset instanceof Asset\Image) {
            if ($this->config['assets']['allowOriginalImage']) {
                $data['binaryData']['original']['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId()]);
                $data['binaryData']['original']['checksum'] = $this->generateAssetChecksum($asset);
                $data['binaryData']['original']['filename'] = pathinfo($asset->getFilename(), PATHINFO_BASENAME);
            }

            foreach (($this->config['assets']['thumbnails'] ?: []) as $thumbnail) {
                $config = Asset\Image\Thumbnail\Config::getByName($thumbnail);
                if ($config) {
                    $data['binaryData'][$thumbnail]['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId(), 'thumbnail' => $thumbnail]);
                    $data['binaryData'][$thumbnail]['checksum'] = hash('md5', $this->generateAssetChecksum($asset) . $config->getModificationDate());
                    $data['binaryData'][$thumbnail]['filename'] = urldecode(pathinfo($asset->getThumbnail($thumbnail)->getPath(), PATHINFO_BASENAME));
                }
            }
        } else {
            $data['binaryData']['original']['path'] = $this->urlGenerator->generate('data_hub_simple_rest_download_asset', ['config' => $this->configName, 'id' => $asset->getId()]);
            $data['binaryData']['original']['checksum'] = $this->generateAssetChecksum($asset);
            $data['binaryData']['original']['filename'] = pathinfo($asset->getFilename(), PATHINFO_BASENAME);
        }

        return $data;
    }

    public function loadElement($elementId): ?ElementInterface
    {
        $element = AbstractObject::getById($elementId);
        if ($element instanceof DataObject\Concrete) {
            if (!$element->isPublished()) {
                return null;
            }
        }

        return $element;
    }
}
