<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Controller;

use OpenApi\Annotations as OA;
use Pimcore\Bundle\AdminBundle\HttpFoundation\JsonResponse;
use Pimcore\Bundle\CoreBundle\EventListener\Frontend\FullPageCacheListener;
use Pimcore\Bundle\DataHubSimpleRestBundle\Exception\AccessDeniedException;
use Pimcore\Bundle\DataHubSimpleRestBundle\Exception\InvalidRequestException;
use Pimcore\Bundle\DataHubSimpleRestBundle\Exception\NotFoundException;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\QueryService;
use Pimcore\Controller\Controller;
use Pimcore\Controller\KernelControllerEventInterface;
use Psr\Log\LoggerAwareTrait;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\ControllerEvent;

/**
 * @OA\Info(
 *      version="1.0.0",
 *      title="Pimcore Datahub Simple Rest API",
 * )
 */
class AbstractController extends Controller implements KernelControllerEventInterface
{
    /**
     * @OA\SecurityScheme(
     *   securityScheme="auth",
     *   type="http",
     *   scheme="bearer",
     *   bearerFormat="JWT"
     * )
     */

    /**
     * @OA\Schema(
     *   schema="ErrorReponse",
     *   @OA\Property(property="error", type="string")
     * )
     *
     *
     * @OA\Response(
     *      response="Error400",
     *      description="Invalid request, detail information in response body.",
     *      @OA\JsonContent(ref="#/components/schemas/ErrorReponse"),
     * )
     *
     * @OA\Response(
     *      response="Error401",
     *      description="Access denied, detail information in response body.",
     *      @OA\JsonContent(ref="#/components/schemas/ErrorReponse"),
     * )
     *
     * @OA\Response(
     *      response="Error404",
     *      description="Not found error.",
     *      @OA\JsonContent(ref="#/components/schemas/ErrorReponse"),
     * )
     *
     * @OA\Response(
     *      response="Error500",
     *      description="Application error, detail information in response body.",
     *      @OA\JsonContent(ref="#/components/schemas/ErrorReponse"),
     * )
     *
     */
    use LoggerAwareTrait;

    /**
     * @var FullPageCacheListener
     */
    protected $fullPageCacheListener;

    public function __construct(FullPageCacheListener $fullPageCacheListener)
    {
        $this->fullPageCacheListener = $fullPageCacheListener;
    }

    public function onKernelControllerEvent(ControllerEvent $event)
    {
        $this->fullPageCacheListener->disable('Disable cache for api requests');
    }

    /**
     * @param \Exception $error
     *
     * @return JsonResponse
     */
    protected function sendJSONError(\Exception $error)
    {
        if ($error instanceof NotFoundException) {
            $errorCode = 404;
        } elseif ($error instanceof InvalidRequestException) {
            $errorCode = 400;
        } elseif ($error instanceof AccessDeniedException) {
            $errorCode = 401;
        } else {
            $errorCode = 500;
            $this->logger->warning('error-response sent - error: ' . $error->getMessage() . '; ' . $error->getTraceAsString());

            if (\Pimcore::inDebugMode()) {
                throw $error;
            }
        }

        return new JsonResponse(
            [
                'error' => $error->getMessage()
            ],
            $errorCode
        );
    }

    protected function checkRequiredParams(Request $request, array $requiredParams = [])
    {
        $missingParams = [];

        foreach ($requiredParams as $param) {
            if (empty($request->get($param))) {
                $missingParams[] = $param;
            }
        }

        $errorMessage = '';
        if (!empty($missingParams)) {
            $errorMessage .= 'Missing required params: ' .  implode(', ', $missingParams);
            throw new InvalidRequestException($errorMessage);
        }
    }

    protected function validateAuthorization(Request $request, string $configName, QueryService $queryService)
    {
        if ($request->headers->has('authorization') === false) {
            throw new AccessDeniedException();
        }

        $header = $request->headers->get('authorization');

        $token = trim((string) preg_replace('/^(?:\s+)?Bearer\s/', '', $header));

        if (!$queryService->validateToken($configName, $token)) {
            throw new AccessDeniedException();
        }
    }
}
