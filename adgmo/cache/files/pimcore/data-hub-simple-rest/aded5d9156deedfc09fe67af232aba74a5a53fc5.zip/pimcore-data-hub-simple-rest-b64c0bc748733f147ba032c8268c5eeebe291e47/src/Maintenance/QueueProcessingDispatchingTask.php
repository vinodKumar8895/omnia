<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Maintenance;

use Pimcore\Bundle\DataHubSimpleRestBundle\Messenger\QueueHandler;
use Pimcore\Maintenance\TaskInterface;

class QueueProcessingDispatchingTask implements TaskInterface
{
    public function __construct(
        protected QueueHandler $simpleRestQueueHandler,
        protected bool $messengerQueueActivated
    ) {
    }

    public function execute()
    {
        if ($this->messengerQueueActivated) {
            $this->simpleRestQueueHandler->dispatchMessages();
        }
    }
}
