<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Controller;

use Pimcore\Controller\FrontendController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class SwaggerController extends FrontendController
{
    /**
     * @Route("/swagger", name="data_hub_simple_rest_swagger")
     */
    public function swaggerUi()
    {
        return $this->render('@PimcoreDataHubSimpleRest/swagger/swagger_ui.html.twig', []);
    }

    /**
     * @Route("/swagger-config")
     */
    public function swaggerConfiguration()
    {
        $openapi = \OpenApi\scan([__DIR__ . '/../']);

        return new Response($openapi->toYaml());
    }
}
