<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Service;

use Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor\AbstractMappingAndDataExtractor;
use Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor\DataExtractorFactory;
use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Tool;
use Symfony\Component\Lock\LockFactory;

class QueryService extends AbstractService
{
    /**
     * @var string
     */
    protected $secret;

    public function __construct(QueueService $queueService, IndexHandler $indexHandler, DataExtractorFactory $dataExtractorFactory, /*LockFactory*/ $lockFactory, string $indexNamePrefix, string $secret)
    {
        $this->secret = $secret;
        parent::__construct($queueService, $indexHandler, $dataExtractorFactory, $indexNamePrefix, $lockFactory);
    }

    /**
     * @param array $response
     *
     * @return array
     */
    protected function filterInternalAttributesFromResponse(array $response): array
    {
        unset($response['system'][AbstractMappingAndDataExtractor::INTERNAL_CHECKSUM]);
        unset($response['system'][AbstractMappingAndDataExtractor::INTERNAL_ENTITY_TYPE]);
        unset($response['system'][AbstractMappingAndDataExtractor::INTERNAL_ORIGINAL_FULL_PATH]);

        return $response;
    }

    protected function filterInternalAttributesFromResponseItems(array $items): array
    {
        $filteredItems = [];
        foreach ($items as $item) {
            $filteredItems[] = $this->filterInternalAttributesFromResponse($item);
        }

        return $filteredItems;
    }

    /**
     * @param string $configName
     * @param string $type
     * @param int $id
     *
     * @return array|null
     *
     * @throws \Pimcore\Bundle\DataHubSimpleRestBundle\Exception\InvalidRequestException
     */
    public function queryIndexById(string $configName, string $type, $id): ?array
    {
        if ($type == 'asset') {
            $dataExtractorCollection = $this->getDataExtractorCollectionForConfigAndType($configName, DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET);
        } else {
            $dataExtractorCollection = $this->getDataExtractorCollectionForConfigAndType($configName, $type);
        }

        $indices = [];
        foreach ($dataExtractorCollection as $dataExtractor) {
            $indices[] = $dataExtractor->getIndexName();
        }

        $response = $this->indexHandler->queryIndexById($indices, $id);

        if ($response) {
            $response = $this->filterInternalAttributesFromResponse($response);
            $response['labels'] = $this->enrichLabelSettingsInResponse($configName, $response['labels']);
        }

        return $response;
    }

    protected function enrichLabelSettingsInResponse(string $configName, array $usedLabels)
    {
        $config = $this->getDataHubConfig()[$configName] ?? null;

        $validLanguages = Tool::getValidLanguages();
        $usedLabels = array_flip($usedLabels);

        $enrichedLabels = [];
        foreach ($config['labelSettings'] as $labelSetting) {
            if (isset($usedLabels[$labelSetting['id']])) {
                $labels = [];
                foreach ($validLanguages as $language) {
                    $labels[$language] = $labelSetting[$language] ?? $labelSetting['id'];
                }
                $enrichedLabels[$labelSetting['id']] = $labels;
            }
        }

        return $enrichedLabels;
    }

    public function queryIndexSearch(
        string $configName,
        string $fulltextSearch,
        $filter = [],
        $size = 200,
        $orderBy = [],
        $pageCursor = null,
        $includeAggs = false
    ) {
        $indices = [];
        $aggregationRequest = [];
        foreach ($this->getDataExtractorsForConfig($configName) as $entityType => $mappingAndDataExtractor) {

            //don't search in folders
            if ($entityType !== DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER && $entityType !== DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER) {
                $indices[] = $mappingAndDataExtractor->getIndexName();
                if ($includeAggs) {
                    $aggregationRequest = array_merge($aggregationRequest, $mappingAndDataExtractor->buildAggregationsRequest());
                }
            }
        }

        $pageCursor = ($pageCursor === null || is_numeric($pageCursor)) ? $pageCursor : unserialize(openssl_decrypt($pageCursor, 'AES-128-ECB', $this->secret));

        if ($orderBy && !is_array($orderBy)) {
            $orderBy = [$orderBy];
        }

        $result = $this->indexHandler->queryIndexSearch(
            $indices,
            $fulltextSearch,
            $filter,
            $size,
            $orderBy,
            $pageCursor,
            $aggregationRequest
        );

        if (isset($result['page_cursor']) && !is_int($result['page_cursor'])) {
            $result['page_cursor'] = openssl_encrypt(serialize($result['page_cursor']), 'AES-128-ECB', $this->secret);
        }

        $result['items'] = $this->filterInternalAttributesFromResponseItems($result['items']);
        $result['labels'] = $this->enrichLabelSettingsInResponse($configName, $result['labels']);

        return $result;
    }

    public function queryIndexTreeNavigation(
        string $configName,
        string $type,
        $parentId = null,
        $includeFolders = true,
        $fulltextSearch = '',
        $filter = [],
        $size = 200,
        $orderBy = null,
        $pageCursor = null,
        $includeAggs = false
    ) {
        $indices = [];
        $aggregationRequest = [];

        foreach ($this->getDataExtractorsForConfig($configName) as $entityType => $mappingAndDataExtractor) {
            if ($includeFolders || ($entityType !== DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER && $entityType !== DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER)) {
                $indices[] = $mappingAndDataExtractor->getIndexName();
                if ($includeAggs) {
                    $aggregationRequest = array_merge($aggregationRequest, $mappingAndDataExtractor->buildAggregationsRequest());
                }
            }
        }

        $pageCursor = ($pageCursor === null || is_numeric($pageCursor)) ? $pageCursor : unserialize(openssl_decrypt($pageCursor, 'AES-128-ECB', $this->secret));

        if ($orderBy && !is_array($orderBy)) {
            $orderBy = [$orderBy];
        }

        $result = $this->indexHandler->queryIndexTreeNavigation(
            $indices,
            $type,
            $parentId,
            $fulltextSearch,
            $filter,
            $size,
            $orderBy,
            $pageCursor,
            $aggregationRequest
        );

        if (isset($result['page_cursor']) && !is_int($result['page_cursor'])) {
            $result['page_cursor'] = openssl_encrypt(serialize($result['page_cursor']), 'AES-128-ECB', $this->secret);
        }

        $result['items'] = $this->filterInternalAttributesFromResponseItems($result['items']);
        $result['labels'] = $this->enrichLabelSettingsInResponse($configName, $result['labels']);

        return $result;
    }
}
