/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */


pimcore.registerNS("pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.configItem");
pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.configItem = Class.create(pimcore.plugin.datahub.configuration.graphql.configItem, {

    urlSave: Routing.generate('pimcore_datahubsimplerest_config_save'),

    getItems: function () {
        return [
            this.getGeneral(),
            this.getSchema(),
            this.getWorkspaces(),
            this.getLabelSettings(),
            this.getDeliverySettings(),
            this.getPermissions()
        ]
    },

    showInfo: function () {

        var footer = this.tab.getDockedComponent('footer');

        footer.removeAll();

        this.queueCountInfo = Ext.create('Ext.form.field.Display', {
            labelWidth: 300,
            readOnly: false,
            disabled: false
        });

        footer.add(this.queueCountInfo);
        footer.add('->');

        let saveButtonConfig = {
            text: t("save"),
            iconCls: "pimcore_icon_apply",
            handler: this.save.bind(this),
            disabled: !this.data.general.writeable || !this.userPermissions.update
        };

        if(!this.data.general.writeable) {
            saveButtonConfig.tooltip = t("config_not_writeable");
        }

        footer.add(saveButtonConfig);

        this.updateQueueItemInfo(true);
    },

    updateQueueItemInfo: function(activateTimeout) {
        Ext.Ajax.request({
            url: Routing.generate('pimcore_datahubsimplerest_config_getqueueitemcount'),
            success: function (response) {
                let data = Ext.decode(response.responseText);
                if(data.count === 0) {
                    this.queueCountInfo.setValue('');
                    this.updateLabelList();
                } else {
                    this.queueCountInfo.setValue(t('plugin_pimcore_datahub_simple_rest_current_items_in_queue') + ': ' + data.count);
                }

            }.bind(this)
        });

        if(activateTimeout) {
            this.queueCountUpdateTimeout = setTimeout(this.updateQueueItemInfo.bind(this, activateTimeout), 60000);
        }
    },

    updateLabelList: function(doCleanup) {
        if(this.labelListMightHaveChanged || doCleanup) {
            Ext.Ajax.request({
                url: Routing.generate('pimcore_datahubsimplerest_config_getlabellist'),
                params: {
                    name: this.data.general.name
                },
                success: function (response) {
                    const rdata = Ext.decode(response.responseText);
                    if (rdata && rdata.success) {

                        if(doCleanup) {
                            var labelRecords = this.labelStore.queryBy(function (record, id) {
                                return true;
                            });
                            labelRecords.items.forEach(function(record) {
                                console.log(record);
                                if(!rdata.labelList.includes(record.data.id)) {
                                    this.labelStore.remove(record);
                                }
                            }.bind(this));
                        }

                        rdata.labelList.forEach(function(label) {
                            if(!this.labelStore.findRecord('id', label)) {
                                this.labelStore.add({'id': label});
                            }
                        }.bind(this));
                        this.labelListMightHaveChanged = false;
                    } else {
                        pimcore.helpers.showNotification(t("error"), t("plugin_pimcore_datahub_configpanel_update_labels_error"), "error", t(rdata.message));
                    }
                }.bind(this)
            });
        }
    },

    tabdestroy: function () {
        clearTimeout(this.queueCountUpdateTimeout);
        this.tabdestroyed = true;
    },

    save: function () {
        var saveData = this.getSaveData();

        Ext.Ajax.request({
            url: this.urlSave,
            params: {
                data: saveData,
                modificationDate: this.modificationDate
            },
            method: "post",
            success: function (response) {
                var rdata = Ext.decode(response.responseText);
                if (rdata && rdata.success) {
                    pimcore.helpers.showNotification(t("success"), t("plugin_pimcore_datahub_configpanel_item_save_success"), "success");
                    this.modificationDate = rdata.modificationDate;
                    this.labelListMightHaveChanged = true;
                    this.resetChanges();
                }
                else if(rdata && rdata.permissionError) {
                        pimcore.helpers.showNotification(t("error"), t("plugin_pimcore_datahub_configpanel_item_saveerror_permissions"), "error");
                        this.tab.setActiveTab(this.tab.items.length-1);
                } else {
                    pimcore.helpers.showNotification(t("error"), t("plugin_pimcore_datahub_configpanel_item_saveerror"), "error", t(rdata.message));
                }

                this.updateQueueItemInfo(false);
            }.bind(this)
        });
    },

    getGeneral: function () {
        this.generalForm = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200,
                width: 600
            },
            border: false,
            title: t("plugin_pimcore_datahub_configpanel_item_general"),
            items: [
                {
                    xtype: "checkbox",
                    fieldLabel: t("active"),
                    name: "active",
                    value: this.data.general && this.data.general.hasOwnProperty("active") ? this.data.general.active : true
                },
                {
                    xtype: "textfield",
                    fieldLabel: t("type"),
                    name: "type",
                    value: t("plugin_pimcore_datahub_type_" + this.data.general.type),
                    readOnly: true
                },
                {
                    xtype: "textfield",
                    fieldLabel: t("name"),
                    name: "name",
                    value: this.data.general.name,
                    readOnly: true
                },
                {
                    name: "description",
                    fieldLabel: t("description"),
                    xtype: "textarea",
                    height: 100,
                    value: this.data.general.description
                },
                {
                    xtype: "textfield",
                    fieldLabel: t("group"),
                    name: "group",
                    value: this.data.general.group
                },
            ]
        });

        return this.generalForm;
    },

    getSchema: function () {

        let schemaGrid = this.createSchemaStoreAndGrid("query");

        let thumbnailStore = new Ext.data.JsonStore({
            autoDestroy: true,
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: Routing.generate('pimcore_datahubsimplerest_config_getthumbnails'),
                reader: {
                    rootProperty: 'data',
                    idProperty: 'name'
                }
            },
            fields: ['name']
        });

        this.schemaForm = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200,
                width: 800
            },
            border: false,
            title: t("plugin_pimcore_datahub_configpanel_schema"),
            items: [
                {
                    xtype: 'fieldset',
                    title: t('plugin_pimcore_datahub_simple_rest_data_object_classes'),
                    items: [
                        schemaGrid
                    ]
                }, {
                    xtype: 'fieldset',
                    title: t('plugin_pimcore_datahub_simple_rest_assets'),
                    items: [
                        {
                            xtype: "checkbox",
                            labelWidth: 200,
                            fieldLabel: t("plugin_pimcore_datahub_simple_rest_assets_enabled"),
                            name: "enabled",
                            value: this.data.schema && this.data.schema.hasOwnProperty("assets") ? this.data.schema.assets.enabled : false
                        },
                        {
                            xtype: "checkbox",
                            labelWidth: 200,
                            fieldLabel: t("plugin_pimcore_datahub_simple_rest_assets_allow_original_image"),
                            name: "allowOriginalImage",
                            value: this.data.schema && this.data.schema.hasOwnProperty("assets") ? this.data.schema.assets.allowOriginalImage : false
                        },
                        {
                            xtype: "tagfield",
                            labelWidth: 200,
                            fieldLabel: t("plugin_pimcore_datahub_simple_rest_assets_thumbnails"),
                            name: "thumbnails",
                            width: 800,
                            store: thumbnailStore,
                            valueField: 'name',
                            displayField: 'name',
                            value: this.data.schema && this.data.schema.hasOwnProperty("assets") ? this.data.schema.assets.thumbnails : []
                        },
                    ]
                }
            ]
        });

        return this.schemaForm;
    },

    createSchemaStoreAndGrid: function () {
        var schemaToolbar = Ext.create('Ext.Toolbar', {
            cls: 'main-toolbar',
            items: [
                {
                    text: t('add'),
                    handler: this.onAdd.bind(this, 'dataObject'),
                    iconCls: "pimcore_icon_add"
                }
            ]
        });

        var fields = ['id', 'language', 'columnConfig'];
        this.dataObjectSchemaStore = Ext.create('Ext.data.Store', {
            reader: {
                type: 'memory'
            },
            fields: fields,
            data: this.data.schema ? this.data.schema.dataObjectClasses : []
        });

        var columns = [
            {
                text: t("plugin_pimcore_datahub_configpanel_entity"),
                sortable: true,
                dataIndex: 'name',
                editable: false,
                filter: 'string',
                flex: 1
            },
            {
                xtype: 'actioncolumn',
                text: t('settings'),
                menuText: t('settings'),
                width: 60,
                items: [{
                    tooltip: t('settings'),
                    icon: "/bundles/pimcoreadmin/img/flat-color-icons/settings.svg",
                    handler: function (grid, rowIndex) {
                        var record = grid.getStore().getAt(rowIndex);

                        var classStore = pimcore.globalmanager.get("object_types_store");
                        var classIdx = classStore.findExact("text", record.data.id);
                        if (classIdx >= 0) {
                            let classRecord = classStore.getAt(classIdx);
                            let classId = classRecord.data.id;
                            let columnConfig = record.get("columnConfig") || [];
                            let language = record.get("language") || 'en';

                            this.openSchemaDialog(classId, columnConfig, language, record); //function (data, settings) {
                        }
                    }.bind(this)
                }]
            },
            {
                xtype: 'actioncolumn',
                text: t('delete'),
                menuText: t('delete'),
                width: 60,
                items: [{
                    tooltip: t('delete'),
                    icon: "/bundles/pimcoreadmin/img/flat-color-icons/delete.svg",
                    handler: function (grid, rowIndex) {
                        grid.getStore().removeAt(rowIndex);
                    }.bind(this)
                }
                ]
            }
        ];

        this.dataObjectSchemaGrid = Ext.create('Ext.grid.Panel', {
            frame: false,
            bodyCls: "pimcore_editable_grid",
            autoScroll: true,
            store: this.dataObjectSchemaStore,
            columnLines: true,
            stripeRows: true,
            columns: {
                items: columns
            },
            trackMouseOver: true,
            selModel: Ext.create('Ext.selection.RowModel', {}),
            tbar: schemaToolbar,
            viewConfig: {
                forceFit: true,
                enableTextSelection: true
            }
        });

        return this.dataObjectSchemaGrid;

    },

    openSchemaDialog: function (classId, columnConfig, language, record) {
        var objectId = 1;

        let dialogColumnConfig = {
            classid: classId,
            language: language
        };

        var fieldKeys = Object.keys(columnConfig);

        var selectedGridColumns = [];
        for (var i = 0; i < fieldKeys.length; i++) {
            var field = columnConfig[fieldKeys[i]];
            if (!field.hidden) {
                var fc = {
                    key: fieldKeys[i],
                    label: field.fieldConfig.label,
                    dataType: field.fieldConfig.type,
                };
                if (field.fieldConfig.width) {
                    fc.width = field.fieldConfig.width;
                }
                if (field.fieldConfig.locked) {
                    fc.locked = field.fieldConfig.locked;
                }

                if (field.isOperator) {
                    fc.isOperator = true;
                    fc.attributes = field.fieldConfig.attributes;

                }

                selectedGridColumns.push(fc);
            }
        }

        dialogColumnConfig.selectedGridColumns = selectedGridColumns;

        var settings = {
            source: 'pimcore_data_hub_simple_rest'
        };

        let className = '';
        const classStore = pimcore.globalmanager.get("object_types_store");
        let classIdx = classStore.findExact("text", record.data.id);
        if (classIdx >= 0) {
            className = classStore.getAt(classIdx).data.name;
        }

        var gridConfigDialog = new pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.gridConfigDialog(dialogColumnConfig, function (record, classId, data, settings, save) {
                var columns = {};

                //convert to data array as grid uses it
                for (let i = 0; i < data.columns.length; i++) {
                    let curr = data.columns[i];

                    //remove layout information as it is not needed
                    delete curr.layout;
                    columns[curr.key] = {
                        name: curr.key,
                        position: (i + 1),
                        hidden: false,
                        fieldConfig: curr,
                        isOperator: curr.isOperator
                    };
                }

                record.set('columnConfig', columns);
                record.set('language', data.language);

            }.bind(this, record, classId),
            function () {
                gridConfigDialog.window.close();
            }.bind(this),
            false,
            settings,
            {
                allowPreview: true,
                classId: classId,
                objectId: objectId,
                csvMode: 0,
                showPreviewSelector : true,
                previewSelectorTypes : ['object'],
                previewSelectorSubTypes: {
                    'object' : ['object','variant']
                },
                previewSelectorSpecific: {
                    classes : [className]
                }
            }
        );
        gridConfigDialog.itemsPerPage.hide();
    },

    getWorkspaces: function () {

        this.assetWorkspace = new pimcore.plugin.datahub.workspace.asset(this);
        this.assetWorkspace.availableRights = ['read'];

        this.objectWorkspace = new pimcore.plugin.datahub.workspace.object(this);
        this.objectWorkspace.availableRights = ['read'];


        let workspacesPanel = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200
            },
            border: false,
            title: t("plugin_pimcore_datahub_simple_rest_configpanel_workspaces"),
            items: [
                {
                    xtype: 'fieldset',
                    width: 800,
                    title: t("workspaces"),
                    items: [
                        this.assetWorkspace.getPanel(),
                        this.objectWorkspace.getPanel()
                    ]
                }
            ]
        });

        return workspacesPanel;
    },

    getLabelSettings: function () {
        const languages = pimcore.settings.websiteLanguages;

        var columns = [
            {text: t("plugin_pimcore_datahub_simple_rest_configpanel_key"), flex: 200, sortable: true, dataIndex: 'id'}
        ];
        var storeFields = ['id', 'useInAggs'];

        languages.forEach(function(language) {
            columns.push({
                cls: "x-column-header_" + language,
                text: pimcore.available_languages[language],
                sortable: true,
                flex: 200,
                dataIndex: language,
                editor: new Ext.form.TextField({}),
                renderer: function (text) {
                    if (text) {
                        return replace_html_event_attributes(strip_tags(text, 'div,span,b,strong,em,i,small,sup,sub,p'));
                    }
                }
            });
            storeFields.push(language);
        });
        columns.push(new Ext.grid.column.Check({
            text: t("plugin_pimcore_datahub_simple_rest_configpanel_useInAggs"),
            dataIndex: "useInAggs",
            width: 50
        }));

        const cellEditing = Ext.create('Ext.grid.plugin.CellEditing', {
            clicksToEdit: 1
        });

        this.labelStore = Ext.create('Ext.data.JsonStore', {
            data: this.data.labelSettings,
            fields: storeFields
        });

        var grid = Ext.create('Ext.grid.Panel', {
            autoScroll: true,
            store: this.labelStore,
            columns: {
                items: columns,
                defaults: {
                    renderer: Ext.util.Format.htmlEncode
                },
            },
            selModel: Ext.create('Ext.selection.RowModel', {}),
            plugins: [
                cellEditing
            ],
            tbar: {
                items: [
                    '->',
                    {
                        xtype: "button",
                        text: t('plugin_pimcore_datahub_simple_rest_configpanel_label_cleanup'),
                        handler: this.updateLabelList.bind(this, true)
                    },
                ]
            },
            trackMouseOver: true,
            columnLines: true,
            bodyCls: "pimcore_editable_grid",
            stripeRows: true,
            viewConfig: {
                forceFit: true,
                markDirty: false
            }
        });

        let labelSettingsPanel = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200
            },
            border: false,
            title: t("plugin_pimcore_datahub_simple_rest_configpanel_label_settings"),
            items: [
                {
                    xtype: 'fieldset',
                    width: '100%',
                    title: t("plugin_pimcore_datahub_simple_rest_configpanel_labels"),
                    items: [
                        {
                            xtype: 'displayfield',
                            hideLabel: false,
                            value: t("plugin_pimcore_datahub_simple_rest_configpanel_label_settings_description"),
                            readOnly: true,
                            disabled: true
                        },
                        grid
                    ]
                }
            ]
        });

        return labelSettingsPanel;
    },

    getDeliverySettings: function() {
        var apikeyField = new Ext.form.field.Text({
            xtype: "textfield",
            labelWidth: 200,
            width: 600,
            fieldLabel: t("plugin_pimcore_datahub_security_datahub_apikey"),
            name: "apikey",
            value: this.data.deliverySettings ? this.data.deliverySettings.apikey : "",
            minLength: 16
        });

        this.deliverySettingsForm = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200
            },
            border: false,
            title: t("plugin_pimcore_datahub_simple_rest_configpanel_delivery_settings"),
            items: [
                {
                    xtype: "fieldcontainer",
                    layout: 'hbox',

                    items: [
                        apikeyField,
                        {
                            xtype: "button",
                            width: 32,
                            style: "margin-left: 8px",
                            iconCls: "pimcore_icon_clear_cache",
                            handler: function () {
                                apikeyField.setValue(md5(uniqid()));
                            }.bind(this)
                        }
                    ]
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: t("plugin_pimcore_datahub_simple_rest_security_apikey_description"),
                    cls: "pimcore_extra_label_bottom",
                    readOnly: true,
                    disabled: true
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: this.data.swaggerUrl,
                    fieldLabel: t('plugin_pimcore_datahub_simple_rest_devliery_swagger_url'),
                    readOnly: false,
                    disabled: false
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: this.data.treeItemsUrl,
                    fieldLabel: t('plugin_pimcore_datahub_simple_rest_devliery_tree_items_url'),
                    readOnly: false,
                    disabled: false
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: this.data.searchUrl,
                    fieldLabel: t('plugin_pimcore_datahub_simple_rest_devliery_search_url'),
                    readOnly: false,
                    disabled: false
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: this.data.getElementByIdUrl,
                    fieldLabel: t('plugin_pimcore_datahub_simple_rest_devliery_get_element_by_id_url'),
                    readOnly: false,
                    disabled: false
                }
            ]
        });

        return this.deliverySettingsForm;
    },

    filterIds: function(dataArray) {
        for (var i = 0; i < dataArray.length; i++) {
            var currentData = dataArray[i];
            delete currentData.id;
        }
        return dataArray;
    },

    getSaveData: function () {
        var saveData = {};
        saveData["general"] = this.generalForm.getForm().getValues();
        saveData["deliverySettings"] = this.deliverySettingsForm.getForm().getValues();
        saveData["schema"] = {};
        saveData["schema"]["assets"] = this.schemaForm.getForm().getValues();
        saveData["schema"]["dataObjectClasses"] = this.getSchemaData("dataObject");
        saveData["workspaces"] = {};
        saveData["workspaces"]["asset"] = this.filterIds(this.assetWorkspace.getValues());
        saveData["workspaces"]["object"] = this.filterIds(this.objectWorkspace.getValues());
        saveData["permissions"] = this.getPermissionsSaveData();

        var labelData = [];
        var labelRecords = this.labelStore.getData();
        labelRecords.items.forEach(record => labelData.push(record.data));
        saveData["labelSettings"] = labelData;

        return Ext.encode(saveData);
    },

});
