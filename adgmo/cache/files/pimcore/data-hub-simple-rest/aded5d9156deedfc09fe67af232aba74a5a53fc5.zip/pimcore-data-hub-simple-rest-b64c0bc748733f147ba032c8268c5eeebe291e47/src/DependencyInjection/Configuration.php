<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\DependencyInjection;

use Pimcore\Bundle\DataHubSimpleRestBundle\Messenger\QueueHandler;
use Symfony\Component\Config\Definition\Builder\TreeBuilder;
use Symfony\Component\Config\Definition\ConfigurationInterface;

/**
 * This is the class that validates and merges configuration from your app/config files.
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/configuration.html}
 */
class Configuration implements ConfigurationInterface
{
    /**
     * {@inheritdoc}
     */
    public function getConfigTreeBuilder()
    {
        $treeBuilder = new TreeBuilder('pimcore_data_hub_simple_rest');
        $rootNode = $treeBuilder->getRootNode();

        /* @phpstan-ignore-next-line */
        $rootNode->addDefaultsIfNotSet()->children()
            ->scalarNode('index_name_prefix')
                ->defaultValue('datahub_restindex_')
                ->info('Prefix for index names')
            ->end()
            ->integerNode('max_results_window')
                ->defaultValue(10000)
                ->info('Limit of page size and offset when paging only works via page cursor (and not page numbers anymore). Limit 10000 comes from Elasticsearch.')
            ->end()
            ->arrayNode('es_hosts')
                ->prototype('scalar')->end()
                ->defaultValue(['localhost'])
                ->info('List of elasticsearch hosts')
            ->end()
            ->arrayNode('indexing_options')
                ->info('Options to configure indexing behaviour')
                ->addDefaultsIfNotSet()
                ->children()
                    ->arrayNode('assets')
                        ->addDefaultsIfNotSet()
                        ->children()
                            ->booleanNode('enable_exif')
                                ->info('Enable indexing for exif data')
                                ->defaultTrue()
                            ->end()
                            ->booleanNode('enable_xmp')
                                ->info('Enable indexing for xmp data')
                                ->defaultTrue()
                            ->end()
                            ->booleanNode('enable_iptc')
                                ->info('Enable indexing for iptc data')
                                ->defaultTrue()
                            ->end()
                        ->end()
                    ->end()
                    ->arrayNode('global_options')
                        ->addDefaultsIfNotSet()
                        ->children()
                            ->booleanNode('numeric_detection')
                                ->info('Enable numeric detection for dynamic objects (like embedded asset meta data, etc.)')
                                ->defaultFalse()
                            ->end()
                            ->booleanNode('date_detection')
                                ->info('Enable date detection for dynamic objects (like embedded asset meta data, etc.)')
                                ->defaultTrue()
                            ->end()
                        ->end()
                    ->end()
                    ->arrayNode('number_of_shards_config')
                        ->info('Configure number of shards for created indices')
                        ->addDefaultsIfNotSet()
                        ->children()
                            ->integerNode('default_number')
                                ->defaultValue(1)
                                ->info('default number is picked if no index specific settings is set')
                            ->end()
                            ->arrayNode('index_specific')
                                ->info('Define number of shards for certain indices. Define index name (without -odd/-even postfix) as key, and number of shards as value.')
                                ->prototype('integer')->end()
                            ->end()
                        ->end()
                    ->end()
                ->end()
            ->end()
            ->arrayNode('messenger_queue_processing')
                ->addDefaultsIfNotSet()
                ->info('Configure index queue processing via symfony messenger')
                ->children()
                    ->booleanNode('activated')
                        ->info('Activate queue processing via symfony messenger.')
                        ->defaultFalse()
                    ->end()
                    ->integerNode('worker_count_lifetime')
                        ->defaultValue(QueueHandler::WORKER_COUNT_LIFE_TIME) //1 hour
                        ->info('Lifetime of tmp store entry for current worker count entry. After lifetime, the value will be cleared. Default to 1 hour.')
                    ->end()
                    ->integerNode('worker_item_count')
                        ->defaultValue(QueueHandler::WORKER_ITEM_COUNT)
                        ->info('Count of items processed per worker message.')
                    ->end()
                    ->integerNode('worker_count')
                        ->defaultValue(QueueHandler::WORKER_COUNT)
                        ->info('Count of maximum parallel worker messages for queue processing.')
                    ->end()
                ->end()
            ->end()
        ->end();

        return $treeBuilder;
    }
}
