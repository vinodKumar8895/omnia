<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle;

use Pimcore\Bundle\DataHubBundle\PimcoreDataHubBundle;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Bundle\EnterpriseBundleInterface;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\PimcoreEnterpriseSubscriptionToolsBundle;
use Pimcore\Extension\Bundle\AbstractPimcoreBundle;
use Pimcore\Extension\Bundle\Traits\PackageVersionTrait;
use Pimcore\HttpKernel\Bundle\DependentBundleInterface;
use Pimcore\HttpKernel\BundleCollection\BundleCollection;

class PimcoreDataHubSimpleRestBundle extends AbstractPimcoreBundle implements DependentBundleInterface, EnterpriseBundleInterface
{
    use PackageVersionTrait;

    public function getJsPaths()
    {
        return [
            '/bundles/pimcoredatahubsimplerest/js/pimcore/startup.js',
            '/bundles/pimcoredatahubsimplerest/js/pimcore/adapter/simpleRest.js',
            '/bundles/pimcoredatahubsimplerest/js/pimcore/configuration/configItem.js',
            '/bundles/pimcoredatahubsimplerest/js/pimcore/configuration/gridConfigDialog.js'
        ];
    }

    public function getCssPaths()
    {
        return [
            '/bundles/pimcoredatahubsimplerest/css/icons.css'
        ];
    }

    /**
     * Register bundles to collection.
     *
     * WARNING: this method will be called as soon as this bundle is added to the collection, independent if
     * it will finally be included due to environment restrictions. If you need to load your dependencies conditionally,
     * specify the environments to use on the collection item.
     *
     * @param BundleCollection $collection
     */
    public static function registerDependentBundles(BundleCollection $collection)
    {
        $collection->addBundle(PimcoreDataHubBundle::class, 20);
        $collection->addBundle(new PimcoreEnterpriseSubscriptionToolsBundle());
    }

    /**
     * @return string
     */
    public function getBundleLicenseId(): string
    {
        return 'DSR';
    }

    /**
     * Returns the composer package name used to resolve the version
     *
     * @return string
     */
    protected function getComposerPackageName(): string
    {
        return 'pimcore/data-hub-simple-rest';
    }

    public function getInstaller()
    {
        return $this->container->get(Installer::class);
    }
}
