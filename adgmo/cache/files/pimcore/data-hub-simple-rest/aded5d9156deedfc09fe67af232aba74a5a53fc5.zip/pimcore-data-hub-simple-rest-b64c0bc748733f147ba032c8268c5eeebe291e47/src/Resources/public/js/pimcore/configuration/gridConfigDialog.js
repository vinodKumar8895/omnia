/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */


pimcore.registerNS("pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.gridConfigDialog");
pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.gridConfigDialog = Class.create(pimcore.object.helpers.gridConfigDialog, {

    availableOperators: [
        'assetmetadatagetter',
        'fieldcollectiongetter',
        'objectfieldgetter',
        'propertygetter',
        'booleanformatter',
        'dateformatter',
        'text',
        'alias',
        'localeswitcher',
        'merge',
        'phpcode',
        'boolean',
        'isequal',
        'arithmetic',
        'base64',
        'elementcounter',
        'json',
        'lfexpander',
        'anonymizer',
        'caseconverter',
        'charcounter',
        'concatenator',
        'stringreplace',
        'substring',
        'translatevalue',
        'trimmer'
    ]

});