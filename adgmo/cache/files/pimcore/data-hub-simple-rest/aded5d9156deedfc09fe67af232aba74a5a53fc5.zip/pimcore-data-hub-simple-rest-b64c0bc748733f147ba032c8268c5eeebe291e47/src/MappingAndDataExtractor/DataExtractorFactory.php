<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Bundle\DataHubSimpleRestBundle\Tool\AssetRelationFixer;
use Pimcore\Localization\LocaleServiceInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class DataExtractorFactory
{
    const DATA_EXTRACTOR_TYPE_ASSET = '_asset';
    const DATA_EXTRACTOR_TYPE_ASSET_FOLDER = '_assetfolder';
    const DATA_EXTRACTOR_TYPE_OBJECT_FOLDER = '_objectfolder';

    /**
     * @var WorkspaceResolver
     */
    protected $workspaceResolver;

    /**
     * @var LocaleServiceInterface
     */
    protected $localeService;

    /**
     * @var UrlGeneratorInterface
     */
    protected $urlGenerator;

    /**
     * @var AssetRelationFixer
     */
    protected $assetRelationFixer;

    /**
     * @var array
     */
    protected $indexingOptions;

    /**
     * @param WorkspaceResolver $workspaceResolver
     * @param LocaleServiceInterface $localeService
     * @param UrlGeneratorInterface $urlGenerator
     * @param AssetRelationFixer $assetRelationFixer
     * @param array $indexingOptions
     */
    public function __construct(WorkspaceResolver $workspaceResolver, LocaleServiceInterface $localeService, UrlGeneratorInterface $urlGenerator, AssetRelationFixer $assetRelationFixer, array $indexingOptions)
    {
        $this->workspaceResolver = $workspaceResolver;
        $this->localeService = $localeService;
        $this->urlGenerator = $urlGenerator;
        $this->assetRelationFixer = $assetRelationFixer;
        $this->indexingOptions = $indexingOptions;
    }

    public function buildDataExtractor(string $configName, string $type, array $config, array $workspaces, array $fieldsForAggregations, string $indexNamePrefix): AbstractMappingAndDataExtractor
    {
        switch ($type) {
            case self::DATA_EXTRACTOR_TYPE_ASSET:

                return new AssetMappingAndDataExtractor($configName, self::DATA_EXTRACTOR_TYPE_ASSET, $config, $this, $this->workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $this->urlGenerator, $this->indexingOptions);

            case self::DATA_EXTRACTOR_TYPE_ASSET_FOLDER:

                return new FolderMappingAndDataExtractor($configName, self::DATA_EXTRACTOR_TYPE_ASSET_FOLDER, $config, $this, $this->workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $this->urlGenerator, $this->indexingOptions);

            case self::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER:

                return new FolderMappingAndDataExtractor($configName, self::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER, $config, $this, $this->workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $this->urlGenerator, $this->indexingOptions);

            default:
                return new DataObjectMappingAndDataExtractor($configName, $config['id'], $config, $this, $this->workspaceResolver, $workspaces, $fieldsForAggregations, $indexNamePrefix, $this->urlGenerator, $this->localeService, $this->assetRelationFixer, $this->indexingOptions);
        }
    }
}
