<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Messenger;

use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Model\Tool\TmpStore;
use Symfony\Component\Messenger\MessageBusInterface;

class QueueHandler
{
    const IMPORTER_WORKER_COUNT_TMP_STORE_KEY = 'DATA-HUB-SIMPLE-REST::worker-count';
    const WORKER_COUNT_LIFE_TIME = 60 * 60; // 1 hour
    const WORKER_ITEM_COUNT = 400;
    const WORKER_COUNT = 3;

    public function __construct(
        protected QueueService $queueService,
        protected IndexService $indexService,
        protected MessageBusInterface $messageBus,
        protected int $workerCountLifeTime,
        protected int $workerItemCount,
        protected int $workerCount
    ) {
    }

    public function __invoke(QueueMessage $message)
    {
        foreach ($message->getItems() as $item) {
            $this->indexService->processQueueEntry($item['elementId'], $item['entityType'], $item['configName']);
        }

        $this->removeMessage($message->getMessageId());
        $this->dispatchMessages();
    }

    public function dispatchMessages()
    {
        $dispatchedMessageCount = $this->getMessageCount();

        $addWorkers = true;
        $addedCleanupMessage = false;
        while ($addWorkers && $dispatchedMessageCount < $this->workerCount) {
            $items = $this->queueService->getAllQueueEntries($this->workerItemCount, true);
            if (!empty($items)) {
                if ($addedCleanupMessage === false) {
                    $this->messageBus->dispatch(new QueueDuplicateCleanupMessage());
                    $addedCleanupMessage = true;
                }

                $messageId = uniqid();
                $this->addMessage($messageId);
                $this->messageBus->dispatch(new QueueMessage($items, $messageId));
                $dispatchedMessageCount = $this->getMessageCount();
            } else {
                $addWorkers = false;
            }
        }
    }

    private function addMessage(string $messageId)
    {
        TmpStore::set(self::IMPORTER_WORKER_COUNT_TMP_STORE_KEY . $messageId, true, self::IMPORTER_WORKER_COUNT_TMP_STORE_KEY, $this->workerCountLifeTime);
    }

    private function removeMessage(string $messageId)
    {
        TmpStore::delete(self::IMPORTER_WORKER_COUNT_TMP_STORE_KEY . $messageId);
    }

    private function getMessageCount(): int
    {
        $ids = TmpStore::getIdsByTag(self::IMPORTER_WORKER_COUNT_TMP_STORE_KEY);
        $runningWorkers = [];
        foreach ($ids as $id) {
            $runningWorkers[] = TmpStore::get($id);
        }

        return count(array_filter($runningWorkers));
    }
}
