<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Exception;

class InvalidRequestException extends \Exception
{
    public function __construct($message = '', $code = 0, \Throwable $previous = null)
    {
        if (empty($message)) {
            $message = 'Invalid request.';
        }

        parent::__construct($message, $code, $previous);
    }
}
