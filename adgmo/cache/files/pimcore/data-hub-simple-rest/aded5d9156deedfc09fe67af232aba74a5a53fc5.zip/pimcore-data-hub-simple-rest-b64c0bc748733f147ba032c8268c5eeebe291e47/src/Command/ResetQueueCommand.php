<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Command;

use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Console\AbstractCommand;
use Symfony\Component\Console\Command\LockableTrait;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ResetQueueCommand extends AbstractCommand
{
    use LockableTrait;

    /**
     * @var IndexService
     */
    protected $indexService;

    public function __construct(IndexService $indexService)
    {
        parent::__construct();
        $this->indexService = $indexService;
    }

    protected function configure()
    {
        $this
            ->setName('datahub:simple-rest:init-index')
            ->setDescription('Initializes index by adding all necessary items to queue for given configs.')
            ->addArgument('config_name', InputArgument::OPTIONAL | InputArgument::IS_ARRAY, 'Names of configs that should be considered.')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if (!$this->lock()) {
            throw new \Exception('The command is already running in another process.');
        }

        $configNames = $input->getArgument('config_name');

        if (empty($configNames)) {
            $output->writeln('Initialize index for all configs.');

            $this->indexService->initIndex();
        } else {
            foreach ($configNames as $configName) {
                $output->writeln("Initialize index for config '$configName'");

                $this->indexService->initIndex($configName);
            }
        }

        $this->release();

        return 0;
    }
}
