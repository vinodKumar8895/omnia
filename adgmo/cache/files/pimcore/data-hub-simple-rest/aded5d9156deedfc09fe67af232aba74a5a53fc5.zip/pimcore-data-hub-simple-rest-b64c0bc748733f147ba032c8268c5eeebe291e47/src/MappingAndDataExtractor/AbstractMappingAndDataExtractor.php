<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Model\Asset;
use Pimcore\Model\Element\ElementInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

abstract class AbstractMappingAndDataExtractor
{
    const INTERNAL_ENTITY_TYPE = '__internal_entity_type';
    const INTERNAL_CHECKSUM = '__internal_checksum';
    const INTERNAL_ORIGINAL_FULL_PATH = '__internal_original_full_path';

    /**
     * @var string
     */
    protected $indexNamePrefix;

    /**
     * @var string
     */
    protected $configName;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var string
     */
    protected $entityType;

    /**
     * @var DataExtractorFactory
     */
    protected $dataExtractorFactory;

    /**
     * @var WorkspaceResolver
     */
    protected $workspaceResolver;

    /**
     * @var array
     */
    protected $workspaces;

    /**
     * @var string
     */
    protected $combinedParentPath;

    /**
     * @var string
     */
    protected $type;

    /**
     * @var array
     */
    protected $fieldsForAggregations;

    /**
     * @var UrlGeneratorInterface
     */
    protected $urlGenerator;

    /**
     * @var array
     */
    protected $indexingOptions;

    public function __construct($configName, $entityType, $config, DataExtractorFactory $dataExtractorFactory, WorkspaceResolver $workspaceResolver, array $workspaces, array $fieldsForAggregations, $indexNamePrefix, UrlGeneratorInterface $urlGenerator, array $indexingOptions)
    {
        $this->indexNamePrefix = $indexNamePrefix;
        $this->configName = $configName;
        $this->config = $config;
        $this->entityType = $entityType;
        $this->dataExtractorFactory = $dataExtractorFactory;
        $this->workspaceResolver = $workspaceResolver;
        $this->workspaces = $workspaces;
        $this->fieldsForAggregations = $fieldsForAggregations;
        $this->urlGenerator = $urlGenerator;
        $this->indexingOptions = $indexingOptions;
    }

    protected function getNumberOfShards(): int
    {
        return
            $this->indexingOptions['number_of_shards_config']['index_specific'][$this->getIndexName()] ??
            $this->indexingOptions['number_of_shards_config']['default_number'];
    }

    public function getIndexSettings(): array
    {
        return [
            'number_of_shards' => $this->getNumberOfShards(),
            'number_of_replicas' => 0,
            'max_ngram_diff' => 30,
            'analysis' => [
                'analyzer' => [
                    'path_analyzer' => [
                        'tokenizer' => 'path_tokenizer'
                    ],
                    'datahub_ngram_analyzer' => [
                        'tokenizer' => 'datahub_ngram_tokenizer',
                        'filter' => ['lowercase']
                    ],
                    'datahub_whitespace_analyzer' => [
                        'tokenizer' => 'datahub_whitespace_tokenizer',
                        'filter' => ['lowercase']
                    ]

                ],
                'tokenizer' => [
                    'path_tokenizer' => [
                        'type' => 'path_hierarchy',
                    ],
                    'datahub_ngram_tokenizer' => [
                        'type' => 'ngram',
                        'min_gram' => 3,
                        'max_gram' => 25,
                        'token_chars' => ['letter', 'digit']
                    ],
                    'datahub_whitespace_tokenizer' => [
                        'type' => 'whitespace'
                    ]
                ]
            ]
        ];
    }

    /**
     * @return string
     */
    public function getIndexName(): string
    {
        $nameParts = [
            $this->indexNamePrefix,
            $this->configName,
            $this->entityType
        ];
        $nameParts = array_filter($nameParts);

        return strtolower(implode('_', $nameParts));
    }

    protected function getCombinedParentPath()
    {
        if ($this->combinedParentPath == null) {
            $this->combinedParentPath = $this->workspaceResolver->findCombinedParent($this->workspaces);
        }

        return $this->combinedParentPath;
    }

    protected function rewriteParentPath($elementPath): string
    {
        $combinedParentPath = $this->getCombinedParentPath();

        $pos = strpos($elementPath, $combinedParentPath);
        if ($pos !== false && $combinedParentPath !== '/') {
            $combinedParentPathParts = explode('/', $combinedParentPath);
            $newParentPath = substr_replace($elementPath, '', $pos, strlen($combinedParentPath));

            return '/' . end($combinedParentPathParts) . $newParentPath;
        }

        return $elementPath;
    }

    protected function createSystemAttributes(ElementInterface $element): array
    {
        $fullPath = $this->rewriteParentPath($element->getRealFullPath());

        return [
            'id' => $element->getId(),
            'key' => $element->getKey(),
            'fullPath' => $fullPath,
            'type' => $this->type,
            'parentId' => $element->getRealFullPath() == $this->getCombinedParentPath() ? 1 : $element->getParentId(),
            'hasChildren' => method_exists($element, 'hasChildren') ? $element->hasChildren() : false,
            'creationDate' => $element->getCreationDate(),
            'modificationDate' => $element->getModificationDate(),
            self::INTERNAL_ENTITY_TYPE => $this->entityType,
            self::INTERNAL_ORIGINAL_FULL_PATH => $element->getRealFullPath()
        ];
    }

    protected function createSystemAttributesMapping(): array
    {
        return [
            'type' => 'object',
            'dynamic' => false,
            'properties' => [
                'id' => ['type' => 'long'],
                'key' => [
                    'type' => 'keyword',
                    'fields' => [
                        'analyzed' => [
                            'type' => 'text',
                            'analyzer' => 'datahub_ngram_analyzer',
                            'search_analyzer' => 'datahub_whitespace_analyzer'
                        ]
                    ]
                ],
                'fullPath' => [
                    'type' => 'keyword',
                    'fields' => [
                        'path_analyzed' => [
                            'type' => 'text',
                            'analyzer' => 'path_analyzer',
                            'search_analyzer' => 'keyword'
                        ]
                    ]
                ],
                'type' => ['type' => 'keyword'],
                'subtype' => ['type' => 'keyword'],
                'parentId' => ['type' => 'long'],
                'hasChildren' => ['type' => 'boolean'],
                'creationDate' => ['type' => 'date'],
                'modificationDate' => ['type' => 'date'],
                self::INTERNAL_ENTITY_TYPE => ['type' => 'keyword'],
                self::INTERNAL_CHECKSUM => ['type' => 'keyword'],
                self::INTERNAL_ORIGINAL_FULL_PATH => [
                    'type' => 'keyword',
                    'fields' => [
                        'path_analyzed' => [
                            'type' => 'text',
                            'analyzer' => 'path_analyzer',
                            'search_analyzer' => 'keyword'
                        ]
                    ]
                ],
            ]
        ];
    }

    protected function createTermsAggregation(string $field): array
    {
        return [
            'terms' => [
                'field' => $field,
                'size' => 1000,
                'order' => [
                    '_count' => 'desc'
                ]
            ]
        ];
    }

    public function getVirtualParentArray($elementId): array
    {
        $virtualParentArray = [];

        $element = $this->loadElement($elementId);

        //if element is already combined parent, return empty array
        if ($element && $element->getRealFullPath() == $this->getCombinedParentPath()) {
            return $virtualParentArray;
        }

        while ($element && $element->getRealFullPath() != $this->getCombinedParentPath() && $element->getRealPath() != '/') {
            $element = method_exists($element, 'getParent') ? $element->getParent() : null;

            $systemData = $this->createSystemAttributes($element);
            $systemData['subtype'] = 'folder';
            if ($this->entityType === DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET || $this->entityType === DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER) {
                $systemData[self::INTERNAL_ENTITY_TYPE] = DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER;
            } else {
                $systemData[self::INTERNAL_ENTITY_TYPE] = DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER;
            }

            $virtualParentArray[] = [
                'id' => $element->getId(),
                'data' => [
                    'system' => $systemData
                ]
            ];

            //$element = method_exists($element, 'getParent') ? $element->getParent() : null;
        }

        return $virtualParentArray;
    }

    public function buildAggregationsRequest(): array
    {
        return [];
    }

    /**
     * @param ElementInterface $element
     *
     * @return bool
     */
    protected function checkElementPermission(ElementInterface $element): bool
    {
        return $this->workspaceResolver->checkElementPermission($element, $this->workspaces);
    }

    /**
     * @return array
     *
     * @throws \Doctrine\DBAL\DBALException
     */
    public function calculateAllElementIds(): array
    {
        return $this->workspaceResolver->calculateAllElementIds($this->entityType, $this->workspaces);
    }

    abstract public function loadElement($elementId): ?ElementInterface;

    abstract public function extractMapping(): array;

    abstract public function extractData($elementId): array;

    /**
     * returns list of first level attribute keys that should be ignored for labels
     *
     * @return array
     */
    public function getLabelBlackList(): array
    {
        return [
            'system.fullPath',
            'system.parentId',
            'system.hasChildren',
            'system.creationDate',
            'system.modificationDate',
            'system.' . self::INTERNAL_ENTITY_TYPE,
            'system.' . self::INTERNAL_ORIGINAL_FULL_PATH,
            'system.' . self::INTERNAL_CHECKSUM,
        ];
    }

    /**
     * @param Asset $asset
     *
     * @return string
     */
    protected function generateAssetChecksum(Asset $asset): string
    {
        $ctx = hash_init('md5');
        hash_update_stream($ctx, $asset->getStream());

        return hash_final($ctx);
    }
}
