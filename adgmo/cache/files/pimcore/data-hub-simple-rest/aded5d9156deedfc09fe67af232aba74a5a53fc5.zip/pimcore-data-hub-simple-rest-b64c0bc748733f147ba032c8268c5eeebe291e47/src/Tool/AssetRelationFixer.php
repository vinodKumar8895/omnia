<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Tool;

use Pimcore\Model\Asset;
use Pimcore\Model\DataObject\Data\Hotspotimage;
use Pimcore\Model\DataObject\Data\ImageGallery;
use Pimcore\Model\DataObject\Data\Video;
use Pimcore\Tool\Serialize;

class AssetRelationFixer
{
    public function processImage(string $rawData): ?Asset
    {
        $value = null;
        if ($el = Asset::getByPath($rawData)) {
            $value = $el;
        } else {
            $value = null;
        }

        return $value;
    }

    public function processHotspotImage(string $rawData): ?Hotspotimage
    {
        $value = null;
        $value = Serialize::unserialize(base64_decode($rawData));
        if ($value instanceof Hotspotimage) {
            return $value;
        } else {
            return null;
        }
    }

    public function processImageGallery(string $rawData): ?ImageGallery
    {
        $value = Serialize::unserialize(base64_decode($rawData));
        if ($value instanceof ImageGallery) {
            return $value;
        } else {
            return null;
        }
    }

    public function processVideo(string $rawData): ?Video
    {
        $video = null;

        if ($rawData && strpos($rawData, '~')) {
            list($type, $data) = explode('~', $rawData);
            if ($type && $data) {
                $video = new Video();
                $video->setType($type);
                if ($type == 'asset') {
                    if ($asset = Asset::getById(intval($data))) {
                        $video->setData($asset);
                    } else {
                        return null;
                    }
                } else {
                    $video->setData($data);
                }
            }
        }

        return $video;
    }
}
