<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\Command;

use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Console\AbstractCommand;
use Pimcore\Console\Traits\Parallelization;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class ProcessQueueCommand extends AbstractCommand
{
    use Parallelization
    {
        Parallelization::runBeforeFirstCommand as parentRunBeforeFirstCommand;
        Parallelization::runAfterBatch as parentRunAfterBatch;
    }
    /**
     * @var IndexService
     */
    protected $indexService;

    public function __construct(IndexService $indexService)
    {
        parent::__construct();
        $this->indexService = $indexService;
    }

    protected function configure()
    {
        self::configureParallelization($this);

        $this
            ->setName('datahub:simple-rest:process-queue')
            ->setDescription('Processes all items of the queue.')
        ;
    }

    /**
     * Fetches the items that should be processed.
     *
     * Typically, you will fetch all the items of the database objects that
     * you want to process here. These will be passed to runSingleCommand().
     *
     * This method is called exactly once in the master process.
     *
     * @param InputInterface $input The console input
     *
     * @return string[] The items to process
     */
    protected function fetchItems(InputInterface $input): array
    {
        //check for duplicates
        $this->indexService->invalidateDuplicateIndexEntries();

        $queueEntries = $this->indexService->getAllQueueEntries();
        $serializedQueueEntries = [];
        foreach ($queueEntries as $queueEntry) {
            $serializedQueueEntries[] = serialize($queueEntry);
        }

        return $serializedQueueEntries;
    }

    /**
     * Processes an item in the child process.
     */
    protected function runSingleCommand(string $item, InputInterface $input, OutputInterface $output): void
    {
        $queueEntry = unserialize($item);
        $this->indexService->processQueueEntry($queueEntry['elementId'], $queueEntry['entityType'], $queueEntry['configName']);
    }
}
