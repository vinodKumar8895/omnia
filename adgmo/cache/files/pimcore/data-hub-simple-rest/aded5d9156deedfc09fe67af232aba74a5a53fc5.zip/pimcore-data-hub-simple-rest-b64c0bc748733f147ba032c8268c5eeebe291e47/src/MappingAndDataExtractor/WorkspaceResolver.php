<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubSimpleRestBundle\MappingAndDataExtractor;

use Pimcore\Db;
use Pimcore\Model\Element\ElementInterface;

class WorkspaceResolver
{
    protected function getDb()
    {
        return Db::get();
    }

    public function findCombinedParent(array $workspaces)
    {
        $workspaceTree = [
            'children' => [],
            'path' => '',
            'workspaceElement' => false
        ];

        foreach ($workspaces as $workspace) {
            $parts = explode('/', $workspace['cpath']);
            $parts = array_filter($parts);
            $parentElement = &$workspaceTree;
            if (empty($parts)) {
                $parentElement['workspaceElement'] = true;
            } else {
                foreach ($parts as $part) {
                    /**
                     * @var array $parentElement['children']
                     */
                    if (!array_key_exists($part, $parentElement['children'])) {
                        $parentElement['children'][$part] = [
                            'children' => [],
                            'path' => $parentElement['path'] . '/' . $part,
                            'workspaceElement' => $parentElement['path'] . '/' . $part == $workspace['cpath']
                        ];
                    }
                    $parentElement = &$parentElement['children'][$part];
                }
            }
        }

        $treeElement = $workspaceTree;
        /**
         * @var null|array $treeElement['children']
         */
        $childrenCount = count($treeElement['children']);

        while ($childrenCount == 1 && $treeElement['workspaceElement'] === false) {
            $treeElement = reset($treeElement['children']);
            $childrenCount = count($treeElement['children'] ?? []);
        }

        return $treeElement['path'] ?: '/';
    }

    /**
     * @param ElementInterface $element
     * @param array $workspaces
     *
     * @return bool
     */
    public function checkElementPermission(ElementInterface $element, array $workspaces): bool
    {

        //find matching workspace entries
        $matchingEntries = [];
        foreach ($workspaces as $entry) {
            if (substr($element->getRealFullPath(), 0, strlen($entry['cpath'])) === $entry['cpath']) {
                $matchingEntries[] = $entry;
            }
        }

        //order them by length
        usort($matchingEntries, function ($a, $b) {
            return strlen($b['cpath']) <=> strlen($a['cpath']);
        });

        //use longest entry and check permission
        $firstEntry = reset($matchingEntries);

        return $firstEntry['read'] ?? false;
    }

    /**
     * @param array $workspaces
     *
     * @return array
     */
    protected function orderWorkspaces(array $workspaces): array
    {
        $workspaceLevels = [];

        foreach ($workspaces as $workspace) {
            $levels = explode('/', $workspace['cpath']);
            $workspaceLevels[count($levels)][$workspace['cpath']] = $workspace;
        }

        return $workspaceLevels;
    }

    /**
     * @param int $level
     * @param string $basePath
     * @param array $workspaceLevels
     *
     * @return array
     */
    protected function getLowerLevelExcludes(int $level, string $basePath, array $workspaceLevels)
    {
        $excludePaths = [];
        for ($i = $level; $i <= max(array_keys($workspaceLevels)); $i++) {
            $currentLevelEntries = $workspaceLevels[$i] ?? [];
            foreach ($currentLevelEntries as $entry) {
                if (substr($entry['cpath'], 0, strlen($basePath)) === $basePath && $entry['read'] === false) {
                    $excludePaths[] = $entry['cpath'];
                }
            }
        }

        return $excludePaths;
    }

    /**
     * @param string $entityType
     * @param array $workspaces
     *
     * @return array
     *
     * @throws \Doctrine\DBAL\DBALException
     */
    public function calculateAllElementIds(string $entityType, array $workspaces): array
    {
        $baseCondition = [];
        $baseConditionParams = [];
        if ($entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET_FOLDER) {
            $tableName = 'assets';
            $idColumn = 'id';
            $pathColumn = 'path';
            $keyColumn = 'filename';

            $baseCondition[] = "type = 'folder'";
        } elseif ($entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_ASSET) {
            $tableName = 'assets';
            $idColumn = 'id';
            $pathColumn = 'path';
            $keyColumn = 'filename';

            $baseCondition[] = "type != 'folder'";
        } elseif ($entityType == DataExtractorFactory::DATA_EXTRACTOR_TYPE_OBJECT_FOLDER) {
            $tableName = 'objects';
            $idColumn = 'o_id';
            $pathColumn = 'o_path';
            $keyColumn = 'o_key';

            $baseCondition[] = "o_type = 'folder'";
        } else {
            $tableName = 'objects';
            $idColumn = 'o_id';
            $pathColumn = 'o_path';
            $keyColumn = 'o_key';

            $baseCondition[] = 'o_className = ?';
            $baseConditionParams[] = $entityType;
        }

        $workspaceLevels = $this->orderWorkspaces($workspaces);

        $ids = [];

        if ($workspaceLevels) {
            for ($level = max(array_keys($workspaceLevels)); $level > 0; $level--) {
                $currentLevelEntries = $workspaceLevels[$level] ?? [];

                foreach ($currentLevelEntries as $currentLevelEntry) {
                    if ($currentLevelEntry['read'] == true) {
                        $excludePaths = $this->getLowerLevelExcludes($level, $currentLevelEntry['cpath'], $workspaceLevels);

                        $condition = $baseCondition;
                        $conditionParams = $baseConditionParams;

                        $condition[] = "CONCAT($pathColumn, $keyColumn) LIKE ?";
                        $conditionParams[] = $currentLevelEntry['cpath'] . '%';

                        foreach ($excludePaths as $excludePath) {
                            $condition[] = "CONCAT($pathColumn, $keyColumn) NOT LIKE ?";
                            $conditionParams[] = $excludePath . '%';
                        }

                        $query = "SELECT $idColumn FROM $tableName WHERE " . implode(' AND ', $condition);

                        $ids = array_merge($ids, $this->getDb()->fetchCol($query, $conditionParams));
                    }
                }
            }
        }

        return $ids;
    }
}
