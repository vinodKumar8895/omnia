# Pimcore Datahub Simple Rest API

This extension adds a simple read-only rest API endpoint to Pimcore Datahub for assets and data objects. All 
exposed data can be configured, is indexed in Elasticsearch and delivered from there for better query 
performance and scalability. 

Therefore, it can be used to connect Pimcore to other systems or to connect frontend applications.


## Features in a nutshell
- Configure schema and exposed data like with other Datahub adapters. 
- All data gets indexed in Elasticsearch indices and delivered from there 
  (no additional load on database when accessing data via rest endpoints).
- Endpoint documentation and test via swagger ui. 
- Available endpoints
  - **tree-items**: Method to load all elements of a tree level with additional support for 
    - paging
    - filtering
    - fulltext search
    - ordering
    - aggregations - provide possible values for fields to create filters
  - **search**: Method to search of elements, returns elements of all types, no folder structures
    with additional support for
      - paging
      - filtering
      - fulltext search
      - ordering
      - aggregations - provide possible values for fields to create filters 
  - **get-element**: Method to get one single element by type and id.
- Endpoint security via bearer token that has to be send as header with every request.  

<div class="image-as-lightbox"></div>

![Config](./doc/img/schema.png)

<div class="image-as-lightbox"></div>

![Swagger](./doc/img/swagger.png)
  

## Further Information
* [Installation & Bundle Configuration](./doc/01_Installation/README.md)
* [Endpoint Configuration Details](./doc/03_Endpoint_Configuration.md)
* [Indexing Details](./doc/04_Indexing_Details.md)
* [Filter Details](./doc/05_Filtering_and_Paging.md)