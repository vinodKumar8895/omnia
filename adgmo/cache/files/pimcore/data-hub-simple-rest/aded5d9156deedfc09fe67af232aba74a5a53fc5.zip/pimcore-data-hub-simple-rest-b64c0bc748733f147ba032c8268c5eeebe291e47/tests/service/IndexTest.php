<?php namespace Pimcore\Bundle\DataHubSimpleRestBundle\Tests;

use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Model\DataObject\Unittest;
use Pimcore\Tests\Util\TestHelper;

class IndexTest extends \Codeception\Test\Unit
{
    /**
     * @var \Pimcore\Bundle\DataHubSimpleRestBundle\Tests\ServiceTester
     */
    protected $tester;

    protected function _before()
    {
        /**
         * @var IndexService $indexService
         */
        $indexService = $this->tester->grabService(IndexService::class);
        $indexService->createOrUpdateMapping('unittest');

    }

    protected function _after()
    {
        TestHelper::cleanUp();
        $db = \Pimcore\Db::get();
        $db->exec(sprintf('DROP TABLE IF EXISTS %s', QueueService::QUEUE_TABLE_NAME));

        $this->tester->cleanupEs();
    }

    // tests
    public function testCreateMapping()
    {
        $this->tester->checkEsMapping();
    }


    public function testCreatingAndIndexingElements() {

        //Create element
        /**
         * @var Unittest $object
         */
        $object = $this->tester->createFullyFledgedObject();

        //Save element to add it to queue
        $object->save();

        /**
         * @var QueueService $queueService
         */
        $queueService = $this->tester->grabService(QueueService::class);
        $this->assertEquals(3, $queueService->getQueueItemCount(), 'Elements added to queue');


        //index object
        /**
         * @var IndexService $indexService
         */
        $indexService = $this->tester->grabService(IndexService::class);
        $indexService->processQueueEntry($object->getId(), $indexService->getEntityTypeForElement($object), null);
        $this->tester->flushEs();

        //check if indexing was successful
        $this->assertEquals(2, $queueService->getQueueItemCount(), 'Unittest processed');
        $this->tester->checkEsEntry($object->getId(), 'unittest', 'unittest');

        //index assets
        $entries = $queueService->getAllQueueEntries();
        $assetIds = [];
        foreach($entries as $entry) {
            $indexService->processQueueEntry($entry['elementId'], $entry['entityType'], $entry['configName']);
            $assetIds[] = $entry['elementId'];
        }
        $this->tester->flushEs();

        //check if indexing was successful
        $this->assertEquals(0, $queueService->getQueueItemCount(), 'Assets processed');
        foreach($assetIds as $assetId) {
            $this->tester->checkEsEntry($assetId, '_asset', 'unittest');
        }

        //updating element
        $newContent = 'new content';
        $object->setInput($newContent);
        $object->save();

        $this->assertEquals(1, $queueService->getQueueItemCount(), 'Updated element in queue');

        //process element
        $indexService->processQueueEntry($object->getId(), $indexService->getEntityTypeForElement($object), null);
        $this->tester->flushEs();

        //check if indexing was successful
        $this->assertEquals(0, $queueService->getQueueItemCount(), 'Unittest processed');
        $this->tester->checkEsEntry($object->getId(), 'unittest', 'unittest');
        $this->tester->checkEsEntryUpdatedText($object->getId(), $newContent, 'unittest');

        //delete element
        $object->delete();
        $this->assertEquals(1, $queueService->getQueueItemCount(), 'Deleted element in queue');

        //process element
        $indexService->processQueueEntry($object->getId(), $indexService->getEntityTypeForElement($object), null);
        $this->tester->flushEs();

        //check if indexing was successful
        $this->assertEquals(0, $queueService->getQueueItemCount(), 'Deletion processed');
        $this->tester->checkEsEntryEmpty($object->getId(), 'unittest', 'unittest');

    }

    // todo test indexing tree


    // test reindex

    // test search
    // test filter
    // test get single element

    // test create new configuration & create mapping
    // test update configuration & update mapping
    // test delete configuration & cleanup index

}
