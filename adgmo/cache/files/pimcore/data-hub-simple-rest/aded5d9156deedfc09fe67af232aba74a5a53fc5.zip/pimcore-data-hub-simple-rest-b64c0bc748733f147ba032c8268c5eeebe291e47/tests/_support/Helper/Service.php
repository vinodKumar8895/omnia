<?php
namespace Pimcore\Bundle\DataHubSimpleRestBundle\Tests\Helper;

use Elasticsearch\ClientBuilder;
use Pimcore\Model\DataObject\ClassDefinition;
use Pimcore\Model\DataObject\Unittest;
use Pimcore\Tests\Helper\ClassManager;
use Pimcore\Tests\Helper\DataType\TestDataHelper;
use Pimcore\Tests\Helper\Model;
use Symfony\Component\DependencyInjection\ContainerInterface;

class Service extends Model
{

    /**
     * @var null|ContainerInterface
     */
    protected static $container = null;

    public function grabService(string $serviceId) {

        //TODO change this as soon as Pimcore helper as grabService method and requirement is bumped to pimcore/pimcore:10.4
        if(empty(self::$container)) {
            $container = \Pimcore::getContainer();
            self::$container = $container->has('test.service_container') ? $container->get('test.service_container') : $container;
        }
        return self::$container->get($serviceId);
    }

    public function initializeDefinitions()
    {
        $this->setupFieldcollection_Unittestfieldcollection();
        $this->setupPimcoreClass_Unittest();
        $this->setupObjectbrick_UnittestBrick();
    }

    /**
     * Set up a class which (hopefully) contains all data types
     *
     * @param string $name
     * @param string $filename
     *
     * @return ClassDefinition|null
     *
     * @throws \Exception
     */
    public function setupPimcoreClass_Unittest($name = 'unittest', $filename = 'class-import.json')
    {

        /** @var ClassManager $cm */
        $cm = $this->getClassManager();

        if (!$class = $cm->getClass($name)) {
            $root = new \Pimcore\Model\DataObject\ClassDefinition\Layout\Panel('root');
            $panel = (new \Pimcore\Model\DataObject\ClassDefinition\Layout\Panel())->setName('MyLayout');
            $rootPanel = (new \Pimcore\Model\DataObject\ClassDefinition\Layout\Tabpanel())->setName('Layout');
            $rootPanel->addChild($panel);

            $calculatedValue = $this->createDataChild('calculatedValue');
            $calculatedValue->setCalculatorClass('@test.calculatorservice');
            $panel->addChild($calculatedValue);

            $calculatedValueExpression = $this->createDataChild('calculatedValue', 'calculatedValueExpression');
            $calculatedValueExpression->setCalculatorExpression("object.getFirstname() ~ ' some calc'");
            $calculatedValueExpression->setCalculatorType(ClassDefinition\Data\CalculatedValue::CALCULATOR_TYPE_EXPRESSION);
            $panel->addChild($calculatedValueExpression);

            $calculatedValueExpressionConstant = $this->createDataChild('calculatedValue', 'calculatedValueExpressionConstant');
            $calculatedValueExpressionConstant->setCalculatorExpression("constant('PIMCORE_PROJECT_ROOT')");
            $calculatedValueExpressionConstant->setCalculatorType(ClassDefinition\Data\CalculatedValue::CALCULATOR_TYPE_EXPRESSION);
            $panel->addChild($calculatedValueExpressionConstant);

            $panel->addChild($this->createDataChild('consent'));

            $panel->addChild($this->createDataChild('country'));
            $panel->addChild($this->createDataChild('countrymultiselect', 'countries'));

            $panel->addChild($this->createDataChild('date'));
            $panel->addChild($this->createDataChild('datetime'));

            $panel->addChild($this->createDataChild('email'));

            /** @var ClassDefinition\Data\EncryptedField $encryptedField */
            $encryptedField = $this->createDataChild('encryptedField');

            $encryptedField->setDelegateDatatype('input');
            $panel->addChild($encryptedField);

            $panel->addChild($this->createDataChild('externalImage'));

            $panel->addChild($this->createDataChild('firstname'));

            $panel->addChild($this->createDataChild('gender'));

            $panel->addChild($this->createDataChild('geopoint', 'point', false, false));
            $panel->addChild($this->createDataChild('geobounds', 'bounds', false, false));
            $panel->addChild($this->createDataChild('geopolygon', 'polygon', false, false));
            $panel->addChild($this->createDataChild('geopolyline', 'polyline', false, false));

//            $panel->addChild($this->createDataChild('indexFieldSelection', 'indexFieldSelection', false, false));
//            $panel->addChild($this->createDataChild('indexFieldSelectionCombo', 'indexFieldSelectionCombo', false, false));
//            $panel->addChild($this->createDataChild('indexFieldSelectionField', 'indexFieldSelectionField', false, false));

            $panel->addChild($this->createDataChild('imageGallery'));
            $panel->addChild($this->createDataChild('input'));
            /** @var ClassDefinition\Data\Input $inputWithDefault */
            $inputWithDefault = $this->createDataChild('input', 'inputWithDefault');
            $inputWithDefault->setDefaultValue('default');
            $panel->addChild($inputWithDefault);

            $panel->addChild($this->createDataChild('manyToOneRelation', 'lazyHref')
                ->setDocumentTypes([])->setAssetTypes([])->setClasses([])
                ->setDocumentsAllowed(true)->setAssetsAllowed(true)->setObjectsAllowed(true));

            $panel->addChild($this->createDataChild('manyToManyRelation', 'lazyMultihref')
                ->setDocumentTypes([])->setAssetTypes([])->setClasses([])
                ->setDocumentsAllowed(true)->setAssetsAllowed(true)->setObjectsAllowed(true));

            $panel->addChild($this->createDataChild('manyToManyObjectRelation', 'lazyObjects')
                ->setClasses([]));

            $panel->addChild($this->createDataChild('manyToOneRelation', 'href')
                ->setDocumentTypes([])->setAssetTypes([])->setClasses([])
                ->setDocumentsAllowed(true)->setAssetsAllowed(true)->setObjectsAllowed(true));

            $panel->addChild($this->createDataChild('manyToManyRelation', 'multihref')
                ->setDocumentTypes([])->setAssetTypes([])->setClasses([])
                ->setDocumentsAllowed(true)->setAssetsAllowed(true)->setObjectsAllowed(true));

            $panel->addChild($this->createDataChild('manyToManyObjectRelation', 'objects')
                ->setClasses([]));

            $panel->addChild($this->createDataChild('newsletterActive', 'newsletterActive', false, false));
            $panel->addChild($this->createDataChild('newsletterConfirmed', 'newsletterConfirmed', false, false));

            $panel->addChild($this->createDataChild('inputQuantityValue'));
            $panel->addChild($this->createDataChild('quantityValue'));

            $panel->addChild($this->createDataChild('advancedManyToManyObjectRelation', 'objectswithmetadata')
                ->setAllowedClassId($name)
                ->setClasses([])
                ->setColumns([ ['position' => 1, 'key' => 'meta1', 'type' => 'text', 'label' => 'label1'],
                    ['position' => 2, 'key' => 'meta2', 'type' => 'text', 'label' => 'label2'], ]));

            $panel->addChild($this->createDataChild('lastname'));

            $panel->addChild($this->createDataChild('numeric', 'number'));

            $passwordField = $this->createDataChild('password');
            $passwordField->setAlgorithm(ClassDefinition\Data\Password::HASH_FUNCTION_PASSWORD_HASH);
            $panel->addChild($passwordField);

            $panel->addChild($this->createDataChild('rgbaColor', 'rgbaColor', false, false));

            $panel->addChild($this->createDataChild('select')->setOptions([
                ['key' => 'Selection 1', 'value' => '1'],
                ['key' => 'Selection 2', 'value' => '2'], ]));

            $panel->addChild($this->createDataChild('slider'));

            $panel->addChild($this->createDataChild('textarea'));
            $panel->addChild($this->createDataChild('time'));

            $panel->addChild($this->createDataChild('wysiwyg'));

            $panel->addChild($this->createDataChild('video', 'video', false, false));

            $panel->addChild($this->createDataChild('multiselect')->setOptions([
                ['key' => 'Katze', 'value' => 'cat'],
                ['key' => 'Kuh', 'value' => 'cow'],
                ['key' => 'Tiger', 'value' => 'tiger'],
                ['key' => 'Schwein', 'value' => 'pig'],
                ['key' => 'Esel', 'value' => 'donkey'],
                ['key' => 'Affe', 'value' => 'monkey'],
                ['key' => 'Huhn', 'value' => 'chicken'],
            ]));

            $panel->addChild($this->createDataChild('language', 'languagex'));
            $panel->addChild($this->createDataChild('languagemultiselect', 'languages'));
            $panel->addChild($this->createDataChild('user'));
            $panel->addChild($this->createDataChild('link'));
            $panel->addChild($this->createDataChild('image'));
            $panel->addChild($this->createDataChild('hotspotimage'));
            $panel->addChild($this->createDataChild('checkbox'));
            $panel->addChild($this->createDataChild('booleanSelect'));
            $panel->addChild($this->createDataChild('table'));
            $panel->addChild($this->createDataChild('structuredTable', 'structuredtable', false, false)
                ->setCols([
                    ['position' => 1, 'key' => 'col1', 'type' => 'number', 'label' => 'collabel1'],
                    ['position' => 2, 'key' => 'col2', 'type' => 'text', 'label' => 'collabel2'],
                ])
                ->setRows([
                    ['position' => 1, 'key' => 'row1', 'label' => 'rowlabel1'],
                    ['position' => 2, 'key' => 'row2', 'label' => 'rowlabel2'],
                    ['position' => 3, 'key' => 'row3', 'label' => 'rowlabel3'],
                ])
            );
            $panel->addChild($this->createDataChild('fieldcollections', 'fieldcollection')
                ->setAllowedTypes(['unittestfieldcollection']));
            $panel->addChild($this->createDataChild('reverseObjectRelation', 'nonowner')->setOwnerClassName($name)->setOwnerFieldName('objects'));
            $panel->addChild($this->createDataChild('fieldcollections', 'myfieldcollection')
                ->setAllowedTypes(['unittestfieldcollection']));

            $panel->addChild($this->createDataChild('urlSlug')->setAction('MyController::myAction'));
            $panel->addChild($this->createDataChild('urlSlug', 'urlSlug2')->setAction('MyController::myAction'));

            $lFields = new \Pimcore\Model\DataObject\ClassDefinition\Data\Localizedfields();
            $lFields->setName('localizedfields');
            $lFields->addChild($this->createDataChild('input', 'linput'));
            $lFields->addChild($this->createDataChild('textarea', 'ltextarea'));
            $lFields->addChild($this->createDataChild('wysiwyg', 'lwysiwyg'));
            $lFields->addChild($this->createDataChild('numeric', 'lnumber'));
            $lFields->addChild($this->createDataChild('slider', 'lslider'));
            $lFields->addChild($this->createDataChild('date', 'ldate'));
            $lFields->addChild($this->createDataChild('datetime', 'ldatetime'));
            $lFields->addChild($this->createDataChild('time', 'ltime'));
            $lFields->addChild($this->createDataChild('select', 'lselect')->setOptions([
                ['key' => 'one', 'value' => '1'],
                ['key' => 'two', 'value' => '2'], ]));

            $lFields->addChild($this->createDataChild('multiselect', 'lmultiselect')->setOptions([
                ['key' => 'one', 'value' => '1'],
                ['key' => 'two', 'value' => '2'], ]));
            $lFields->addChild($this->createDataChild('countrymultiselect', 'lcountries'));
            $lFields->addChild($this->createDataChild('languagemultiselect', 'llanguages'));
            $lFields->addChild($this->createDataChild('table', 'ltable'));
            $lFields->addChild($this->createDataChild('image', 'limage'));
            $lFields->addChild($this->createDataChild('checkbox', 'lcheckbox'));
            $lFields->addChild($this->createDataChild('link', 'llink'));
            $lFields->addChild($this->createDataChild('manyToManyObjectRelation', 'lobjects')
                ->setClasses([]));

            $lFields->addChild($this->createDataChild('manyToManyRelation', 'lmultihrefLazy')
                ->setDocumentTypes([])->setAssetTypes([])->setClasses([])
                ->setDocumentsAllowed(true)->setAssetsAllowed(true)->setObjectsAllowed(true));

            $lFields->addChild($this->createDataChild('urlSlug', 'lurlSlug')->setAction('MyController::myLocalizedAction'));

            $panel->addChild($lFields);
            $panel->addChild($this->createDataChild('objectbricks', 'mybricks'));

            $root->addChild($rootPanel);
            $class = $this->createClass($name, $root, $filename, false, $name);
        }

        return $class;
    }

    /**
     * @param string $keyPrefix
     * @param bool $save
     * @param bool $publish
     * @param int $seed
     *
     * @return Unittest
     */
    public function createFullyFledgedObject($keyPrefix = '', $save = true, $publish = true, $seed = 1)
    {
        $testDataHelper = $this->getModule(TestDataHelper::class);

        if (null === $keyPrefix) {
            $keyPrefix = '';
        }

        $object = new Unittest();
        $object->setOmitMandatoryCheck(true);
        $object->setParentId(1);
        $object->setUserOwner(1);
        $object->setUserModification(1);
        $object->setCreationDate(time());
        $object->setKey($keyPrefix . uniqid() . rand(10, 99));

        if ($publish) {
            $object->setPublished(true);
        }

        $testDataHelper->fillInput($object, 'input', $seed);
        $testDataHelper->fillNumber($object, 'number', $seed);
        $testDataHelper->fillTextarea($object, 'textarea', $seed);
        $testDataHelper->fillSlider($object, 'slider', $seed);
        $testDataHelper->fillHref($object, 'href', $seed);
        $testDataHelper->fillMultihref($object, 'multihref', $seed);
        $testDataHelper->fillImage($object, 'image', $seed);
        $testDataHelper->fillHotspotImage($object, 'hotspotimage', $seed);
        $testDataHelper->fillLanguage($object, 'languagex', $seed);
        $testDataHelper->fillCountry($object, 'country', $seed);
        $testDataHelper->fillDate($object, 'date', $seed);
        $testDataHelper->fillDate($object, 'datetime', $seed);
        $testDataHelper->fillTime($object, 'time', $seed);
        $testDataHelper->fillSelect($object, 'select', $seed);
        $testDataHelper->fillMultiSelect($object, 'multiselect', $seed);
        $testDataHelper->fillUser($object, 'user', $seed);
        $testDataHelper->fillCheckbox($object, 'checkbox', $seed);
        $testDataHelper->fillBooleanSelect($object, 'booleanSelect', $seed);
        $testDataHelper->fillWysiwyg($object, 'wysiwyg', $seed);
        $testDataHelper->fillPassword($object, 'password', $seed);
        $testDataHelper->fillMultiSelect($object, 'countries', $seed);
        $testDataHelper->fillMultiSelect($object, 'languages', $seed);
        $testDataHelper->fillGeoCoordinates($object, 'point', $seed);
        $testDataHelper->fillGeobounds($object, 'bounds', $seed);
        $testDataHelper->fillGeopolygon($object, 'polygon', $seed);
        $testDataHelper->fillTable($object, 'table', $seed);
        $testDataHelper->fillLink($object, 'link', $seed);
        $testDataHelper->fillStructuredTable($object, 'structuredtable', $seed);

        $testDataHelper->fillInput($object, 'linput', $seed, 'de');
        $testDataHelper->fillInput($object, 'linput', $seed, 'en');

        $testDataHelper->fillBricks($object, 'mybricks', $seed);
        $testDataHelper->fillFieldCollection($object, 'myfieldcollection', $seed);

        $testDataHelper->fillObjects($object, 'objects', $seed);
        $testDataHelper->fillObjects($object, 'lobjects', $seed, 'de');
        $testDataHelper->fillObjects($object, 'lobjects', $seed, 'en');
        $testDataHelper->fillObjectsWithMetadata($object, 'objectswithmetadata', $seed);

        if ($save) {
            $object->save();
        }

        return $object;
    }


    /**
     * @return \Elasticsearch\Client
     */
    protected function getElasticSearchClient()
    {
        if (empty($this->elasticSearchClient)) {
            $builder = ClientBuilder::create();
            $builder->setHosts([getenv('PIMCORE_ELASTIC_SEARCH_HOST')]);
            $this->elasticSearchClient = $builder->build();
        }

        return $this->elasticSearchClient;
    }

    public function checkEsMapping() {

        $client = $this->getElasticSearchClient();
        $response = $client->cat()->indices(['index' => 'datahub_restindex__*']);
        $this->assertCount(4, $response);

        $this->assertTrue($client->indices()->existsAlias(['name' => 'datahub_restindex__unittest__objectfolder']));
        $this->assertTrue($client->indices()->existsAlias(['name' => 'datahub_restindex__unittest__asset']));
        $this->assertTrue($client->indices()->existsAlias(['name' => 'datahub_restindex__unittest__assetfolder']));
        $this->assertTrue($client->indices()->existsAlias(['name' => 'datahub_restindex__unittest_unittest']));

        $response = $client->indices()->getMapping(['index' => 'datahub_restindex__unittest_unittest']);
        $this->assertEquals('keyword', reset($response)['mappings']['properties']['data']['properties']['booleanSelect']['type']);
    }

    public function checkEsEntry(string $id, string $type = '_asset', string $config = 'unittest') {

        $client = $this->getElasticSearchClient();
        $response = $client->get([
            'id' => $id,
            'type' => '_doc',
            'index' => sprintf('datahub_restindex__%s_%s', $config, $type)
        ]);

        $this->assertEquals($id, $response['_id'], 'Check ES document id of element');
        $this->assertEquals($id, $response['_source']['system']['id'], 'Check id in content of element');
    }

    public function checkEsEntryEmpty(string $id, string $type = '_asset', string $config = 'unittest') {

        $client = $this->getElasticSearchClient();

        $response = $client->exists([
            'id' => $id,
            'type' => '_doc',
            'index' => sprintf('datahub_restindex__%s_%s', $config, $type)
        ]);

        $this->assertFalse($response);
    }

    public function checkEsEntryUpdatedText(string $id, string $updatedInput, string $config = 'unittest') {

        $client = $this->getElasticSearchClient();
        $response = $client->get([
            'id' => $id,
            'type' => '_doc',
            'index' => sprintf('datahub_restindex__%s_%s', $config, 'unittest')
        ]);

        $this->assertEquals($id, $response['_id'], 'Check ES document id of element');
        $this->assertEquals($updatedInput, $response['_source']['data']['input'], 'Check updated data in element');
    }

    public function cleanupEs() {

        $client = $this->getElasticSearchClient();
        $client->indices()->delete(['index' => 'datahub_restindex__*']);

        $response = $client->indices()->getMapping();
        $this->assertCount(0, $response);
    }

    public function flushEs() {
        $client = $this->getElasticSearchClient();
        $client->indices()->refresh();
        $client->indices()->flush();
    }

}
