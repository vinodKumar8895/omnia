<?php namespace Pimcore\Bundle\DataHubSimpleRestBundle\Tests;

use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\IndexService;
use Pimcore\Bundle\DataHubSimpleRestBundle\Service\QueryService;
use Pimcore\Model\DataObject\Unittest;
use Pimcore\Tests\Util\TestHelper;

class QueryTest extends \Codeception\Test\Unit
{
    /**
     * @var \Pimcore\Bundle\DataHubSimpleRestBundle\Tests\ServiceTester
     */
    protected $tester;


    protected int $id;
    protected int $subId;


    protected function _before()
    {
        /**
         * @var QueueService $queueService
         */
        $queueService = $this->tester->grabService(QueueService::class);

        /**
         * @var IndexService $indexService
         */
        $indexService = $this->tester->grabService(IndexService::class);
        $indexService->createOrUpdateMapping('unittest');

        /**
         * @var Unittest $object
         */
        $object = TestHelper::createEmptyObject('some-key');
        $object->setInput('Query text first');
        $object->save();
        $this->id = $object->getId();

        $subObject = TestHelper::createEmptyObject('some-other-key');
        $subObject->setParent($object);
        $subObject->setInput('Query text second');
        $subObject->save();

        $this->subId = $subObject->getId();

        //index elements
        $entries = $queueService->getAllQueueEntries();
        foreach($entries as $entry) {
            $indexService->processQueueEntry($entry['elementId'], $entry['entityType'], $entry['configName']);
        }

        $this->assertEquals(0, $queueService->getQueueItemCount(), 'All items indexed.');
        $this->tester->flushEs();
    }

    protected function _after()
    {
        TestHelper::cleanUp();
        $db = \Pimcore\Db::get();
        $db->exec(sprintf('DROP TABLE IF EXISTS %s', QueueService::QUEUE_TABLE_NAME));

        $this->tester->cleanupEs();
    }

    // tests
    public function testQuery() {

        /**
         * @var QueryService $queryService
         */
        $queryService = $this->tester->grabService(QueryService::class);


        //test query by id
        $element = $queryService->queryIndexById('unittest', 'unittest', $this->id);
        $this->assertEquals($this->id, $element['system']['id'], 'Check element id');

        $element = $queryService->queryIndexById('unittest', 'unittest', $this->subId);
        $this->assertEquals($this->subId, $element['system']['id'], 'Check element id');

        //test query by fulltext
        $elements = $queryService->queryIndexSearch('unittest', 'Query');
        $this->assertEquals(2, $elements['total_count'], 'Check element count');

        $elements = $queryService->queryIndexSearch('unittest', 'first');
        $this->assertEquals(1, $elements['total_count'], 'Check element count');
        $this->assertEquals($this->id, $elements['items'][0]['system']['id'], 'Check element id');

        //test query by tree navigation
        $elements = $queryService->queryIndexTreeNavigation('unittest', 'object', $this->id);
        $this->assertEquals(1, $elements['total_count'], 'Check element count');
        $this->assertEquals($this->subId, $elements['items'][0]['system']['id'], 'Check element id');

    }

}
