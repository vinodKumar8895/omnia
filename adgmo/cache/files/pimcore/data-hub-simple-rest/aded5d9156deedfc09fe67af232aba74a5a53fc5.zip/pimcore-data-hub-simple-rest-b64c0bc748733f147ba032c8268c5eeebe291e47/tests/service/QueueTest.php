<?php
namespace Pimcore\Bundle\DataHubSimpleRestBundle\Tests;

use Pimcore\Bundle\DataHubSimpleRestBundle\Queue\QueueService;

class QueueTest extends \Codeception\Test\Unit
{
    /**
     * @var \Pimcore\Bundle\DataHubSimpleRestBundle\Tests\ServiceTester
     */
    protected $tester;

    public function testQueue()
    {
        $this->assertEquals(true, true, 'First test check');

        $queueService = new QueueService();

        $queueService->addItemToQueue('123', 'object');
        $count = $queueService->getQueueItemCount();
        $this->assertEquals($count, 1, 'Queue Item count check');

        $entries = $queueService->getAllQueueEntries();

        $this->assertEquals($entries[0]['elementId'], '123', 'Queue Item id check');

        $queueService->markQueueEntryAsProcessed('123', 'object', 'foo');

        $count = $queueService->getQueueItemCount();
        $this->assertEquals($count, 1, 'Queue Item count re-check');


        $queueService->markQueueEntryAsProcessed('123', 'object', null);

        $count = $queueService->getQueueItemCount();
        $this->assertEquals($count, 0, 'Queue Item count re-check');
    }

}
