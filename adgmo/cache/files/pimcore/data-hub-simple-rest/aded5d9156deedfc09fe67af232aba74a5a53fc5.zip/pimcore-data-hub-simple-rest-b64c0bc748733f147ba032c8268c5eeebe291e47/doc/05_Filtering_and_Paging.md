# Filtering and Paging

## Query Filters

Querying can be done using a limited and simplifed subset of the syntax described
[here](https://restdb.io/docs/querying-with-the-api).

Also note that there might restrictions regarding nesting levels.

### Supported Logic Operators

* $not
* $or
* $and

### Examples

```
q={"modificationDate" : "1000"}

... SQL equivalent ...
where ((`modificationDate` = '1000') )
````


```
q=[{"creationDate" : "1000"}, {"modificationDate" : "9999"}]
...
where ( ((`creationDate` = '1000') )  AND  ((`modificationDate` = '9999') )  )
```

```
q={"modificationDate" : "1000"}, "$or": [{"o_id": "3"}, {"o_key": "lorem-ipsum"}]}
...
where ((`o_modificationDate` = '1000') AND ((`o_id` = '3') OR (`o_key` = 'lorem-ipsum')  )  )
```

```
q={"$and" : [{"o_published": "0"}, {"o_modificationDate" : "1000", "$or": [{"o_id": "3"}, {"o_key": "lorem-ipsum"}]}]}
...        
where ( ((`o_published` = '0') )  AND  ((`o_modificationDate` = '1000') AND ((`o_id` = '3') OR (`o_key` = 'lorem-ipsum') )  )  )
```

```
q={"o_type": {"$not": "folder"}}
...
(( NOT `o_type` ='object') )
```


## Paging

The paging can be done via the `page_cursor` parameter in the query. When loading the next page of a result, use the 
value provided by the previous response for the `page_cursor` parameter. The value is available in the `link` header 
or via the data attribute `page_cursor` in the response content.

### Technical Details
The `page_cursor` has two operation modes: 
- for pages below the configured max results window, it uses a numeric value and ES `from` query.
- for pages after the max results window, it uses the `search_after` option of ES - as also suggested 
  [here](https://www.elastic.co/guide/en/elasticsearch/reference/current/paginate-search-results.html).

The max results window can be configured via symfony configuration: 

```yaml 
pimcore_data_hub_simple_rest:
    # Limit of page size and offset when paging only works via page cursor (and not page numbers anymore). Limit 10000 comes from Elasticsearch.
    max_results_window:   10000
```
