# Installation 

This bundle depends on Pimcore [Datahub bundle](https://github.com/pimcore/data-hub). This needs 
to be installed first. 

To install simple rest use following commands: 

```bash
composer require pimcore/data-hub-simple-rest
./bin/console pimcore:bundle:enable PimcoreDataHubSimpleRestBundle
```

> Make sure, that priority of Datahub bundle is higher than priority of Datahub Simple Rest API bundle. 
> This can be specified as parameter during bundle enablement or in Pimcore extension manager. 

## Bundle Configuration

Configure Elasticsearch hosts and index name prefix with symfony configuration:

```yml 
pimcore_data_hub_simple_rest:

    # Prefix for index names
    index_name_prefix:    datahub_restindex_

    # Limit of page size and offset when paging only works via page cursor (and not page numbers anymore). Limit 10000 comes from Elasticsearch.
    max_results_window:   10000

    # List of elasticsearch hosts
    es_hosts:

        # Default:
        - localhost
        
    # Options to configure indexing behaviour
    indexing_options:
        assets:

            # Enable indexing for exif data
            enable_exif:          true

            # Enable indexing for xmp data
            enable_xmp:           true

            # Enable indexing for iptc data
            enable_iptc:          true
        global_options:

            # Enable numeric detection for dynamic objects (like embedded asset meta data, etc.)
            numeric_detection:    false

            # Enable date detection for dynamic objects (like embedded asset meta data, etc.)
            date_detection:       true
            
        # Configure number of shards for created indices
        number_of_shards_config:

            # default number is picked if no index specific settings is set
            default_number:       1

            # Define number of shards for certain indices. Define index name (without -odd/-even postfix) as key, and number of shards as value.
            index_specific:       []                
            
    # Configure index queue processing via symfony messenger
    messenger_queue_processing:

        # Activate queue processing via symfony messenger.
        activated:            false

        # Lifetime of tmp store entry for current worker count entry. After lifetime, the value will be cleared. Default to 1 hour.
        worker_count_lifetime: 3600

        # Count of items processed per worker message.
        worker_item_count:    400

        # Count of maximum parallel worker messages for queue processing.
        worker_count:         3                
``` 

> Supported elasticsearch versions: 6 and 7

### Index Processing
To make sure indexing queue is processed and index is filled, there are two possible ways: 

#### Command Based
For command based queue processing, following command has to be executed on regular base, e.g. every 5 minutes.

```bash 
*/5 * * * * php /home/project/www/bin/console datahub:simple-rest:process-queue 
```

#### Symfony Messenger Based
For symfony messenger based queue processing, at least following configuration needs to be done in symfony configuration:
```yml 
pimcore_data_hub_simple_rest:
    messenger_queue_processing:
        activated: true
```

If activated, the processing is kicked off automatically with the `datahub_simplerest_update_queue_dispatching` maintenance task.

In addition to that, following settings are available. They all have meaningful default values though:
- `worker_count`: Count of maximum parallel worker messages for queue processing
- `worker_item_count`: Count of items processed per worker message.
- `worker_count_lifetime`: Lifetime of tmp store entry for current worker count entry. After lifetime, the value will be cleared. 

Messages are dispatched via `pimcore_index_queues` transport. So make sure, you have
workers processing this transport when activating the messenger based queue processing. 

