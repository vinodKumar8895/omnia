# Upgrade Notes

Things to consider before or when upgrading to new versions. 

### v1.5.x to v1.6.0

- Default number of shards is now set to `1` (was `5`). To change the value back to `5`, see Indexing Options section
  in [Indexing Details](../04_Indexing_Details.md).
