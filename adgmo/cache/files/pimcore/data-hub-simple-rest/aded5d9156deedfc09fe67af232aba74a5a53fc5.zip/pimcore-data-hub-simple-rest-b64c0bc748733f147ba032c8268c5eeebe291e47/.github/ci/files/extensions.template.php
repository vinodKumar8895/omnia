<?php

return [
    "bundle" => [
        "Pimcore\\Bundle\\EcommerceFrameworkBundle\\PimcoreEcommerceFrameworkBundle" => FALSE,
        "Pimcore\\Bundle\\DataHubSimpleRestBundle\\PimcoreDataHubSimpleRestBundle" => TRUE
    ]
];
