export {ReactComponent as BoxIcon} from "~portal-engine/icons/box-open";
export {ReactComponent as FileIcon} from "~portal-engine/icons/file";
export {ReactComponent as VenusIcon} from "~portal-engine/icons/venus";
export {ReactComponent as AllergiesIcon} from "~portal-engine/icons/allergies";