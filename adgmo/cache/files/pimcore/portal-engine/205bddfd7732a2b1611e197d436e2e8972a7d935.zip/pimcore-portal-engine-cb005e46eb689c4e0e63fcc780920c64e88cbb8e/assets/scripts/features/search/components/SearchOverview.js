/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */


import React from "react";
import SearchList from "~portal-engine/scripts/features/search/components/SearchList";

export function SearchOverview() {
    return (
        <div className="main-content__main">
            <div className="container">
                <SearchList/>
            </div>
        </div>
    );
}