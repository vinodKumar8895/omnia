/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */


export const FILE_SIZE_TO_BIG = 'filesize-too-big';
export const FILE_SIZE_WARNING = 'filesize-warning';