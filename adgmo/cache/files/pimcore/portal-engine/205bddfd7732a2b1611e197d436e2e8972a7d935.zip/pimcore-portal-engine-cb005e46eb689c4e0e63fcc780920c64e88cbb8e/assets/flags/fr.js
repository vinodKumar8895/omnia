import React from "react";
export function ReactComponent(props) {
return (<svg version="1.1" xmlns="http://www.w3.org/2000/svg" {...props} viewBox="0 0 53 40">
        <title>fr</title>
        <path fill="#fff" d="M0 0h53.333v40h-53.333z"></path>
        <path fill="#00267f" d="M0 0h17.778v40h-17.778z"></path>
        <path fill="#f31830" d="M35.555 0h17.778v40h-17.778z"></path>
    </svg>
)
}