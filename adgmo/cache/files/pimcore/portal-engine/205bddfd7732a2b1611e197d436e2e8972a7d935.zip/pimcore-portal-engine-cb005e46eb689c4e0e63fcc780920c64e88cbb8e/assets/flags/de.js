import React from "react";
export function ReactComponent(props) {
return (<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 53 40" {...props}>
    <title>de</title>
    <path fill="#fc0" d="M0 26.667h53.333v13.334h-53.333z"></path>
    <path fill="#000" d="M0 0h53.333v13.333h-53.333z"></path>
    <path fill="#f00" d="M0 13.333h53.333v13.333h-53.333z"></path>
</svg>)
}