export {ReactComponent as IconDE} from "~portal-engine/flags/de";
export {ReactComponent as IconFR} from "~portal-engine/flags/fr";
export {ReactComponent as IconEN} from "~portal-engine/flags/en";