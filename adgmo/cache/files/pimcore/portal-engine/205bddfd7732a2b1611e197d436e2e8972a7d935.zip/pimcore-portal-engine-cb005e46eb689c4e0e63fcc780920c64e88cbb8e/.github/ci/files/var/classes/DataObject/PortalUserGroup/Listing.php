<?php

namespace Pimcore\Model\DataObject\PortalUserGroup;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\PortalUserGroup|false current()
 * @method DataObject\PortalUserGroup[] load()
 * @method DataObject\PortalUserGroup[] getData()
 */

class Listing extends DataObject\Listing\Concrete
{
protected $classId = "portalusergroup";
protected $className = "PortalUserGroup";


/**
* Filter by dataObjectWorkspaceDefinition (Data Object Workspace Definition)
* @param mixed $data
* @param string $operator SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByDataObjectWorkspaceDefinition ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by assetWorkspaceDefinition (Asset Workspace Definition)
* @param mixed $data
* @param string $operator SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByAssetWorkspaceDefinition ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("assetWorkspaceDefinition")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by visibleLanguages (Visible languages)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByVisibleLanguages ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("visibleLanguages")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by editableLanguages (Editable languages)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByEditableLanguages ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("editableLanguages")->addListingFilter($this, $data, $operator);
	return $this;
}



}
