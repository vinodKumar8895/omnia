<?php

return [
    "list" => [
        "License" => [
            "name" => "License",
            "title" => "",
            "icon" => ""
        ]
    ]
];
