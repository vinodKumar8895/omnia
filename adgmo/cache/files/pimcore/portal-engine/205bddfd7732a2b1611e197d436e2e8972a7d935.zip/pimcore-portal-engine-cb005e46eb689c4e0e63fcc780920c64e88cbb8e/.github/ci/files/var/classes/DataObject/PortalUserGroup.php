<?php

/**
* Inheritance: no
* Variants: no


Fields Summary:
- permission [dynamicPermissionResource]
- dataObjectWorkspaceDefinition [advancedManyToManyRelation]
- assetWorkspaceDefinition [advancedManyToManyRelation]
- visibleLanguages [languagemultiselect]
- editableLanguages [languagemultiselect]
*/

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\PortalUserGroup\Listing getList()
* @method static \Pimcore\Model\DataObject\PortalUserGroup\Listing|\Pimcore\Model\DataObject\PortalUserGroup|null getByDataObjectWorkspaceDefinition($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUserGroup\Listing|\Pimcore\Model\DataObject\PortalUserGroup|null getByAssetWorkspaceDefinition($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUserGroup\Listing|\Pimcore\Model\DataObject\PortalUserGroup|null getByVisibleLanguages($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUserGroup\Listing|\Pimcore\Model\DataObject\PortalUserGroup|null getByEditableLanguages($value, $limit = 0, $offset = 0, $objectTypes = null)
*/

class PortalUserGroup extends \Pimcore\Bundle\PortalEngineBundle\Model\DataObject\AbstractPortalUserGroup
{
protected $o_classId = "portalusergroup";
protected $o_className = "PortalUserGroup";
protected $permission;
protected $dataObjectWorkspaceDefinition;
protected $assetWorkspaceDefinition;
protected $visibleLanguages;
protected $editableLanguages;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get permission - permission
* @return null|array
*/
public function getPermission()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("permission");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->permission;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set permission - permission
* @param null|array $permission
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public function setPermission($permission)
{
	$this->permission = $permission;

	return $this;
}

/**
* Get dataObjectWorkspaceDefinition - Data Object Workspace Definition
* @return \Pimcore\Model\DataObject\Data\ElementMetadata[]
*/
public function getDataObjectWorkspaceDefinition()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("dataObjectWorkspaceDefinition");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set dataObjectWorkspaceDefinition - Data Object Workspace Definition
* @param \Pimcore\Model\DataObject\Data\ElementMetadata[] $dataObjectWorkspaceDefinition
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public function setDataObjectWorkspaceDefinition($dataObjectWorkspaceDefinition)
{
	/** @var \Pimcore\Model\DataObject\ClassDefinition\Data\AdvancedManyToManyRelation $fd */
	$fd = $this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition");
	$hideUnpublished = \Pimcore\Model\DataObject\Concrete::getHideUnpublished();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished(false);
	$currentData = $this->getDataObjectWorkspaceDefinition();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished($hideUnpublished);
	$isEqual = $fd->isEqual($currentData, $dataObjectWorkspaceDefinition);
	if (!$isEqual) {
		$this->markFieldDirty("dataObjectWorkspaceDefinition", true);
	}
	$this->dataObjectWorkspaceDefinition = $fd->preSetData($this, $dataObjectWorkspaceDefinition);
	return $this;
}

/**
* Get assetWorkspaceDefinition - Asset Workspace Definition
* @return \Pimcore\Model\DataObject\Data\ElementMetadata[]
*/
public function getAssetWorkspaceDefinition()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("assetWorkspaceDefinition");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->getClass()->getFieldDefinition("assetWorkspaceDefinition")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set assetWorkspaceDefinition - Asset Workspace Definition
* @param \Pimcore\Model\DataObject\Data\ElementMetadata[] $assetWorkspaceDefinition
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public function setAssetWorkspaceDefinition($assetWorkspaceDefinition)
{
	/** @var \Pimcore\Model\DataObject\ClassDefinition\Data\AdvancedManyToManyRelation $fd */
	$fd = $this->getClass()->getFieldDefinition("assetWorkspaceDefinition");
	$hideUnpublished = \Pimcore\Model\DataObject\Concrete::getHideUnpublished();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished(false);
	$currentData = $this->getAssetWorkspaceDefinition();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished($hideUnpublished);
	$isEqual = $fd->isEqual($currentData, $assetWorkspaceDefinition);
	if (!$isEqual) {
		$this->markFieldDirty("assetWorkspaceDefinition", true);
	}
	$this->assetWorkspaceDefinition = $fd->preSetData($this, $assetWorkspaceDefinition);
	return $this;
}

/**
* Get visibleLanguages - Visible languages
* @return string[]|null
*/
public function getVisibleLanguages()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("visibleLanguages");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->visibleLanguages;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set visibleLanguages - Visible languages
* @param string[]|null $visibleLanguages
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public function setVisibleLanguages($visibleLanguages)
{
	$this->visibleLanguages = $visibleLanguages;

	return $this;
}

/**
* Get editableLanguages - Editable languages
* @return string[]|null
*/
public function getEditableLanguages()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("editableLanguages");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->editableLanguages;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set editableLanguages - Editable languages
* @param string[]|null $editableLanguages
* @return \Pimcore\Model\DataObject\PortalUserGroup
*/
public function setEditableLanguages($editableLanguages)
{
	$this->editableLanguages = $editableLanguages;

	return $this;
}

}

