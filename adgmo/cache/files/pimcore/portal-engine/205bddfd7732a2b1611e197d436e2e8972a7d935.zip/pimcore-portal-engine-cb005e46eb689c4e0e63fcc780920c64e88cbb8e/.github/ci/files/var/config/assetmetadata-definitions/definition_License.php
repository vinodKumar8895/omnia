<?php


return Pimcore\AssetMetadataClassDefinitionsBundle\Model\Configuration::__set_state(array(
   'name' => 'License',
   'title' => '',
   'prefix' => 'License',
   'icon' => '/bundles/pimcoreadmin/img/flat-color-icons/diploma_2.svg',
   'layoutDefinitions' =>
  Pimcore\AssetMetadataClassDefinitionsBundle\Model\ClassDefinition\Layout\Panel::__set_state(array(
     'fieldtype' => 'panel',
     'labelWidth' => 100,
     'layout' => NULL,
     'border' => false,
     'name' => NULL,
     'type' => NULL,
     'region' => NULL,
     'title' => NULL,
     'width' => NULL,
     'height' => NULL,
     'collapsible' => false,
     'collapsed' => false,
     'bodyStyle' => NULL,
     'datatype' => 'layout',
     'permissions' => NULL,
     'children' =>
    array (
      0 =>
      Pimcore\AssetMetadataClassDefinitionsBundle\Model\ClassDefinition\Layout\Panel::__set_state(array(
         'fieldtype' => 'panel',
         'labelWidth' => 100,
         'layout' => NULL,
         'border' => false,
         'name' => 'Layout',
         'type' => NULL,
         'region' => NULL,
         'title' => '',
         'width' => NULL,
         'height' => NULL,
         'collapsible' => false,
         'collapsed' => false,
         'bodyStyle' => '',
         'datatype' => 'layout',
         'permissions' => NULL,
         'children' =>
        array (
          0 =>
          Pimcore\AssetMetadataClassDefinitionsBundle\Model\ClassDefinition\Data\Input::__set_state(array(
             'fieldtype' => 'input',
             'datatype' => 'data',
             'name' => 'license',
             'title' => 'License',
             'style' => '',
             'width' => 500,
             'mandatory' => false,
          )),
          1 =>
          Pimcore\AssetMetadataClassDefinitionsBundle\Model\ClassDefinition\Data\Input::__set_state(array(
             'fieldtype' => 'input',
             'datatype' => 'data',
             'name' => 'licensePath',
             'title' => 'License Path',
             'style' => '',
             'width' => 500,
             'mandatory' => false,
          )),
        ),
         'locked' => false,
         'icon' => '',
      )),
    ),
     'locked' => false,
     'icon' => NULL,
  )),
   'dao' => NULL,
));
