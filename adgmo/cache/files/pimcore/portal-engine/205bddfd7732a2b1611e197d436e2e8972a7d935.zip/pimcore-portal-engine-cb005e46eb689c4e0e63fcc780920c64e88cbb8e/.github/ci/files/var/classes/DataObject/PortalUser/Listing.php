<?php

namespace Pimcore\Model\DataObject\PortalUser;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\PortalUser|false current()
 * @method DataObject\PortalUser[] load()
 * @method DataObject\PortalUser[] getData()
 */

class Listing extends DataObject\Listing\Concrete
{
protected $classId = "portaluser";
protected $className = "PortalUser";


/**
* Filter by email (E-Mail)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByEmail ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("email")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by firstname (First Name)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByFirstname ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("firstname")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by lastname (Last Name)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByLastname ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("lastname")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by preferredLanguage (Preferred Language)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByPreferredLanguage ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("preferredLanguage")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by pimcoreUser (Pimcore User)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByPimcoreUser ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("pimcoreUser")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by usePimcoreUserPassword (Use Pimcore User Password)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByUsePimcoreUserPassword ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("usePimcoreUserPassword")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by groups (Groups)
* @param mixed $data
* @param string $operator SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByGroups ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("groups")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by externalUserId (External User ID)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByExternalUserId ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("externalUserId")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by avatar (Avatar)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByAvatar ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("avatar")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by admin (Admin)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByAdmin ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("admin")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by dataObjectWorkspaceDefinition (Data Object Workspace Definition)
* @param mixed $data
* @param string $operator SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByDataObjectWorkspaceDefinition ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by assetWorkspaceDefinition (Asset Workspace Definition)
* @param mixed $data
* @param string $operator SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByAssetWorkspaceDefinition ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("assetWorkspaceDefinition")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by visibleLanguages (Visible languages)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByVisibleLanguages ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("visibleLanguages")->addListingFilter($this, $data, $operator);
	return $this;
}

/**
* Filter by editableLanguages (Editable Languages)
* @param string|int|float|array|Model\Element\ElementInterface $data  comparison data, can be scalar or array (if operator is e.g. "IN (?)")
* @param string $operator  SQL comparison operator, e.g. =, <, >= etc. You can use "?" as placeholder, e.g. "IN (?)"
* @return static
*/
public function filterByEditableLanguages ($data, $operator = '=')
{
	$this->getClass()->getFieldDefinition("editableLanguages")->addListingFilter($this, $data, $operator);
	return $this;
}



}
