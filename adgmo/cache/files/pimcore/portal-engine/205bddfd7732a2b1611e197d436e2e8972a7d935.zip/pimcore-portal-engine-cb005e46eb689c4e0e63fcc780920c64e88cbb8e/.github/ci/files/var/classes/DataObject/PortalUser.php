<?php

/**
* Inheritance: no
* Variants: no


Fields Summary:
- email [email]
- firstname [input]
- lastname [input]
- preferredLanguage [select]
- pimcoreUser [user]
- usePimcoreUserPassword [checkbox]
- portalPassword [password]
- groups [permissionManyToManyRelation]
- externalUserId [input]
- avatar [image]
- admin [checkbox]
- permission [dynamicPermissionResource]
- dataObjectWorkspaceDefinition [advancedManyToManyRelation]
- assetWorkspaceDefinition [advancedManyToManyRelation]
- visibleLanguages [languagemultiselect]
- editableLanguages [languagemultiselect]
*/

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\PortalUser\Listing getList()
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByEmail($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByFirstname($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByLastname($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByPreferredLanguage($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByPimcoreUser($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByUsePimcoreUserPassword($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByGroups($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByExternalUserId($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByAvatar($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByAdmin($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByDataObjectWorkspaceDefinition($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByAssetWorkspaceDefinition($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByVisibleLanguages($value, $limit = 0, $offset = 0, $objectTypes = null)
* @method static \Pimcore\Model\DataObject\PortalUser\Listing|\Pimcore\Model\DataObject\PortalUser|null getByEditableLanguages($value, $limit = 0, $offset = 0, $objectTypes = null)
*/

class PortalUser extends \Pimcore\Bundle\PortalEngineBundle\Model\DataObject\AbstractPortalUser
{
protected $o_classId = "portaluser";
protected $o_className = "PortalUser";
protected $email;
protected $firstname;
protected $lastname;
protected $preferredLanguage;
protected $pimcoreUser;
protected $usePimcoreUserPassword;
protected $portalPassword;
protected $groups;
protected $externalUserId;
protected $avatar;
protected $admin;
protected $permission;
protected $dataObjectWorkspaceDefinition;
protected $assetWorkspaceDefinition;
protected $visibleLanguages;
protected $editableLanguages;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\PortalUser
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get email - E-Mail
* @return string|null
*/
public function getEmail()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("email");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->email;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set email - E-Mail
* @param string|null $email
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setEmail($email)
{
	$this->email = $email;

	return $this;
}

/**
* Get firstname - First Name
* @return string|null
*/
public function getFirstname()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("firstname");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->firstname;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set firstname - First Name
* @param string|null $firstname
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setFirstname($firstname)
{
	$this->firstname = $firstname;

	return $this;
}

/**
* Get lastname - Last Name
* @return string|null
*/
public function getLastname()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("lastname");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->lastname;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set lastname - Last Name
* @param string|null $lastname
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setLastname($lastname)
{
	$this->lastname = $lastname;

	return $this;
}

/**
* Get preferredLanguage - Preferred Language
* @return string|null
*/
public function getPreferredLanguage()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("preferredLanguage");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->preferredLanguage;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set preferredLanguage - Preferred Language
* @param string|null $preferredLanguage
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setPreferredLanguage($preferredLanguage)
{
	$this->preferredLanguage = $preferredLanguage;

	return $this;
}

/**
* Get pimcoreUser - Pimcore User
* @return string|null
*/
public function getPimcoreUser()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("pimcoreUser");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->pimcoreUser;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set pimcoreUser - Pimcore User
* @param string|null $pimcoreUser
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setPimcoreUser($pimcoreUser)
{
	$this->pimcoreUser = $pimcoreUser;

	return $this;
}

/**
* Get usePimcoreUserPassword - Use Pimcore User Password
* @return bool|null
*/
public function getUsePimcoreUserPassword()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("usePimcoreUserPassword");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->usePimcoreUserPassword;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set usePimcoreUserPassword - Use Pimcore User Password
* @param bool|null $usePimcoreUserPassword
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setUsePimcoreUserPassword($usePimcoreUserPassword)
{
	$this->usePimcoreUserPassword = $usePimcoreUserPassword;

	return $this;
}

/**
* Get portalPassword - Password
* @return string|null
*/
public function getPortalPassword()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("portalPassword");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->portalPassword;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set portalPassword - Password
* @param string|null $portalPassword
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setPortalPassword($portalPassword)
{
	$this->portalPassword = $portalPassword;

	return $this;
}

/**
* Get groups - Groups
* @return \Pimcore\Model\DataObject\PortalUserGroup[]
*/
public function getGroups()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("groups");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->getClass()->getFieldDefinition("groups")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set groups - Groups
* @param \Pimcore\Model\DataObject\PortalUserGroup[] $groups
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setGroups($groups)
{
	/** @var \FrontendPermissionToolkitBundle\CoreExtensions\ClassDefinitions\PermissionManyToManyRelation $fd */
	$fd = $this->getClass()->getFieldDefinition("groups");
	$hideUnpublished = \Pimcore\Model\DataObject\Concrete::getHideUnpublished();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished(false);
	$currentData = $this->getGroups();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished($hideUnpublished);
	$isEqual = $fd->isEqual($currentData, $groups);
	if (!$isEqual) {
		$this->markFieldDirty("groups", true);
	}
	$this->groups = $fd->preSetData($this, $groups);
	return $this;
}

/**
* Get externalUserId - External User ID
* @return string|null
*/
public function getExternalUserId()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("externalUserId");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->externalUserId;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set externalUserId - External User ID
* @param string|null $externalUserId
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setExternalUserId($externalUserId)
{
	$this->externalUserId = $externalUserId;

	return $this;
}

/**
* Get avatar - Avatar
* @return \Pimcore\Model\Asset\Image|null
*/
public function getAvatar()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("avatar");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->avatar;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set avatar - Avatar
* @param \Pimcore\Model\Asset\Image|null $avatar
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setAvatar($avatar)
{
	$this->avatar = $avatar;

	return $this;
}

/**
* Get admin - Admin
* @return bool|null
*/
public function getAdmin()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("admin");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->admin;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set admin - Admin
* @param bool|null $admin
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setAdmin($admin)
{
	$this->admin = $admin;

	return $this;
}

/**
* Get permission - permission
* @return null|array
*/
public function getPermission()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("permission");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->permission;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set permission - permission
* @param null|array $permission
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setPermission($permission)
{
	$this->permission = $permission;

	return $this;
}

/**
* Get dataObjectWorkspaceDefinition - Data Object Workspace Definition
* @return \Pimcore\Model\DataObject\Data\ElementMetadata[]
*/
public function getDataObjectWorkspaceDefinition()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("dataObjectWorkspaceDefinition");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set dataObjectWorkspaceDefinition - Data Object Workspace Definition
* @param \Pimcore\Model\DataObject\Data\ElementMetadata[] $dataObjectWorkspaceDefinition
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setDataObjectWorkspaceDefinition($dataObjectWorkspaceDefinition)
{
	/** @var \Pimcore\Model\DataObject\ClassDefinition\Data\AdvancedManyToManyRelation $fd */
	$fd = $this->getClass()->getFieldDefinition("dataObjectWorkspaceDefinition");
	$hideUnpublished = \Pimcore\Model\DataObject\Concrete::getHideUnpublished();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished(false);
	$currentData = $this->getDataObjectWorkspaceDefinition();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished($hideUnpublished);
	$isEqual = $fd->isEqual($currentData, $dataObjectWorkspaceDefinition);
	if (!$isEqual) {
		$this->markFieldDirty("dataObjectWorkspaceDefinition", true);
	}
	$this->dataObjectWorkspaceDefinition = $fd->preSetData($this, $dataObjectWorkspaceDefinition);
	return $this;
}

/**
* Get assetWorkspaceDefinition - Asset Workspace Definition
* @return \Pimcore\Model\DataObject\Data\ElementMetadata[]
*/
public function getAssetWorkspaceDefinition()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("assetWorkspaceDefinition");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->getClass()->getFieldDefinition("assetWorkspaceDefinition")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set assetWorkspaceDefinition - Asset Workspace Definition
* @param \Pimcore\Model\DataObject\Data\ElementMetadata[] $assetWorkspaceDefinition
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setAssetWorkspaceDefinition($assetWorkspaceDefinition)
{
	/** @var \Pimcore\Model\DataObject\ClassDefinition\Data\AdvancedManyToManyRelation $fd */
	$fd = $this->getClass()->getFieldDefinition("assetWorkspaceDefinition");
	$hideUnpublished = \Pimcore\Model\DataObject\Concrete::getHideUnpublished();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished(false);
	$currentData = $this->getAssetWorkspaceDefinition();
	\Pimcore\Model\DataObject\Concrete::setHideUnpublished($hideUnpublished);
	$isEqual = $fd->isEqual($currentData, $assetWorkspaceDefinition);
	if (!$isEqual) {
		$this->markFieldDirty("assetWorkspaceDefinition", true);
	}
	$this->assetWorkspaceDefinition = $fd->preSetData($this, $assetWorkspaceDefinition);
	return $this;
}

/**
* Get visibleLanguages - Visible languages
* @return string[]|null
*/
public function getVisibleLanguages()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("visibleLanguages");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->visibleLanguages;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set visibleLanguages - Visible languages
* @param string[]|null $visibleLanguages
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setVisibleLanguages($visibleLanguages)
{
	$this->visibleLanguages = $visibleLanguages;

	return $this;
}

/**
* Get editableLanguages - Editable Languages
* @return string[]|null
*/
public function getEditableLanguages()
{
	if ($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) {
		$preValue = $this->preGetValue("editableLanguages");
		if ($preValue !== null) {
			return $preValue;
		}
	}

	$data = $this->editableLanguages;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		return $data->getPlain();
	}

	return $data;
}

/**
* Set editableLanguages - Editable Languages
* @param string[]|null $editableLanguages
* @return \Pimcore\Model\DataObject\PortalUser
*/
public function setEditableLanguages($editableLanguages)
{
	$this->editableLanguages = $editableLanguages;

	return $this;
}

}

