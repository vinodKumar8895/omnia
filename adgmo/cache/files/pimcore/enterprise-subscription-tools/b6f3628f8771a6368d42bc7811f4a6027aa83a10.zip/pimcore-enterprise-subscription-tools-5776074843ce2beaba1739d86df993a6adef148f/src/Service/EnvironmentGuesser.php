<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Service;

use Symfony\Component\HttpKernel\KernelInterface;

class EnvironmentGuesser
{
    const ENVIRONMENT_PRODUCTION = 'prod';
    const ENVIRONMENT_TEST = 'test';
    const ENVIRONMENT_DEVELOPMENT = 'dev';

    /**
     * @var KernelInterface
     */
    protected $kernel;

    /**
     * @var bool|null
     */
    protected $productionSystemSetting;

    /**
     * @param KernelInterface $kernel
     * @param bool|null $productionSystemSetting
     */
    public function __construct(KernelInterface $kernel, $productionSystemSetting)
    {
        $this->kernel = $kernel;
        $this->productionSystemSetting = $productionSystemSetting;
    }

    public function getEnvironment(): string
    {
        if (null !== $this->productionSystemSetting) {
            return
                $this->productionSystemSetting === true
                    ? self::ENVIRONMENT_PRODUCTION
                    : self::ENVIRONMENT_DEVELOPMENT;
        }

        if ($this->kernel->isDebug()) {
            return self::ENVIRONMENT_DEVELOPMENT;
        }

        if ($this->kernel->getEnvironment() === 'test') {
            return self::ENVIRONMENT_TEST;
        }

        return self::ENVIRONMENT_PRODUCTION;
    }

    public function isDevelopmentEnvironment(): bool
    {
        return $this->getEnvironment() !== self::ENVIRONMENT_PRODUCTION;
    }
}
