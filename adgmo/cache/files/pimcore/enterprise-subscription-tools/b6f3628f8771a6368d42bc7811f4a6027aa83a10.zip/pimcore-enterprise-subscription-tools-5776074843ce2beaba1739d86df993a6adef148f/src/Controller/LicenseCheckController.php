<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Controller;

use Pimcore\Bundle\AdminBundle\HttpFoundation\JsonResponse;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Service\EnterpriseSubscriptionStatusService;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Service\EnvironmentGuesser;
use Pimcore\Controller\FrontendController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class LicenseCheckController extends FrontendController
{
    /**
     * @Route("/admin/enterprise-subscription-tools/instance-info")
     */
    public function instanceInfoAction(Request $request, EnterpriseSubscriptionStatusService $service, EnvironmentGuesser $environmentGuesser)
    {
        $environment = $environmentGuesser->getEnvironment();

        return new JsonResponse([
            'success' => true,
            'instanceId' => $service->getInstanceId(),
            'environment' => $environment,
            'instanceCode' => $service->buildInstanceCode()
        ]);
    }
}
