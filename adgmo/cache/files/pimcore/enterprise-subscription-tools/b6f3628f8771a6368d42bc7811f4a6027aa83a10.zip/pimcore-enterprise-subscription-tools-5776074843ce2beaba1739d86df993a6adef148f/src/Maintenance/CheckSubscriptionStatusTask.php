<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Maintenance;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Psr7\Request;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Service\EnterpriseSubscriptionStatusService;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Service\EnvironmentGuesser;
use Pimcore\Config;
use Pimcore\Maintenance\TaskInterface;
use Pimcore\Model\Tool\TmpStore;
use Psr\Log\LoggerInterface;

class CheckSubscriptionStatusTask implements TaskInterface
{
    /**
     * @var EnterpriseSubscriptionStatusService
     */
    protected $subscriptionStatusService;

    /**
     * @var ClientInterface
     */
    protected $httpClient;

    /**
     * @var EnvironmentGuesser
     */
    protected $environmentGuesser;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @param EnterpriseSubscriptionStatusService $subscriptionStatusService
     * @param ClientInterface $httpClient
     * @param Config $config
     * @param LoggerInterface $logger
     * @param EnvironmentGuesser $environmentGuesser
     */
    public function __construct(EnterpriseSubscriptionStatusService $subscriptionStatusService, ClientInterface $httpClient, Config $config, LoggerInterface $logger, EnvironmentGuesser $environmentGuesser)
    {
        $this->subscriptionStatusService = $subscriptionStatusService;
        $this->httpClient = $httpClient;
        $this->config = $config;
        $this->logger = $logger;
        $this->environmentGuesser = $environmentGuesser;
    }

    /**
     * Execute the Task
     */
    public function execute()
    {
        $lockId = 'EnterpriseSubscription::CheckSubscriptionStatusTask';

        $locked = TmpStore::get($lockId);

        if (!$locked && date('H') <= 4) {
            // execution should be only sometime between 0:00 and 4:59 -> less load expected
            $this->logger->debug('Checking Pimcore Subscription Status');

            $request = new Request('POST', 'https://license.pimcore.com/pimcore-license/check');
            $response = $this->httpClient->send($request, [
                'form_params' => [
                    'instanceId' => $this->subscriptionStatusService->getInstanceId(),
                    'instanceCode' => $this->subscriptionStatusService->buildInstanceCode(),
                    'environment' => $this->environmentGuesser->getEnvironment(),
                    'main_domain' => $this->config['general']['domain']
                ]
            ]);
            TmpStore::set($lockId, true, null, 86400);
        } else {
            $this->logger->debug('Skip Checking Pimcore Subscription Status, was done within the last 24 hours');
        }
    }
}
