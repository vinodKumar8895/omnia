# Installation 

This bundle depends on Pimcore [Datahub bundle](https://pimcore.com/docs/data-hub/current) and
[Datahub Simple Rest API](https://pimcore.com/docs/data-hub-simple-rest/current). 
They need to be installed first. 

To install Pimcore Datahub CI Hub use following commands: 

```bash
composer require pimcore/data-hub-ci-hub
./bin/console pimcore:bundle:enable PimcoreDataHubCiHubBundle
```

> Make sure, that priority of Datahub bundle is higher than priority of Datahub Simple Rest API bundle, 
> and priority of Datahub Simple Rest API is higher that priority of Datahub CI Hub. 
> This can be specified as parameter during bundle enabling or in Pimcore extension manager. 