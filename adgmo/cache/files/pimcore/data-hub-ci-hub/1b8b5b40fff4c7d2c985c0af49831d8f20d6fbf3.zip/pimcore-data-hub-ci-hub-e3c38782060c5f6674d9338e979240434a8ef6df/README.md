# Pimcore Datahub CI Hub integration

## Features in a nutshell

This bundle integrates [CI Hub](https://ci-hub.com/) to Pimcore Datahub and therefore allows integrating Pimcore 
assets and data objects directly into Adobe and Microsoft Products. 

- Configure schema and exposed data like with other Datahub adapters via drag & drop.
- Exported data is cached to get a high performance API.
- A token is provided which can be used for connecting CI Hub with your Pimcore Datahub endpoint


<div class="image-as-lightbox"></div>

![Configuration](./doc/img/ci-hub-config.png)


## Further Information
Since this bundle is based on the [Pimcore Datahub Simple Rest API bundle](https://pimcore.com/docs/data-hub-simple-rest/current), 
see its documentation for details on configuration and usage.

For installation details see [installation page](./doc/01_Installation.md). 
