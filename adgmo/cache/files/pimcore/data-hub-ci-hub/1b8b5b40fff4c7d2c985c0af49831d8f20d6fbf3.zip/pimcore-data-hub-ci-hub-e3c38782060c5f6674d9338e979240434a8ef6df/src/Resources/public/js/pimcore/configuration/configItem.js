/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */


pimcore.registerNS("pimcore.plugin.pimcoreDataHubCiHubBundle.configuration.configItem");
pimcore.plugin.pimcoreDataHubCiHubBundle.configuration.configItem = Class.create(pimcore.plugin.pimcoreDataHubSimpleRestBundle.configuration.configItem, {
    getDeliverySettings: function() {
        var apikeyField = new Ext.form.field.Text({
            xtype: "textfield",
            labelWidth: 200,
            width: 600,
            fieldLabel: t("plugin_pimcore_datahub_security_datahub_apikey"),
            name: "apikey",
            value: this.data.deliverySettings ? this.data.deliverySettings.apikey : "",
            minLength: 16
        });

        this.deliverySettingsForm = new Ext.form.FormPanel({
            bodyStyle: "padding:10px;",
            autoScroll: true,
            defaults: {
                labelWidth: 200
            },
            border: false,
            title: t("plugin_pimcore_datahub_simple_rest_configpanel_delivery_settings"),
            items: [
                {
                    xtype: "fieldcontainer",
                    layout: 'hbox',

                    items: [
                        apikeyField,
                        {
                            xtype: "button",
                            width: 32,
                            style: "margin-left: 8px",
                            iconCls: "pimcore_icon_clear_cache",
                            handler: function () {
                                apikeyField.setValue(md5(uniqid()));
                            }.bind(this)
                        }
                    ]
                },
                {
                    xtype: 'displayfield',
                    hideLabel: false,
                    value: t("plugin_pimcore_datahub_simple_rest_security_apikey_description"),
                    cls: "pimcore_extra_label_bottom",
                    readOnly: true,
                    disabled: true
                }
            ]
        });

        return this.deliverySettingsForm;
    }
});
