<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\DataHubCiHubBundle;

use Pimcore\Bundle\DataHubBundle\PimcoreDataHubBundle;
use Pimcore\Bundle\DataHubSimpleRestBundle\PimcoreDataHubSimpleRestBundle;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\Bundle\EnterpriseBundleInterface;
use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\PimcoreEnterpriseSubscriptionToolsBundle;
use Pimcore\Extension\Bundle\AbstractPimcoreBundle;
use Pimcore\Extension\Bundle\Traits\PackageVersionTrait;
use Pimcore\HttpKernel\Bundle\DependentBundleInterface;
use Pimcore\HttpKernel\BundleCollection\BundleCollection;

class PimcoreDataHubCiHubBundle extends AbstractPimcoreBundle implements DependentBundleInterface, EnterpriseBundleInterface
{
    use PackageVersionTrait;

    public function getJsPaths()
    {
        return [
            '/bundles/pimcoredatahubcihub/js/pimcore/startup.js',
            '/bundles/pimcoredatahubcihub/js/pimcore/adapter/ciHub.js',
            '/bundles/pimcoredatahubcihub/js/pimcore/configuration/configItem.js'
        ];
    }

    public function getCssPaths()
    {
        return [
            '/bundles/pimcoredatahubcihub/css/icons.css'
        ];
    }

    /**
     * Register bundles to collection.
     *
     * WARNING: this method will be called as soon as this bundle is added to the collection, independent if
     * it will finally be included due to environment restrictions. If you need to load your dependencies conditionally,
     * specify the environments to use on the collection item.
     *
     * @param BundleCollection $collection
     */
    public static function registerDependentBundles(BundleCollection $collection)
    {
        $collection->addBundle(PimcoreDataHubBundle::class, 25);
        $collection->addBundle(PimcoreDataHubSimpleRestBundle::class, 20);
        $collection->addBundle(new PimcoreEnterpriseSubscriptionToolsBundle());
    }

    /**
     * @return string
     */
    public function getBundleLicenseId(): string
    {
        return 'DCI';
    }

    /**
     * Returns the composer package name used to resolve the version
     *
     * @return string
     */
    protected function getComposerPackageName(): string
    {
        return 'pimcore/data-hub-ci-hub';
    }

    public function getInstaller()
    {
        return $this->container->get(Installer::class);
    }
}
