<?php

namespace OpenApi\Tests\Fixtures\InheritProperties;

/**
 * @OA\Schema()
 */
class Base
{

    /**
     * @OA\Property();
     * @var string
     */
    public $baseProperty;
}
