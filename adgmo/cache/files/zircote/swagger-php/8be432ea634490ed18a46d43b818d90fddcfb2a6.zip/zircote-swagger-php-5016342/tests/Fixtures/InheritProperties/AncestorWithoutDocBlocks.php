<?php declare(strict_types=1);

namespace OpenApi\Tests\Fixtures\InheritProperties;

class AncestorWithoutDocBlocks extends GrandAncestor
{
    public $firstname;
}
