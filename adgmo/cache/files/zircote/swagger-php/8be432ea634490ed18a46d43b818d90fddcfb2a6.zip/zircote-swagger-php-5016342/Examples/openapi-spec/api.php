<?php

/**
 * @OA\Info(
 *  title="Link Example",
 *  version="1.0.0"
 * )
 */
